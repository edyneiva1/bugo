'use strict';
globalThis.BGCarModels=(()=>{
 const models=new Map();
 // Dimensions are in meters, centered on the rear/front axle midpoint.
 const profiles=[
  [1,1,1,1],[.93,1.11,1.04,.91],[1.07,.89,.86,1.06],[.98,1.04,.91,1.13]
 ];
 function make(id,lod){
  const key=id+'/'+lod;if(models.has(key))return models.get(key);
  const [width,length,roof,wing]=profiles[id%4],g=[];
  const triangle=(a,b,c,m,k=1)=>{g.push({a,b,c,m,k});};
  const quad=(a,b,c,d,m,k=1)=>{triangle(a,b,c,m,k);triangle(a,c,d,m,k);};
  const curve=(a,b,c,d,t)=>b+.5*t*(c-a+t*(2*a-5*b+4*c-d+t*(3*b-a-3*c+d)));
  function shell(sections,rings,m){
   const split=lod===2?3:lod===1?2:1,row=[];
   const start=g.length;
   for(let j=0;j<(sections.length-1)*split+1;j++){
    const i=Math.min(sections.length-2,Math.floor(j/split)),t=j/split-i;
    const q=sections[i].map((_,n)=>curve(sections[Math.max(0,i-1)][n],sections[i][n],sections[i+1][n],sections[Math.min(sections.length-1,i+2)][n],t));
    const [z,w,bottom,top]=q;
    row.push(Array.from({length:rings},(_,k)=>{
     const angle=2*Math.PI*k/rings, h=Math.sin(angle);
     return [w*Math.sign(Math.cos(angle))*Math.abs(Math.cos(angle))**.57,
      (top+bottom)/2+(top-bottom)*Math.sign(h)*Math.abs(h)**.66/2,z];
    }));
   }
   for(let j=1;j<row.length;j++)for(let k=0;k<rings;k++){
    const l=(k+1)%rings;
    const material=m==='glass'&&j>split*2&&j<split*4&&k>=Math.floor(rings*.14)&&k<Math.ceil(rings*.37)?'paint':m;
    quad(row[j-1][k],row[j-1][l],row[j][l],row[j][k],material);
   }
   for(let i=start;i<g.length;i++)g[i].smooth=start;
   for(let k=1;k<rings-1;k++){
    triangle(row[0][0],row[0][k],row[0][k+1],m);
    const end=row.at(-1);triangle(end[0],end[k+1],end[k],m);
   }
  }
  const body=[[-2.15,.76,.29,.68],[-2.01,.93,.24,.85],[-1.65,1.02,.23,.97],[-1.13,.99,.22,.95],
   [-.56,.92,.22,.83],[.48,.90,.21,.82],[1.05,.96,.21,.88],[1.58,.96,.22,.84],[2.03,.85,.29,.66],[2.16,.72,.32,.57]];
  shell(body.map(([z,w,l,h])=>[z*length,w*width,l,h]),lod===2?24:lod===1?12:8,'paint');
  const cabin=[[-1.26,.67,.75,.85],[-.87,.73,.78,1.07],[-.45,.67,.80,1.36],[.20,.62,.80,1.37],[.53,.67,.80,1.25],[1.06,.74,.77,.85]];
  shell(cabin.map(([z,w,l,h])=>[z*length,w*width,l,l+(h-l)*roof]),lod===2?20:lod===1?10:6,'glass');
  const zRear=-2.165*length,zFront=2.17*length;
  function panel(z,x0,x1,y0,y1,m,inset=0){
   const sign=Math.sign(z);
   quad([x0+.04,y0,z+sign*inset],[x1-.04,y0,z+sign*inset],[x1,y1,z-sign*.022],[x0,y1,z-sign*.022],m);
  }
  panel(zRear,-.72,.72,.475,.65,'trim',.011);
  panel(zRear,-.46,.46,.29,.40,'mesh',.042);
  panel(zFront,-.56,.56,.33,.47,'mesh',.075);
  for(const side of [-1,1]){
   const [a,b]=[side*.44,side*.76].sort((x,y)=>x-y);
   panel(zRear,a,b,.54,.638,'tail',.035);
   if(lod===2){panel(zRear,a+.035,b-.035,.575,.598,'tailLight',.048);panel(zFront,a+.045,b-.045,.465,.485,'head',.04);}
   panel(zFront,a,b,.445,.545,'head',.025);
   panel(zFront,side<0?-.72:.5,side<0?-.5:.72,.30,.41,'mesh',.025);
   const x=side*.89*width;
   // Door seam follows the rocker, and two stainless exhaust tips flank the diffuser.
   quad([x,.42,-.92],[x,.44,-.92],[x,.47,.71],[x,.455,.71],'trim');
   const ex=side*.61;
   tube(ex,.335,zRear-.05, .08,.12,lod===2?14:8,'metal','mesh','z');
   const mirror=side*.82*width;
   quad([mirror,.94,.25],[mirror+side*.16,.965,.24],[mirror+side*.17,1.03,.36],[mirror,1.03,.40],'paint');
  }
  function tube(cx,cy,cz,r,depth,n,m,cap,axis){
   const at=(a,v)=>axis==='x'?[cx+v,cy+Math.cos(a)*r,cz+Math.sin(a)*r]:[cx+Math.sin(a)*r,cy+Math.cos(a)*r,cz+v];
   for(let i=0;i<n;i++){
    const a=i/n*Math.PI*2,b=(i+1)/n*Math.PI*2;
    quad(at(a,-depth/2),at(b,-depth/2),at(b,depth/2),at(a,depth/2),m);
    const v=depth/2;
    for(const side of [-1,1]){
     const center=axis==='x'?[cx+side*v,cy,cz]:[cx,cy,cz+side*v];
     const outward=axis==='x'?side===1:side===-1;
     triangle(center,at(outward?a:b,side*v),at(outward?b:a,side*v),cap);
    }
   }
  }
  for(const axle of [-1,1])for(const side of [-1,1]){
   const x=side*.89*width,z=axle*1.29*length,y=.347,n=lod===2?24:lod===1?16:10;
   const u=x+side*.146;
   tube(x,y,z,.345,.27,n,'rubber','rubber','x');
   tube(u,y,z,.248,.024,n,'metal','rim','x');
   if(lod){
    const ring=(r,a)=>[u+side*.017,y+Math.cos(a)*r,z+Math.sin(a)*r];
    for(let k=0;k<n;k++){const a=k*2*Math.PI/n,b=(k+1)*2*Math.PI/n;quad(ring(.249,a),ring(.249,b),ring(.223,b),ring(.223,a),'metal');}
   }
   if(lod){
    for(let i=0;i<7;i++){
     const a=i*2*Math.PI/7;
     const v=(r,turn)=>[u+side*.018,y+Math.cos(a+turn)*r,z+Math.sin(a+turn)*r];
     quad(v(.044,-.34),v(.236,-.07),v(.22,.13),v(.04,.51),'metal');
    }
    tube(u+side*.023,y,z,.057,.022,8,'metal','metal','x');
   }
  }
  if(id!==2){
   const z=-1.85*length,y=1.04+(wing-.8)*.17;
   quad([-.95,y,z],[.95,y,z],[.90,y+.022,z+.33],[-.90,y+.022,z+.33],'carbon');
   quad([-.95,y,z],[.95,y,z],[.95,y-.048,z],[-.95,y-.048,z],'paint');
   for(const x of [-.74,.74]){
    quad([x,.72,z+.16],[x,y,z+.12],[x,y,z+.29],[x,.74,z+.35],'carbon');
    quad([x*1.26,y-.075,z-.02],[x*1.26,y+.08,z+.01],[x*1.26,y+.07,z+.34],[x*1.26,y-.07,z+.28],'carbon');
   }
  }
  const normals=new Map();
  const keyFor=(t,v)=>t.smooth+':'+v.join(',');
  for(const t of g){
   const a=t.b.map((v,i)=>v-t.a[i]),b=t.c.map((v,i)=>v-t.a[i]);
   const n=[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
   const len=Math.hypot(...n)||1;
   t.n=n.map(v=>v/len);
   if(t.smooth!==undefined)for(const v of [t.a,t.b,t.c]){const key=keyFor(t,v),old=normals.get(key)||[0,0,0];normals.set(key,old.map((x,i)=>x+n[i]));}
  }
  for(const t of g)if(t.smooth!==undefined){
   [t.na,t.nb,t.nc]=[t.a,t.b,t.c].map(v=>{const n=normals.get(keyFor(t,v)),l=Math.hypot(...n)||1;return n.map(x=>x/l);});
  }
  models.set(key,g);return g;
 }
 return {make};
})();
