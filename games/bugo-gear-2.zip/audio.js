/* Original synthesized score and sound effects. No recorded audio assets. */
(() => {
  "use strict";

  const motifs = {
    title: { bpm: 116, chords: [45, 41, 48, 43], lead: [69, 0, 72, 76, 74, 0, 72, 67, 69, 0, 72, 77, 76, 74, 72, 0] },
    menu: { bpm: 103, chords: [50, 46, 41, 48], lead: [65, 0, 69, 72, 69, 65, 62, 0, 67, 0, 69, 72, 74, 72, 69, 0] },
    race: { bpm: 151, chords: [40, 43, 38, 45], lead: [64, 67, 71, 67, 74, 71, 67, 0, 76, 74, 71, 69, 67, 69, 71, 0] },
    results: { bpm: 114, chords: [48, 45, 41, 43], lead: [72, 76, 79, 0, 76, 72, 69, 0, 72, 77, 81, 0, 79, 74, 71, 0] },
    ending: { bpm: 93, chords: [41, 48, 46, 41], lead: [65, 69, 72, 77, 0, 76, 72, 0, 74, 72, 70, 69, 65, 0, 0, 0] }
  };

  const effects = {
    navigate: [520, 680, .07], confirm: [440, 780, .12], purchase: [460, 920, .22],
    shift: [260, 180, .09], brake: [1050, 430, .14], skid: [780, 220, .20],
    collision: [135, 34, .24], nitro: [145, 670, .36], pickup: [620, 1210, .14],
    countdown: [380, 380, .16], start: [770, 790, .3], finish: [620, 990, .26]
  };

  const aliases = {
    select: "navigate", buy: "purchase", crash: "collision", hit: "collision",
    boost: "nitro", collect: "pickup", gear: "shift", go: "start", beep: "countdown"
  };

  const frequency = midi => 440 * 2 ** ((midi - 69) / 12);
  let context;
  let master;
  let musicBus, effectBus;
  let musicLevel=.8, effectLevel=.8;
  const voices=[];
  let roadNoise, roadFilter, roadGain;
  let noise;
  let muted = false;
  let active;
  let next = 0;
  let step = 0;

  function start() {
    const AudioContext = globalThis.AudioContext || globalThis.webkitAudioContext;
    if (!AudioContext) return;
    if (!context) {
      context = new AudioContext();
      master = context.createGain();
      master.gain.value = muted ? 0 : .52;
      master.connect(context.destination);
      musicBus=context.createGain(); musicBus.gain.value=musicLevel; musicBus.connect(master);
      effectBus=context.createGain(); effectBus.gain.value=effectLevel; effectBus.connect(master);

      for(let player=0;player<2;player++){
      const engine = context.createOscillator();
      engine.type = "sawtooth";
      engine.frequency.value = 36;
      const engineFilter = context.createBiquadFilter();
      engineFilter.type = "lowpass";
      engineFilter.frequency.value = 180;
      const engineGain = context.createGain();
      engineGain.gain.value = 0;
      engine.connect(engineFilter).connect(engineGain).connect(effectBus);
      engine.start();
      // Second combustion layer: lower exhaust fundamental, mixed below the main motor.
      const exhaust = context.createOscillator();
      exhaust.type = "triangle";
      exhaust.frequency.value = 36;
      const exhaustGain = context.createGain();
      exhaustGain.gain.value = 0;
      exhaust.connect(exhaustGain).connect(effectBus);
      exhaust.start();
      voices.push({engine,engineFilter,engineGain,exhaust,exhaustGain});
      }

      noise = context.createBuffer(1, context.sampleRate, context.sampleRate);
      const samples = noise.getChannelData(0);
      let seed = 92771;
      for (let i = 0; i < samples.length; i++) {
        seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
        samples[i] = seed / 2147483648 - 1;
      }
      roadNoise = context.createBufferSource();
      roadNoise.buffer = noise;
      roadNoise.loop = true;
      roadFilter = context.createBiquadFilter();
      roadFilter.type = "lowpass";
      roadFilter.frequency.value = 350;
      roadGain = context.createGain();
      roadGain.gain.value = 0;
      roadNoise.connect(roadFilter).connect(roadGain).connect(effectBus);
      roadNoise.start();
    }
    if (context.state === "suspended") context.resume().catch(() => {});
  }

  function tone(at, hz, target, length, level, shape, bus=musicBus) {
    const oscillator = context.createOscillator();
    const envelope = context.createGain();
    oscillator.type = shape;
    oscillator.frequency.setValueAtTime(hz, at);
    oscillator.frequency.exponentialRampToValueAtTime(target, at + length);
    envelope.gain.setValueAtTime(.0001, at);
    envelope.gain.exponentialRampToValueAtTime(level, at + .009);
    envelope.gain.exponentialRampToValueAtTime(.0001, at + length);
    oscillator.connect(envelope).connect(bus);
    oscillator.start(at);
    oscillator.stop(at + length + .006);
    oscillator.onended = () => { oscillator.disconnect(); envelope.disconnect(); };
  }

  function percussion(at, cutoff, length, level, bus=musicBus) {
    const source = context.createBufferSource();
    const filter = context.createBiquadFilter();
    const envelope = context.createGain();
    source.buffer = noise;
    filter.type = "bandpass";
    filter.frequency.value = cutoff;
    filter.Q.value = .7;
    envelope.gain.setValueAtTime(level, at);
    envelope.gain.exponentialRampToValueAtTime(.0001, at + length);
    source.connect(filter).connect(envelope).connect(bus);
    source.start(at);
    source.stop(at + length + .006);
    source.onended = () => { source.disconnect(); filter.disconnect(); envelope.disconnect(); };
  }

  function schedule(song, at, i, interval) {
    const bar = Math.floor(i / 8) % 4;
    const beat = i % 8;
    const root = song.chords[bar];
    const note = song.lead[i % song.lead.length];
    if (note) {
      const section=Math.floor(i/16)%4;
      const pitch=frequency(note+(section===2?12:0));
      tone(at,pitch,pitch,interval*.76,.069,section===2?"triangle":"square");
      if(section===3)tone(at,frequency(note-12),frequency(note-12),interval*.63,.034,"triangle");
    }
    if (beat % 2 === 0) {
      const bass = frequency(root + (beat === 6 ? 7 : 0) - 12);
      tone(at, bass, bass, interval * 1.35, .14, "triangle");
    }
    if (beat === 1 || beat === 5) {
      const harmony = frequency(root + (bar === 0 || bar === 2 ? 15 : 16));
      tone(at, harmony, harmony, interval * 1.25, .037, "triangle");
    }
    if (beat === 0 || beat === 4) tone(at, 116, 42, .115, .14, "sine");
    if (beat === 2 || beat === 6) percussion(at, 1400, .09, .12);
    if (beat % 2 === 1) percussion(at, 6800, .038, .064);
  }

  function update(mode, race) {
    if (!context || context.state !== "running") return;
    const now = context.currentTime;
    const running = mode === "race" || mode === "racing";
    const humans = running ? (race?.cars||[]).filter(car => car.player && !car.retired && car.finish===null) : [];
    const mix=humans.length>1?.65:1;
    for(let i=0;i<voices.length;i++){
    const human=humans.find(c=>c.player===i+1);
    const {engine,engineFilter,engineGain,exhaust,exhaustGain}=voices[i];
    const rawRpm = human ? (human.rpm ?? human.speed / 72) : 0;
    const rpm = Math.max(0, Math.min(1, rawRpm));
    const throttle = human?.previous?.gas ? 1 : 0;
    const boost = human?.boost > 0 ? 1 : 0;
    const firing = 32 + rpm * 100;
    engine.frequency.setTargetAtTime(firing, now, .055);
    engineFilter.frequency.setTargetAtTime(140 + rpm * 510 + throttle * 160 + boost * 230, now, .09);
    engineGain.gain.setTargetAtTime(human ? (.045 + rpm * .045 + throttle * .045)*mix : 0, now, .065);
    exhaust.frequency.setTargetAtTime(firing * .5, now, .055);
    exhaustGain.gain.setTargetAtTime(human ? (.025 + throttle * .04 + boost * .025)*mix : 0, now, .08);
    }
    const speed=Math.min(1,Math.max(0,...humans.map(c=>c.speed/85)));
    const weather=race?.track?.weather;
    const rain=weather==='rain',snow=weather==='snow';
    const ambience=rain&&humans.length ? .018 : 0;
    roadFilter.frequency.setTargetAtTime(350+speed*2300+(rain?650:snow?170:0),now,.12);
    roadGain.gain.setTargetAtTime(ambience+speed*speed*(rain?.095:snow?.070:.055),now,.1);

    const selection = running ? "race" : mode === "pause" ? null : ({
      intro: "title", result: "results", victory: "ending", complete: "ending"
    }[mode] || (motifs[mode] ? mode : "menu"));
    if (selection !== active) {
      active = selection;
      next = now + .03;
      step = 0;
    }
    if (!active || muted) return;
    if (next < now) next = now + .02;
    const song = motifs[active];
    const interval = 30 / song.bpm;
    while (next < now + .12) {
      schedule(song, next, step++, interval);
      next += interval;
    }
  }

  function effect(name) {
    if (!context || context.state !== "running" || muted) return;
    const key = aliases[name] || name;
    const spec = effects[key];
    if (!spec) return;
    const [from, to, length] = spec;
    const at = context.currentTime + .01;
    tone(at, from, to, length, .19, key === "collision" ? "triangle" : "square",effectBus);
    if (["collision", "nitro", "skid", "brake"].includes(key)) {
      percussion(at, key === "collision" ? 480 : 2300, length, .18,effectBus);
    }
  }

  globalThis.BGAudio = {
    start, update, effect,
    levels(music,effects) {
      musicLevel=music; effectLevel=effects;
      if(context){
        musicBus.gain.setTargetAtTime(music,context.currentTime,.025);
        effectBus.gain.setTargetAtTime(effects,context.currentTime,.025);
      }
    },
    get muted() { return muted; },
    set muted(value) {
      muted = Boolean(value);
      if (context) master.gain.setTargetAtTime(muted ? 0 : .52, context.currentTime, .025);
    }
  };
})();
