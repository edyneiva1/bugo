'use strict';
globalThis.BGPresentation=(()=>{
  const stage=document.querySelector('#stage'), display=document.querySelector('#screen');
  const panel=document.querySelector('#panel'), hud=document.querySelector('#race-hud');
  const make=(tag,cls,text)=>{
    const e=document.createElement(tag);
    if(cls)e.className=cls;
    if(text!==undefined)e.textContent=text;
    return e;
  };
  let scaleQuality={resolution:720,effects:true}, driverViews=[], displayedTrack;
  function fullscreen(){
    const op=document.fullscreenElement ? document.exitFullscreen?.() : document.documentElement.requestFullscreen?.();
    op?.catch(()=>{});
  }
  function configure(fit,quality){
    stage.dataset.fit=fit;
    scaleQuality=quality;
    resize();
  }
  function resize(){
    const r=stage.getBoundingClientRect();
    if(!r.width||!r.height)return;
    const limit=scaleQuality.resolution;
    const dpr=Math.min(devicePixelRatio||1,1.5);
    const scale=Math.min(dpr,limit/r.height,1920/r.width);
    const w=Math.max(2,Math.floor(r.width*scale/2)*2),h=Math.max(2,Math.floor(r.height*scale/2)*2);
    if(display.width!==w||display.height!==h){display.width=w;display.height=h;}
    const gl=document.querySelector('#screen-3d');
    if(gl.width!==w||gl.height!==h){gl.width=w;gl.height=h;}
  }
  new ResizeObserver(resize).observe(stage);
  function newCanvas(w=640,h=400){
    const e=make('canvas');e.width=w;e.height=h;return e;
  }
  function textPairs(parent,pairs){
    const dl=make('dl');
    for(const [label,value] of pairs)dl.append(make('dt','',label),make('dd','',String(value)));
    parent.append(dl);
  }
  function map(ctx,track,w,h,color='#ffa263',pad=15){
    ctx.lineJoin='round';
    ctx.lineCap='round';
    ctx.beginPath();
    track.map.forEach((p,i)=>ctx[i?'lineTo':'moveTo'](pad+p.x*(w-2*pad),pad+p.y*(h-2*pad)));
    ctx.strokeStyle='#060d17';ctx.lineWidth=Math.max(5,h*.04);ctx.stroke();
    ctx.strokeStyle=color;ctx.lineWidth=Math.max(2,h*.014);ctx.stroke();
  }
  function atlas(ctx,index){
    ctx.fillStyle='#102335';ctx.fillRect(0,0,640,400);
    ctx.strokeStyle='#436176';ctx.lineWidth=1;
    for(let x=0;x<640;x+=40){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,400);ctx.stroke();}
    for(let y=0;y<400;y+=40){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(640,y);ctx.stroke();}
    BGMenu.geography(ctx,0,0,index,0);
  }
  function aside(mode,opts){
    if(!['garage','garage-part','purchase','drivers','preview','regions','ready'].includes(mode))return;
    const a=make('aside','screen-aside'), cv=newCanvas(), c=cv.getContext('2d'), profile=opts.profile;
    const t=(pt,en)=>opts.lang?en:pt;
    if(mode==='preview'){
      const track=BGTracks.create(opts.track);
      map(c,track,640,400);
      textPairs(a,[[t('Distância','Distance'),(track.length/(opts.mph?1609.344:1000)).toFixed(2)+(opts.mph?' mi':' km')],
        [t('Voltas','Laps'),track.laps],[t('Pilotos','Drivers'),opts.profiles.map(p=>p.name).join(' / ')]]);
    }else if(mode==='regions'){
      c.save();c.scale(640/122,400/75);atlas(c,opts.region);c.restore();
      const labels=[t('Liberada','Unlocked'),t('Bloqueada','Locked')];
      textPairs(a,[[t('Acesso','Access'),labels[+(opts.region*4>opts.progress)]],
        [t('Circuitos concluídos','Cleared circuits'),Math.max(0,Math.min(4,opts.progress-opts.region*4))+' / 4']]);
    }else if(mode==='garage-part'||mode==='purchase'){
      const tier=mode==='purchase'?opts.tier:profile.parts[opts.slot];
      c.save();c.scale(6.4,6);BGMenu.part(c,0,3,opts.slot,tier);c.restore();
      textPairs(a,[[t('Instalado','Installed'),'N'+(profile.parts[opts.slot]+1)],
        [t('Créditos','Credits'),'$'+profile.money.toLocaleString(opts.lang?'en-US':'pt-BR')],
        ...BGParts.metrics(opts.slot,tier,profile.parts).map(([pt,en,v])=>[t(pt,en),v])]);
    }else{
      const g=c.createRadialGradient(320,260,30,320,240,285);
      g.addColorStop(0,'#304961');g.addColorStop(1,'#101a29');c.fillStyle=g;c.fillRect(0,0,640,400);
      const car={body:3,color:BGEngine.colors[profile.paint]};
      const draw=angle=>{
        if(BG3D.preview(cv,car,angle)){cv.dataset.renderer='webgl';return;}
        c.fillStyle=g;c.fillRect(0,0,640,400);
        BGRenderer.preview(c,car,60,42,520);
      };
      draw(.53);
      if(mode==='garage'&&cv.dataset.renderer==='webgl'){
        const views=make('div','garage-views');
        for(const [name,angle] of [[t('Traseira','Rear'),0],[t('Lateral','Side'),Math.PI/2],[t('Frente','Front'),Math.PI]]){
          const b=make('button','',name);
          b.type='button';b.onclick=()=>draw(angle);views.append(b);
        }
        a.append(views);
      }
      textPairs(a,[[t('Piloto','Driver'),profile.name],
        [t('Transmissão','Transmission'),profile.manual?t('Manual','Manual'):t('Automática','Automatic')],
        [t('Marchas','Gears'),BGParts.transmissions[profile.parts[6]].length],
        [t('Nitro inicial','Starting nitro'),BGParts.nitro[profile.parts[7]].stock],
        [t('Peças no máximo','Maxed parts'),profile.parts.filter(n=>n===3).length+' / '+profile.parts.length]]);
    }
    a.prepend(cv);
    return a;
  }
  function mount(mode,opts){
    stage.dataset.screen=mode;panel.dataset.view=mode;
    const items=[...panel.children], layout=make('div','screen-layout'), left=make('div','screen-main'), actions=make('div','action-list');
    let actionStarted=false;
    for(const item of items){
      if(item.tagName==='BUTTON'||item.tagName==='INPUT')actionStarted=true;
      if(item.tagName==='BUTTON'&&!item.disabled){
        const chevron=make('span','chevron','›');chevron.setAttribute('aria-hidden','true');item.append(chevron);
      }
      (actionStarted?actions:left).append(item);
    }
    if(mode==='title'){
      const h=left.querySelector('h1');
      const brand=make('span','wordmark-accent','BUGO');
      h.replaceChildren(brand,document.createTextNode(' GEAR 2'));
    }
    if(mode==='menu'){
      const h=left.querySelector('h2');
      h.textContent='BUGO GEAR 2';
    }
    left.append(actions);layout.append(left);
    const art=aside(mode,opts);
    if(art)layout.append(art);
    panel.append(layout);
    if(location.protocol!=='bugo-game:'){
      const fs=make('button','display-control',opts.lang?'Full screen':'Tela cheia');
      fs.type='button';fs.onclick=fullscreen;panel.append(fs);
    }
  }
  function addBar(parent,cls,label){
    const root=make('div',cls), caption=make('span','hud-label',label);
    const track=make('div','meter-track'), fill=make('i');
    track.append(fill);root.append(caption,track);parent.append(root);return {caption,fill};
  }
  function prepare(race,lang){
    hud.replaceChildren();hud.dataset.players=race.cars.filter(c=>c.player).length;
    const drivers=race.cars.filter(c=>c.player);
    displayedTrack=race.track;
    driverViews=drivers.map(c=>{
      const view=make('div','hud-view'), head=make('div','hud-head');
      const labels=lang?['Position','Lap','Time','Best lap']:['Posição','Volta','Tempo','Melhor volta'];
      const stats=labels.map((s,i)=>{
        const b=make('div','hud-stat'), v=make('strong','hud-value');
        b.append(make('span','hud-label',i===0?'P'+c.player+' · '+s:s),v);head.append(b);return v;
      });
      const gauges=make('div','hud-gauges'), speedRow=make('div','speed-row');
      const speed=make('strong','',0), unit=make('span','speed-unit'),gear=make('b','gear-chip');
      speedRow.append(speed,unit,gear);
      const rpmTrack=make('div','rpm-track'), rpm=make('i');rpmTrack.append(rpm);
      const aux=make('div','hud-aux'), nitro=addBar(aux,'nitro','Nitro'),fuel=addBar(aux,'fuel',lang?'Fuel':'Combustível');
      const damages=make('div','damage-icon'), parts=Array.from({length:3},()=>make('i'));
      damages.setAttribute('aria-label',lang?'Vehicle damage':'Danos no veículo');
      damages.append(...parts);aux.append(damages);gauges.append(speedRow,rpmTrack,aux);
      const mapBox=make('div','hud-map'), mapCanvas=newCanvas(200,160), background=newCanvas(200,160);
      map(background.getContext('2d'),race.track,200,160,'#bfd1e1',11);
      mapBox.append(mapCanvas);
      const alert=make('div','hud-alert');alert.hidden=true;
      view.append(head,gauges,mapBox,alert);hud.append(view);
      return {c,stats,speed,gear,unit,rpm,nitro,fuel,parts,m:mapCanvas.getContext('2d'),background,alert};
    });
  }
  function update(race,lang,mph){
    if(displayedTrack!==race.track || driverViews[0]?.c!==race.cars[0])prepare(race,lang);
    const rank=BGEngine.order(race), leader=rank[0];
    const text=(node,value)=>{const s=String(value);if(node.textContent!==s)node.textContent=s;};
    const fraction=(node,x)=>{node.style.transform='scaleX('+Math.max(0,Math.min(1,x))+')';};
    for(const v of driverViews){
      const c=v.c;
      text(v.stats[0],(rank.indexOf(c)+1)+' / '+race.cars.length);
      text(v.stats[1],Math.min(race.laps,Math.floor(Math.max(0,c.z)/race.track.length)+1)+' / '+race.laps);
      text(v.stats[2],(c.finish??c.retiredAt??Math.max(0,race.time)).toFixed(1)+' s');
      text(v.stats[3],c.bestLap===null?'—':c.bestLap.toFixed(1)+' s');
      text(v.speed,Math.round(c.speed*(mph?2.23694:3.6)));
      text(v.unit,mph?'MPH':'KM/H');text(v.gear,c.gear===0?'R':c.gear);
      text(v.nitro.caption,'Nitro '+c.nitro);text(v.fuel.caption,(lang?'Fuel ':'Combustível ')+Math.ceil(c.fuel)+'%');
      fraction(v.rpm,c.rpm);fraction(v.nitro.fill,c.nitro/c.kit.max);fraction(v.fuel.fill,c.fuel/100);
      c.damage.forEach((d,i)=>v.parts[i].style.setProperty('--damage',d>=100?'#313641':d>=65?'#ff7358':d>=30?'#ffd273':'#8dd2a1'));
      v.m.clearRect(0,0,200,160);v.m.drawImage(v.background,0,0);
      for(const car of new Set([leader,...driverViews.map(s=>s.c)])){
        const p=race.track.mapPoint(Math.max(0,car.z));
        v.m.beginPath();v.m.arc(11+p.x*178,11+p.y*138,car===c?6:4,0,Math.PI*2);
        v.m.fillStyle=car===c?'#ffac69':'#ebf7ff';v.m.fill();
      }
      const message=c.retired?(lang?'RETIRED':'FORA DA CORRIDA'):c.finish!==null?(lang?'FINISH':'CHEGADA'):
        race.time<0?String(Math.ceil(-race.time)):race.time<.8?(lang?'GO':'VAI'):'';
      text(v.alert,message);v.alert.hidden=!message;
    }
  }
  function screen(mode){
    stage.dataset.screen=mode;
    hud.hidden=mode!=='race';
  }
  return {configure,mount,screen,update,fullscreen};
})();
