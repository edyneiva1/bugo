'use strict';
globalThis.BGParts = (() => {
  const slot = Object.freeze({engine:0,dry:1,wet:2,front:3,rear:4,side:5,gearbox:6,nitro:7});
  const prices = [
    [0,30000,50000,80000],[0,1000,2000,4000],[0,1000,2000,3000],
    [0,5000,10000,20000],[0,5000,10000,20000],[0,5000,10000,20000],
    [0,10000,30000,50000],[0,5000,15000,30000]
  ];
  const transmissions = [[42.3,47.6,55.9,63],[28,38,47,57,69],[23,32,40,49,60,75],[18,26,34,43,52,64,81]];
  const nitro = [
    {stock:6,max:9,time:2.15,force:1},
    {stock:7,max:10,time:2.35,force:1.05},
    {stock:8,max:11,time:2.55,force:1.1},
    {stock:9,max:12,time:2.75,force:1.15}
  ];
  return {slot,prices,transmissions,nitro};
})();
