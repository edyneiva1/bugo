'use strict';
globalThis.BGParts = (() => {
  const slot = Object.freeze({engine:0,dry:1,wet:2,front:3,rear:4,side:5,gearbox:6,nitro:7,brakes:8,suspension:9,fuel:10});
  const prices = [
    [0,30000,50000,80000],[0,1000,2000,4000],[0,1000,2000,3000],
    [0,5000,10000,20000],[0,5000,10000,20000],[0,5000,10000,20000],
    [0,10000,30000,50000],[0,5000,15000,30000],
    [0,3500,8500,16000],[0,4500,10000,20000],[0,4000,9000,18000]
  ];
  const transmissions = [[42.3,47.6,55.9,63],[28,38,47,57,69],[23,32,40,49,60,75],[18,26,34,43,52,64,81]];
  const nitro = [
    {stock:6,max:9,time:2.15,force:1},
    {stock:7,max:10,time:2.35,force:1.05},
    {stock:8,max:11,time:2.55,force:1.1},
    {stock:9,max:12,time:2.75,force:1.15}
  ];
  const brakeDeceleration = tier => 25 + tier * 2.2;
  // Values derived from the existing simulation, not estimated horsepower or speed tests.
  function metrics(index,tier,parts=[]) {
    const engine=index===slot.engine?tier:(parts[slot.engine]||0);
    const gearbox=index===slot.gearbox?tier:(parts[slot.gearbox]||0);
    const speed=Math.round((transmissions[gearbox].at(-1)+engine*2)*3.6);
    switch(index){
      case 0:return [['Limite teórico','Theoretical cap',speed+' km/h'],['Impulso adicional','Extra drive',(tier*.7).toFixed(1)+' m/s²']];
      case 1:return [['Aderência seca','Dry grip',(.93+tier*.07).toFixed(2)]];
      case 2:return [['Aderência chuva','Rain grip',(.72+tier*.08).toFixed(2)],['Aderência neve','Snow grip',(.58+tier*.08).toFixed(2)]];
      case 3:case 4:case 5:return [['Redução de dano recebido','Incoming damage reduction',Math.round(100*(1-1/(1+tier*.55)))+'%']];
      case 6:return [['Marchas','Gears',String(transmissions[tier].length)],['Limite teórico','Theoretical cap',speed+' km/h']];
      case 7:return [['Cargas iniciais','Starting charges',String(nitro[tier].stock)],['Duração','Duration',nitro[tier].time.toFixed(2)+' s']];
      case 8:return [['Força de frenagem','Braking force',brakeDeceleration(tier).toFixed(1)+' m/s²']];
      case 9:return [['Aderência adicional','Extra grip',(tier*.035).toFixed(3)]];
      case 10:return [['Economia de combustível','Fuel savings',tier*8+'%']];
      default:return [];
    }
  }
  return {slot,prices,transmissions,nitro,brakeDeceleration,metrics};
})();
