'use strict';
globalThis.BGChampionship = (() => {
  const pointsByPlace = [10,6,4,3,2,1];
  const prizes = [10000,6000,4000,3000,2000,1000];
  const settled = new WeakMap();
  const partPrice = (slot,level) => BGParts.prices[slot]?.[level+1];
  function buyPart(profile, slot, upgrade = profile.parts[slot]+1) {
    const level = profile.parts[slot];
    const price=BGParts.prices[slot]?.[upgrade];
    if (!Number.isInteger(level) || !price || upgrade<=level || profile.money<price) return false;
    profile.money -= price;
    profile.parts[slot]=upgrade;
    return true;
  }
  const name = (state,c) => c.player ? state.profiles[c.id].name : 'CPU '+String(c.id+1).padStart(2,'0');
  function settle(state, race) {
    if (settled.has(race)) return settled.get(race);
    if (state.track !== race.track.index) throw Error('Race does not match the championship stage');
    const order = BGEngine.order(race);
    const players = race.cars.filter(c => c.player);
    const qualified = players.some(c => c.finish !== null && order.indexOf(c) < 10);
    const results = order.map((c,i) => {
      const p=c.player ? state.profiles[c.id] : null;
      const points=qualified && c.finish!==null ? pointsByPlace[i] || 0 : 0;
      const prize=c.finish!==null ? prizes[i] || 0 : 0;
      if(p) {
        p.points+=points; p.money+=prize+c.cash;
        if(c.finish!==null && c.finish<(state.records[state.track] || Infinity)) state.records[state.track]=c.finish;
      } else if (qualified) state.rivals[c.id]=(state.rivals[c.id] || 0)+points;
      return {name:name(state,c),place:i+1,time:c.finish,points,prize,player:c.player,total:p?.points ?? (state.rivals[c.id]||0)};
    });
    if (qualified) state.track++;
    const result={qualified,drivers:results.filter(c=>c.player),results};
    settled.set(race,result);
    return result;
  }
  return {settle,partPrice,buyPart};
})();
