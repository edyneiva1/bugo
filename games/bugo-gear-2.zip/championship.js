'use strict';
globalThis.BGChampionship = (() => {
  const pointsByPlace = [10,6,4,3,2,1];
  const prizes = [10000,6000,4000,3000,2000,1000];
  const settled = new WeakMap();
  const partPrice = (slot,level) => BGParts.prices[slot]?.[level+1];
  function buyPart(profile, slot, upgrade = profile.parts[slot]+1) {
    const level = profile.parts[slot];
    const price=BGParts.prices[slot]?.[upgrade];
    if (!Number.isInteger(level) || !price || upgrade<=level || profile.money<price) return false;
    profile.money -= price;
    profile.parts[slot]=upgrade;
    return true;
  }
  const name = (state,c) => c.player ? state.profiles[c.id].name : 'CPU '+String(c.id+1).padStart(2,'0');
  function settle(state, race) {
    if (settled.has(race)) return settled.get(race);
    if (state.track !== race.track.index) throw Error('Race does not match the championship stage');
    const order = BGEngine.order(race);
    const players = race.cars.filter(c => c.player);
    const qualified = players.some(c => c.finish !== null && order.indexOf(c) < 10);
    const results = order.map((c,i) => {
      const p=c.player ? state.profiles[c.id] : null;
      const points=qualified && c.finish!==null ? pointsByPlace[i] || 0 : 0;
      const prize=c.finish!==null ? prizes[i] || 0 : 0;
      if(p) {
        p.points+=points; p.money+=prize+c.cash;
        if(c.finish!==null && c.finish<(state.records[state.track] || Infinity)) state.records[state.track]=c.finish;
      } else if (qualified) state.rivals[c.id]=(state.rivals[c.id] || 0)+points;
      return {name:name(state,c),place:i+1,time:c.finish,points,prize,player:c.player,total:p?.points ?? (state.rivals[c.id]||0)};
    });
    if (qualified) {
      state.regional ??= {};
      const row=Array(21).fill(null);
      order.forEach((c,i)=>{row[c.player===2?20:c.id]=results[i].points;});
      state.regional[state.track]=row;
      state.track++;
    }
    const result={qualified,drivers:results.filter(c=>c.player),results};
    settled.set(race,result);
    return result;
  }
  function regional(state,region) {
    if(!Number.isInteger(region)||region<0||region>=16) throw Error('Invalid region');
    const start=region*4, totals=Array(21).fill(null);
    let recorded=0;
    for(let i=start;i<start+4;i++) {
      const row=state.regional?.[i];
      if(row){recorded++;row.forEach((points,id)=>{if(points!==null)totals[id]=(totals[id]??0)+points;});}
    }
    return {recorded, completed:Math.max(0,Math.min(4,state.track-start)), rows:totals.map((points,id)=>({id,points})).filter(r=>r.points!==null).sort((a,b)=>b.points-a.points||a.id-b.id)};
  }
  return {settle,partPrice,buyPart,regional};
})();
