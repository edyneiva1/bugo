'use strict';
globalThis.BGMenu=(()=>{
  const colors={ink:'#101522',paper:'#eef1de',gold:'#ffb954',mint:'#73d0bd',steel:'#778ba0',panel:'#202d42'};
  const b=(c,k,x,y,w,h)=>{c.fillStyle=k;c.fillRect(Math.round(x),Math.round(y),Math.round(w),Math.round(h));};
  function text(c,label,x,y,size=9,color=colors.paper,align='left'){
    c.font='bold '+size+'px monospace';c.textBaseline='top';c.textAlign=align;c.fillStyle=color;
    c.fillText(label,x,y);
  }
  function poly(c,k,list){
    c.fillStyle=k;c.beginPath();c.moveTo(...list[0]);
    for(const p of list.slice(1))c.lineTo(...p);
    c.closePath();c.fill();
  }
  const land=[
    [[3,16],[12,7],[26,8],[41,4],[49,12],[42,24],[35,28],[31,40],[23,38],[18,30],[10,26]],
    [[32,40],[48,44],[49,54],[44,66],[36,74],[31,61],[29,51]],
    [[50,15],[58,10],[67,15],[74,10],[94,10],[112,16],[119,26],[107,30],[103,38],[89,37],[81,32],[76,42],[63,36],[53,28]],
    [[58,32],[73,35],[78,47],[72,62],[65,65],[60,55],[56,44]],
    [[88,52],[100,41],[111,46],[116,56],[109,64],[97,64]]];
  const pins=[[102,58],[63,20],[70,44],[22,22],[65,18],[106,52],[66,12],[67,44],[45,55],[82,22],[39,53],[105,26],[40,60],[48,14],[17,29],[65,10]];
  function geography(c,x,y,index,time){
    b(c,'#17283d',x,y,122,75);
    for(let v=9;v<75;v+=9)b(c,'#28425a',x,y+v,122,1);
    for(let u=0;u<122;u+=11)b(c,'#28425a',x+u,y,1,75);
    land.forEach((shape,i)=>poly(c,['#548989','#488183','#5b9393'][i%3],shape.map(([u,v])=>[x+u,y+v])));
    const [u,v]=pins[index];
    b(c,colors.gold,x+u-2,y+v-2,5,5);
    if(Math.floor(time*6)%2)c.strokeStyle=colors.gold,c.strokeRect(x+u-5.5,y+v-5.5,11,11);
  }
  function part(c,x,y,slot,tier){
    const metal=['#5a6a7d','#758a9e','#9caab5','#d2dbe1'][tier];
    const hi=colors.paper, dark='#343950', accent=['#51aaa1','#f2ab57','#ec7969','#f4d483'][tier];
    c.save();c.translate(x,y);
    for(let i=0;i<8;i++)b(c,'#233850',5,7+i*6,92,1);
    if(slot===1||slot===2){
      poly(c,dark,[[38,4],[62,5],[77,16],[78,44],[65,53],[38,52],[23,39],[23,16]]);
      poly(c,metal,[[41,9],[60,10],[70,20],[70,40],[62,48],[41,47],[33,37],[33,19]]);
      poly(c,dark,[[44,16],[57,16],[63,23],[63,36],[56,42],[45,41],[40,34],[40,24]]);
      for(let i=0;i<6+tier;i++)b(c,i%2?accent:hi,25+i%3*2,13+i*4,6,2);
      if(slot===2)for(let i=0;i<4;i++)b(c,'#8dcefc',65,21+i*5,4,1);
    }else if(slot===7){
      for(let j=0;j<1+Math.floor(tier/2);j++){
        const u=30+j*27;
        poly(c,metal,[[u,12],[u+5,7],[u+18,7],[u+23,12],[u+23,44],[u+17,48],[u+6,48],[u,43]]);
        b(c,dark,u+8,2,8,6);b(c,hi,u+4,15,2,24);b(c,accent,u+2,24,19,7);
        text(c,'N',u+8,24,7,dark);
      }
    }else if(slot===6){
      poly(c,metal,[[17,20],[42,20],[53,12],[73,12],[84,22],[83,39],[70,45],[51,43],[38,36],[17,36]]);
      for(let i=0;i<4+tier;i++)b(c,i%2?accent:hi,49+(i%3)*8,17+Math.floor(i/3)*7,5,3);
      for(let i=0;i<7;i++)b(c,dark,19+i*3,23,1,11);
    }else if(slot>=3){
      const slant=(slot-4)*7;
      poly(c,dark,[[17,37],[27+slant,17],[76+slant,12],[86,26],[75,43],[25,45]]);
      poly(c,metal,[[20,35],[29+slant,20],[74+slant,15],[82,26],[73,38],[25,41]]);
      poly(c,accent,[[29,32],[70+slant,19],[77,24],[32,37]]);
      for(let i=0;i<=tier;i++)b(c,hi,29+i*11,34-i*2,3,2);
    }else{
      poly(c,dark,[[17,34],[21,19],[36,13],[75,18],[88,30],[83,45],[29,48]]);
      poly(c,metal,[[25,23],[40,16],[73,20],[83,28],[75,35],[30,37]]);
      for(let i=0;i<4+tier;i++)b(c,i%2?hi:accent,27+i*7,21+(i%2)*3,6,8);
      for(let i=0;i<6;i++)b(c,'#a9b6ba',37+i*6,35+(i%2)*2,3,8);
      b(c,dark,20,39,13,7);
    }
    for(let i=0;i<4;i++)b(c,i<=tier?accent:'#3c4c65',24+i*15,57,12,3);
    c.restore();
  }
  return {part,geography};
})();
