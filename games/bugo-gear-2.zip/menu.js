'use strict';
globalThis.BGMenu=(()=>{
  let rows=[],scroll=0,previous='',focused;
  const colors={ink:'#101522',paper:'#eef1de',gold:'#ffb954',mint:'#73d0bd',steel:'#778ba0',panel:'#202d42'};
  const b=(c,k,x,y,w,h)=>{c.fillStyle=k;c.fillRect(Math.round(x),Math.round(y),Math.round(w),Math.round(h));};
  function text(c,label,x,y,size=9,color=colors.paper,align='left'){
    c.font='bold '+size+'px monospace';c.textBaseline='top';c.textAlign=align;c.fillStyle=color;
    c.fillText(label,x,y);
  }
  function poly(c,k,list){
    c.fillStyle=k;c.beginPath();c.moveTo(...list[0]);
    for(const p of list.slice(1))c.lineTo(...p);
    c.closePath();c.fill();
  }
  function logo(c,x,y,size){
    c.save();c.translate(x,y);c.transform(1,0,-.18,1,0,0);
    for(let i=0;i<3;i++)b(c,['#ed705f','#efaa59','#6bd4c0'][i],-15,8+i*4,13,2);
    text(c,'BUGO GEAR 2',2,3,size,'#0a1120');
    text(c,'BUGO GEAR 2',0,0,size,'#eaf2de');
    b(c,'#f5b457',0,size+3,size*6.52,2);
    c.restore();
  }
  function landscape(c,time,full){
    const colors=['#253f65','#375783','#516e9c','#688eab','#93b7bf','#ecc595'];
    colors.forEach((k,i)=>b(c,k,0,i*20,256,21));
    for(let i=0;i<65;i++)b(c,i%2?'#a9c1bd':'#728dac',(i*47)%256,25+(i*31)%76,2,1);
    poly(c,'#f5c78b',[[170,45],[196,45],[203,52],[203,71],[196,78],[170,78],[163,71],[163,52]]);
    for(let n=0;n<2;n++) {
      const crest=[[0,111]];
      for(let x=0;x<=256;x+=8)crest.push([x,86+n*15+Math.sin(x*.06+n)*8+Math.cos(x*.11+n)*9]);
      poly(c,n?'#294c58':'#51647c',[...crest,[256,147],[0,147]]);
    }
    for(let i=0;i<36;i++) {
      const x=i*8-5,h=4+i*13%21;
      b(c,i%2?'#273e53':'#354b62',x,124-h,6,h+5);
      for(let y=126-h;y<120;y+=4)if((i+y)%3)b(c,'#dbbd83',x+2,y,1,1);
    }
    for(let y=125;y<224;y++){
      const span=(y-119)*1.32, phase=Math.floor((y-122)*.13+time*(full?9:3));
      const center=128+Math.sin(time*.5)*(y-125)*.17;
      b(c,phase%2?'#304f55':'#395b5c',0,y,256,1);
      b(c,phase%3?'#bb786b':'#e8d2ae',center-span-3,y,span*2+6,1);
      b(c,phase%2?'#434557':'#494c60',center-span,y,span*2,1);
      if(phase%3===0)b(c,'#e4d1b0',center-1,y,2,1);
    }
  }
  function keyline(c,x,y,w,h){
    b(c,'#101827',x,y,w,h);b(c,'#2b3d55',x+1,y+1,w-2,h-2);
    b(c,'#7096a3',x+1,y+1,w-2,1);b(c,'#4a7183',x+1,y+h-2,w-2,1);
    for(const n of [0,w-4])b(c,colors.gold,x+n,y,4,2);
  }
  function route(c,track,x,y,w,h){
    const points=track.map;
    c.strokeStyle='#081927';c.lineWidth=5;c.beginPath();
    points.forEach((p,i)=>c[i?'lineTo':'moveTo'](x+p.x*w,y+p.y*h));c.stroke();
    c.strokeStyle=colors.mint;c.lineWidth=2;c.stroke();
    b(c,colors.gold,x+points[0].x*w-2,y+points[0].y*h-2,5,5);
  }
  const land=[
    [[3,16],[12,7],[26,8],[41,4],[49,12],[42,24],[35,28],[31,40],[23,38],[18,30],[10,26]],
    [[32,40],[48,44],[49,54],[44,66],[36,74],[31,61],[29,51]],
    [[50,15],[58,10],[67,15],[74,10],[94,10],[112,16],[119,26],[107,30],[103,38],[89,37],[81,32],[76,42],[63,36],[53,28]],
    [[58,32],[73,35],[78,47],[72,62],[65,65],[60,55],[56,44]],
    [[88,52],[100,41],[111,46],[116,56],[109,64],[97,64]]];
  const pins=[[102,58],[63,20],[70,44],[22,22],[65,18],[106,52],[66,12],[67,44],[45,55],[82,22],[39,53],[105,26],[40,60],[48,14],[17,29],[65,10]];
  function geography(c,x,y,index,time){
    b(c,'#17283d',x,y,122,75);
    for(let v=9;v<75;v+=9)b(c,'#28425a',x,y+v,122,1);
    for(let u=0;u<122;u+=11)b(c,'#28425a',x+u,y,1,75);
    land.forEach((shape,i)=>poly(c,['#548989','#488183','#5b9393'][i%3],shape.map(([u,v])=>[x+u,y+v])));
    const [u,v]=pins[index];
    b(c,colors.gold,x+u-2,y+v-2,5,5);
    if(Math.floor(time*6)%2)c.strokeStyle=colors.gold,c.strokeRect(x+u-5.5,y+v-5.5,11,11);
  }
  function part(c,x,y,slot,tier){
    const metal=['#5a6a7d','#758a9e','#9caab5','#d2dbe1'][tier];
    const hi=colors.paper, dark='#343950', accent=['#51aaa1','#f2ab57','#ec7969','#f4d483'][tier];
    c.save();c.translate(x,y);
    for(let i=0;i<8;i++)b(c,'#233850',5,7+i*6,92,1);
    if(slot===1||slot===2){
      poly(c,dark,[[38,4],[62,5],[77,16],[78,44],[65,53],[38,52],[23,39],[23,16]]);
      poly(c,metal,[[41,9],[60,10],[70,20],[70,40],[62,48],[41,47],[33,37],[33,19]]);
      poly(c,dark,[[44,16],[57,16],[63,23],[63,36],[56,42],[45,41],[40,34],[40,24]]);
      for(let i=0;i<6+tier;i++)b(c,i%2?accent:hi,25+i%3*2,13+i*4,6,2);
      if(slot===2)for(let i=0;i<4;i++)b(c,'#8dcefc',65,21+i*5,4,1);
    }else if(slot===7){
      for(let j=0;j<1+Math.floor(tier/2);j++){
        const u=30+j*27;
        poly(c,metal,[[u,12],[u+5,7],[u+18,7],[u+23,12],[u+23,44],[u+17,48],[u+6,48],[u,43]]);
        b(c,dark,u+8,2,8,6);b(c,hi,u+4,15,2,24);b(c,accent,u+2,24,19,7);
        text(c,'N',u+8,24,7,dark);
      }
    }else if(slot===6){
      poly(c,metal,[[17,20],[42,20],[53,12],[73,12],[84,22],[83,39],[70,45],[51,43],[38,36],[17,36]]);
      for(let i=0;i<4+tier;i++)b(c,i%2?accent:hi,49+(i%3)*8,17+Math.floor(i/3)*7,5,3);
      for(let i=0;i<7;i++)b(c,dark,19+i*3,23,1,11);
    }else if(slot>=3){
      const slant=(slot-4)*7;
      poly(c,dark,[[17,37],[27+slant,17],[76+slant,12],[86,26],[75,43],[25,45]]);
      poly(c,metal,[[20,35],[29+slant,20],[74+slant,15],[82,26],[73,38],[25,41]]);
      poly(c,accent,[[29,32],[70+slant,19],[77,24],[32,37]]);
      for(let i=0;i<=tier;i++)b(c,hi,29+i*11,34-i*2,3,2);
    }else{
      poly(c,dark,[[17,34],[21,19],[36,13],[75,18],[88,30],[83,45],[29,48]]);
      poly(c,metal,[[25,23],[40,16],[73,20],[83,28],[75,35],[30,37]]);
      for(let i=0;i<4+tier;i++)b(c,i%2?hi:accent,27+i*7,21+(i%2)*3,6,8);
      for(let i=0;i<6;i++)b(c,'#a9b6ba',37+i*6,35+(i%2)*2,3,8);
      b(c,dark,20,39,13,7);
    }
    for(let i=0;i<4;i++)b(c,i<=tier?accent:'#3c4c65',24+i*15,57,12,3);
    c.restore();
  }
  function render(c,panel,mode,time,opt={}){
    if(mode!==previous){scroll=0;previous=mode;focused=null;}
    rows=[];c.imageSmoothingEnabled=false;
    landscape(c,time,mode==='title');
    const age=opt.age;
    if(mode==='title'){
      if(age<.72){
        b(c,colors.ink,0,0,256,224);
        for(let i=0;i<5;i++)b(c,i%2?colors.gold:colors.mint,64+i*6,103+i*3,28,2);
        text(c,'BUGO',141,99,21,colors.paper,'center');
      }else{
        const w=Math.min(143,56+(age-.72)*65);
        const x=128-w/2+Math.sin(time*1.2)*7;
        b(c,'#362e3d',x+4,187,w-8,3);
        BGRenderer.preview(c,{color:'#de5f55',body:3},x,188-w*.58,w);
        logo(c,20+Math.max(0,1.55-age)*60,30,29);
        if(Math.floor(time*4)%4!==3)text(c,opt.lang?'PRESS START':'PRESSIONE START',128,202,10,colors.paper,'center');
      }
      rows.push({element:panel.querySelector('button'),x:0,y:0,w:256,h:224});
      return;
    }
    if(mode==='menu'){
      logo(c,20,21,28);
      keyline(c,14,67,145,140);
      BGRenderer.preview(c,{color:'#de5f55',body:3},147,125,103);
      const buttons=[...panel.querySelectorAll('button')];
      buttons.forEach((element,i)=>{
        const y=84+i*27,active=element===document.activeElement;
        if(active){b(c,'#34546a',20,y-3,131,21);poly(c,colors.gold,[[21,y+1],[28,y+5],[21,y+9]]);}
        text(c,element.textContent,34,y,11,active?colors.gold:colors.paper);
        rows.push({element,x:18,y:y-5,w:134,h:23});
      });
      return;
    }
    keyline(c,8,9,240,206);
    b(c,'#32465d',10,10,236,24);
    const children=[...panel.children];
    const title=children[0]?.tagName.match(/^H[12]$/)?children.shift():null;
    if(title)text(c,title.textContent,17,17,title.textContent.length>27?9:12,colors.gold);
    const split=['regions','preview','garage-part','purchase','drivers','garage'].includes(mode);
    const width=split?126:219, artX=145;
    if(mode==='regions')geography(c,123,48,opt.region,time);
    if(mode==='preview'){
      const track=BGTracks.create(opt.track);
      route(c,track,artX,41,93,82);
      text(c,'08:30',191,124,13,colors.gold,'center');
      opt.profiles.forEach((p,i)=>text(c,'P'+(i+1)+' '+p.name,artX,147+i*13,8,colors.paper));
    }
    if(['garage-part','purchase'].includes(mode))part(c,artX,43,opt.slot,mode==='purchase'?opt.tier:opt.level);
    if(['garage','drivers'].includes(mode))BGRenderer.preview(c,{color:BGEngine.colors[opt.paint],body:3},152,53,81);
    const height=e=>e.tagName==='BUTTON'||e.tagName==='INPUT'?16:12;
    const stack=children.map((element,i)=>({element,i,h:height(element)}));
    const select=stack.findIndex(r=>r.element===document.activeElement);
    if(select>=0&&focused!==document.activeElement){
      scroll=Math.min(scroll,select);
      while(stack.slice(scroll,select+1).reduce((sum,r)=>sum+r.h,0)>171)scroll++;
    }
    focused=document.activeElement;
    scroll=Math.min(scroll,Math.max(0,stack.length-1));
    let y=40;
    for(const r of stack.slice(scroll)){
      if(y+r.h>210)break;
      const e=r.element,input=e.tagName==='INPUT',button=e.tagName==='BUTTON';
      const active=focused===e;
      if(active)b(c,'#3b6174',15,y-1,width,r.h-1);
      if(button||input){
        rows.push({...r,x:15,y:y-1,w:width});
        if(active)poly(c,colors.gold,[[16,y+2],[21,y+5],[16,y+8]]);
        else b(c,'#688395',16,y+4,2,2);
      }
      if(!input||!active){
        const label=input?e.getAttribute('aria-label')+' '+e.value:e.textContent;
        const maximum=split?23:40, words=label.split(' ');
        let labelText=label;
        if(label.length>maximum){
          while(words.join(' ').length>maximum&&words.length>1)words.pop();
          labelText=words.join(' ').slice(0,maximum)+'…';
        }
        text(c,labelText,button||input?24:17,y+2,split?7:9,e.disabled?'#94a7b6':active?colors.gold:colors.paper);
      }
      if(input){
        e.style.left='9%';e.style.top=(y/224*100)+'%';e.style.width=(width-16)/256*100+'%';e.style.visibility='visible';
      }
      y+=r.h;
    }
    for(const e of panel.querySelectorAll('input'))if(!rows.some(r=>r.element===e))e.style.visibility='hidden';
    if(scroll>0)text(c,'▲',233,40,8,colors.gold);
    if(y<210&&stack.slice(scroll).reduce((n,r)=>n+r.h,40)>210)text(c,'▼',233,201,8,colors.gold);
  }
  function activate(x,y){
    const e=rows.find(r=>x>=r.x&&x<r.x+r.w&&y>=r.y&&y<r.y+r.h)?.element;
    if(e&&!e.disabled){e.focus();if(e.tagName!=='INPUT')e.click();}
  }
  return {render,activate,move:delta=>{scroll=Math.max(0,scroll+Math.sign(delta));}};
})();
