'use strict';
(() => {
  const canvas = document.querySelector('#screen'), panel = document.querySelector('#panel');
  const keys=new Set(),pressed=new Set(),raceEdges=new Set(),pads=[];
  const translations = (pt,en) => state.lang ? en : pt;
  const t = translations;
  let state = BGSave.load(), mode = 'title', race, menuPlayer = 0, message = '', last = 0, accumulator = 0, outcome;
  let remap = null, controlPlayer = 0, menuSlot = 0, resultPage=0, ready=0, regionIndex=0, purchaseTier=0;
  const actions=BGControls.actions;
  const presets={
    economy:{resolution:540,effects:false},balanced:{resolution:720,effects:true},high:{resolution:1080,effects:true}
  };
  let regionalIndex=0, regionalReturn='menu', bindingIndex=0, quickTrack=null, previewReturn='menu', garageReturn='menu', settingsReturn='options', standingsReturn='menu', codeReturn='menu';
  const quality=()=>presets[state.quality]||state.customQuality;
  function poll(){
    try{return Array.from(navigator.getGamepads?.()||[]).filter(Boolean);}
    catch{return [];}
  }
  function control(i,games){
    const a=BGControls.keys(state,i,keys),p=games[i],down=n=>!!p?.buttons[n]?.pressed;
    const bindings=BGControls.config(state,i);
    for(const j of [4,5,6,8])a[actions[j]]||=bindings[j].some(k=>raceEdges.has(k));
    a.gas||=down(7)||down(0)||down(3);
    a.brake||=down(6)||down(1);
    a.boost||=down(2);a.up||=down(5);a.down||=down(4);a.handbrake||=down(10);
    a.camera||=down(8);a.lookBack||=down(11);
    a.steer=Number(a.right||down(15))-Number(a.left||down(14));
    const axis=p?.axes[0]||0,dz=state.deadzone[i];
    if(!a.steer&&Math.abs(axis)>dz)a.steer=Math.max(-1,Math.min(1,Math.sign(axis)*(Math.abs(axis)-dz)/(1-dz)*state.sensitivity[i]));
    return a;
  }
  function add(tag,text) {
    const element = document.createElement(tag);
    element.textContent = text;
    panel.append(element);
    return element;
  }
  function button(label,action) {
    const element = add('button',label);
    element.onclick = () => {BGAudio.start(); BGAudio.effect('confirm'); action();};
    return element;
  }
  function input(value, label, limit) {
    const element = add('input','');
    element.value = value; element.maxLength = limit; element.setAttribute('aria-label',label);
    return element;
  }
  function save() { BGSave.save(state); }
  function change(action) { action(); save(); show(mode); }
  function show(next) {
    mode = next; panel.replaceChildren(); panel.hidden = mode === 'race';
    document.documentElement.lang = state.lang ? 'en' : 'pt-BR';
    BGPresentation.screen(mode);
    BGPresentation.configure(state.fit,quality());
    BGAudio.muted = state.muted;
    BGAudio.levels(state.music,state.effects);
    if(mode==='race'){canvas.focus();return;}
    if(menuPlayer>=state.players)menuPlayer=0;
    document.querySelector('#screen-3d').hidden=true;
    if (mode === 'title') {
      add('h1','BUGO GEAR 2');
      button(t('PRESSIONE START','PRESS START'),() => show('menu'));
    }
    if (mode === 'menu') {
      add('h2',t('PIT LANE','PIT LANE'));
      button(state.track===64?t('Classificação','Standings'):t('Campeonato','Championship'),
        ()=>{quickTrack=null;previewReturn='menu';show(state.track===64?'ending':'preview');});
      button(t('Corrida rápida','Quick race'),()=>{quickTrack=Math.min(63,state.track);show('quick');});
      button(t('Regiões','Regions'),()=>{regionIndex=Math.min(15,state.track>>2);show('regions');});
      button(t('Garagem','Garage'),()=>{garageReturn='menu';show('garage');});
      button(t('Classificação geral','Championship standings'),()=>{standingsReturn='menu';show('standings');});
      button(t('Classificação regional','Regional standings'),()=>{regionalIndex=Math.min(15,state.track>>2);regionalReturn='menu';show('regional');});
      button(t('Continuar por código','Continue with code'),()=>{codeReturn=mode;show('code');});
      button(t('Configuração','Settings'),()=>show('options'));
    }
    if (mode === 'preview') {
      const track=BGTracks.create(quickTrack??state.track);
      const conditions = {
        clear:t('Céu limpo','Clear'),rain:t('Chuva','Rain'),snow:t('Neve','Snow'),fog:t('Neblina','Fog'),night:t('Noite','Night')
      };
      const distance = (track.length / (state.mph ? 1609.344 : 1000)).toFixed(2);
      add('h2',track.name[state.lang]);
      add('p',track.laps+' '+t('voltas','laps')+' · '+distance+' '+(state.mph ? 'mi' : 'km'));
      add('small',conditions[track.weather]);
      if(state.records[track.index])add('p',t('Recorde da prova','Race record')+' · '+state.records[track.index].toFixed(2)+' s');
      add('p',quickTrack===null?t('Campeonato · prova ','Championship · race ')+(track.stage+1)+'/4':t('Treino · sem prêmios ou pontos','Practice · no prizes or points'));
      add('p',t('Distância total','Total distance')+' · '+(track.length*track.laps/(state.mph?1609.344:1000)).toFixed(2)+' '+(state.mph?'mi':'km'));
      add('p',t('Pneus recomendados: ','Recommended tires: ')+(['rain','snow'].includes(track.weather)?t('chuva/neve','wet/snow'):t('secos','dry')));
      button(t('Preparar pilotos','Driver setup'),()=>{settingsReturn='preview';show('drivers');});
      button(t('Largada','Start race'),() => {ready=0;state.players===2 ? show('ready') : start();});
      button(t('Garagem','Garage'),()=>{garageReturn='preview';show('garage');});
      button(t('Voltar','Back'),() => show(previewReturn));
    }
    if(mode==='quick'){
      add('h2',t('CORRIDA RÁPIDA','QUICK RACE'));
      add('p',BGTracks.create(quickTrack).name[state.lang]);
      const max=Math.min(63,state.track);
      button(t('Pista anterior','Previous circuit'),()=>{quickTrack=(quickTrack+max)%(max+1);show('quick');});
      button(t('Próxima pista','Next circuit'),()=>{quickTrack=(quickTrack+1)%(max+1);show('quick');});
      button(t('Selecionar','Select'),()=>{previewReturn='quick';show('preview');});
      button(t('Voltar','Back'),()=>{quickTrack=null;show('menu');});
    }
    if(mode==='ready'){
      add('h2',t('CONFIRMAÇÃO','READY CHECK'));
      add('p','P'+(ready+1)+' · '+state.profiles[ready].name);
      button(t('Confirmar piloto','Confirm driver'),()=>{if(++ready===2)start();else show('ready');});
      button(t('Voltar','Back'),()=>show('preview'));
    }
    if(mode==='regions'){
      const name=BGTracks.create(regionIndex*4).name[state.lang].split(' / ')[0];
      const unlocked=regionIndex*4<=state.track;
      add('h2',name);
      add('p',unlocked?t('REGIÃO LIBERADA · treino sem alterar campeonato','REGION UNLOCKED · practice without changing championship'):t('REGIÃO BLOQUEADA','REGION LOCKED'));
      for(let i=0;i<4;i++){
        const id=regionIndex*4+i;
        const label=(id<state.track?'✓ ':id===state.track?'◆ ':'· ')+BGTracks.create(id).name[state.lang].split(' / ')[1];
        if(id<=state.track)button(label,()=>{quickTrack=id;previewReturn='regions';show('preview');});else add('small',label);
      }
      button(t('Anterior','Previous'),()=>{regionIndex=(regionIndex+15)%16;show('regions');});
      button(t('Próxima','Next'),()=>{regionIndex=(regionIndex+1)%16;show('regions');});
      button(t('Voltar','Back'),()=>show('menu'));
    }
    if (mode === 'reset') {
      add('h2',t('Reiniciar campeonato?','Restart championship?'));
      button(t('Confirmar','Confirm'),() => {
        const fresh = BGSave.defaults();
        state.track = 0;
        state.rivals={};state.regional={};
        state.profiles.forEach((p,i) => {p.points = 0; p.money = 0; p.parts = fresh.profiles[i].parts;});
        save(); show('menu');
      });
      button(t('Cancelar','Cancel'),() => show('menu'));
    }
    if (mode==='options') {
      add('h2',t('CONFIGURAÇÃO','SETTINGS'));
      button(t('Pilotos e prova','Drivers & race'),()=>{settingsReturn='options';show('drivers');});
      button(t('Controles','Controls'),()=>show('controls'));
      button(t('Áudio e exibição','Sound & display'),()=>show('system'));
      button(t('Continuação','Continue code'),()=>{codeReturn=mode;show('code');});
      button(t('Créditos','Credits'),()=>show('credits'));
      button(t('Voltar','Back'),()=>show('menu'));
    }
    if (mode==='drivers') {
      add('h2',t('PILOTOS E PROVA','DRIVERS & RACE'));
      button(t('Jogadores','Players')+' · '+state.players,()=>change(()=>{state.players=3-state.players;menuPlayer=0;}));
      button('P'+(menuPlayer+1)+' · '+state.profiles[menuPlayer].name,()=>change(()=>menuPlayer=state.players===2?1-menuPlayer:0));
      const profile=state.profiles[menuPlayer];
      const name=input(profile.name,t('Nome','Name'),12);
      name.onchange=()=>{profile.name=name.value.trim()||'P'+(menuPlayer+1);save();};
      button(t('Pintura','Paint')+' · '+(profile.paint+1),()=>change(()=>profile.paint=(profile.paint+1)%BGEngine.colors.length));
      button(profile.manual?t('Câmbio manual','Manual gears'):t('Câmbio automático','Automatic gears'),()=>change(()=>profile.manual=!profile.manual));
      button(t('Dificuldade','Difficulty')+' · '+[t('Iniciante','Rookie'),t('Profissional','Pro'),t('Campeonato','Championship')][state.difficulty],
        ()=>change(()=>state.difficulty=(state.difficulty+1)%3));
      button(t('Voltar','Back'),()=>show(settingsReturn));
    }
    if (mode==='system') {
      add('h2',t('ÁUDIO E EXIBIÇÃO','SOUND & DISPLAY'));
      button(t('Idioma · Português','Language · English'),()=>change(()=>state.lang^=1));
      button(state.mph?'MPH':'KM/H',()=>change(()=>state.mph=!state.mph));
      for(const [key,label] of [['music',t('Música','Music')],['effects',t('Efeitos','Effects')]]){
        button(label+' · '+Math.round(state[key]*100)+'%',()=>change(()=>state[key]=(Math.round(state[key]*5)+1)%6/5));
      }
      button(t('Áudio','Audio')+' · '+(state.muted?'OFF':'ON'),()=>change(()=>state.muted=!state.muted));
      const fits=['fill','wide','tall'];
      const labels=[t('Preencher tela','Fill screen'),'16:9','16:10'];
      button(t('Formato','Screen fit')+' · '+labels[fits.indexOf(state.fit)],()=>change(()=>state.fit=fits[(fits.indexOf(state.fit)+1)%fits.length]));
      const profiles=['economy','balanced','high','custom'];
      const names=t(['Econômico','Equilibrado','Alto','Personalizado'],['Economy','Balanced','High','Custom']);
      button(t('Gráficos','Graphics')+' · '+names[profiles.indexOf(state.quality)],
        ()=>change(()=>state.quality=profiles[(profiles.indexOf(state.quality)+1)%profiles.length]));
      if(state.quality==='custom'){
        const resolution=[540,720,900,1080];
        button(t('Resolução interna','Internal resolution')+' · '+state.customQuality.resolution+'p',
          ()=>change(()=>state.customQuality.resolution=resolution[(resolution.indexOf(state.customQuality.resolution)+1)%resolution.length]));
        button(t('Efeitos 3D','3D effects')+' · '+(state.customQuality.effects?'ON':'OFF'),
          ()=>change(()=>state.customQuality.effects=!state.customQuality.effects));
      }
      button(t('Reiniciar campeonato','Restart championship'),()=>show('reset'));
      button(t('Voltar','Back'),()=>show('options'));
    }
    if(mode==='credits'){
      add('h2',t('CRÉDITOS','CREDITS'));
      add('p','BUGO GEAR 2');
      add('small',t('Arte original. Simulação, geometria e áudio sintetizado no jogo.','Original artwork. In-game simulation, geometry and synthesized audio.'));
      button(t('Voltar','Back'),()=>show('options'));
    }
    const actionLabels=t(['Acelerar','Frear','Esquerda','Direita','Nitro','Subir marcha','Reduzir marcha',
      'Freio de mão','Câmera','Olhar para trás','Pausar','Confirmar'],['Throttle','Brake','Left','Right','Nitro','Shift up',
      'Shift down','Handbrake','Camera','Look back','Pause','Confirm']);
    if(mode==='controls'){
      add('h2',t('CONTROLES','CONTROLS'));
      button('P'+(controlPlayer+1),()=>{controlPlayer^=1;bindingIndex=0;show('controls');});
      const layout=BGControls.config(state,controlPlayer);
      add('p',actionLabels[bindingIndex]+' · '+(layout[bindingIndex].join(' / ')||'—'));
      button(t('Próxima ação','Next action'),()=>{bindingIndex=(bindingIndex+1)%(controlPlayer?10:12);show('controls');});
      button(t('Remapear tecla','Remap key'),()=>{remap=bindingIndex;show('remap');});
      button(t('Restaurar padrão','Reset defaults'),()=>change(()=>BGControls.reset(state,controlPlayer)));
      button(t('Sensibilidade','Sensitivity')+' · '+state.sensitivity[controlPlayer].toFixed(1),()=>change(()=>{
        const values=[.7,1,1.3];state.sensitivity[controlPlayer]=values[(values.indexOf(state.sensitivity[controlPlayer])+1)%3];
      }));
      button(t('Zona morta','Dead zone')+' · '+Math.round(state.deadzone[controlPlayer]*100)+'%',()=>change(()=>{
        const values=[.08,.18,.28,.38];state.deadzone[controlPlayer]=values[(values.indexOf(state.deadzone[controlPlayer])+1)%4];
      }));
      button(t('Voltar','Back'),()=>show('options'));
    }
    if(mode==='remap'){
      add('h2',t('PRESSIONE A TECLA','PRESS KEY'));
      add('p',actionLabels[remap]);
      button(t('Cancelar','Cancel'),()=>{remap=null;show('controls');});
    }
    if (['garage','garage-part','purchase'].includes(mode)) {
      const p = state.profiles[menuPlayer];
      const labels=[t('Motor','Engine'),t('Pneus secos','Dry tires'),t('Pneus chuva/neve','Wet tires'),
        t('Proteção frontal','Front armor'),t('Proteção traseira','Rear armor'),t('Proteção lateral','Side armor'),
        t('Câmbio','Gearbox'),t('Nitro','Nitro'),t('Freios','Brakes'),t('Suspensão','Suspension'),t('Eficiência de combustível','Fuel efficiency')];
      if(mode==='purchase'){
        add('h2',labels[menuSlot]);
        const cost=BGParts.prices[menuSlot][purchaseTier];
        add('p',t('Confirmar compra','Confirm purchase')+' · $'+cost.toLocaleString(state.lang?'en-US':'pt-BR'));
        add('p',t('Saldo após a compra: ','Balance after purchase: ')+'$'+(p.money-cost).toLocaleString(state.lang?'en-US':'pt-BR'));
        for(const [pt,en,value] of BGParts.metrics(menuSlot,purchaseTier,p.parts))add('p',t(pt,en)+': '+value);
        button(t('Comprar','Buy'),()=>{if(BGChampionship.buyPart(p,menuSlot,purchaseTier)){BGAudio.effect('purchase');save();}show('garage-part');});
        button(t('Cancelar','Cancel'),()=>show('garage-part'));
      } else if(mode==='garage-part') {
        add('h2',labels[menuSlot]+' · $'+p.money);
        const level=p.parts[menuSlot];
        const effect=t(['Aceleração e limite','Aderência em pista seca','Aderência em pista molhada',
          'Absorção frontal','Absorção traseira','Absorção lateral','Relações de marcha','Cargas e duração','Potência de frenagem','Aderência e estabilidade','Menor consumo'][menuSlot],
          ['Power and top speed','Dry grip','Wet grip','Front absorption','Rear absorption','Side absorption','Gear ratios','Capacity and duration','Stopping power','Grip and stability','Lower fuel use'][menuSlot]);
        add('p',effect);
        for(let i=0;i<4;i++){
          const description=menuSlot===6 ? ' · '+BGParts.transmissions[i].length+t(' marchas',' gears') :
            menuSlot===7 ? ' · '+BGParts.nitro[i].stock+t(' cargas',' charges') : '';
          const price=BGParts.prices[menuSlot][i];
          const status=i===level?t('INSTALADO','FITTED'):i<level?t('SUPERADO','SUPERSEDED'):price>p.money?'$'+price.toLocaleString(state.lang?'en-US':'pt-BR')+' · '+t('SEM CRÉDITOS','INSUFFICIENT FUNDS'):'$'+price.toLocaleString(state.lang?'en-US':'pt-BR');
          button('N'+(i+1)+description+' · '+status,()=>{
            purchaseTier=i;show('purchase');
          }).disabled=i<=level||price>p.money;
        }
        button(t('Voltar','Back'),()=>show('garage'));
      } else {
      add('h2',t('GARAGEM','GARAGE') + ' · P' + (menuPlayer + 1) + ' · $' + p.money);
      const name = input(p.name,t('Nome','Name'),12);
      name.onchange = () => {p.name = name.value.trim() || 'P' + (menuPlayer + 1); save();};
      if (state.players === 2) button(t('Trocar piloto','Switch driver'),() => {menuPlayer ^= 1; show('garage');});
      button(t('Pintura','Paint') + ' · ' + (p.paint+1),() => change(() => p.paint = (p.paint+1) % BGEngine.colors.length)).style.color = BGEngine.colors[p.paint];
      button(p.manual ? 'MANUAL' : t('AUTOMÁTICO','AUTOMATIC'),() => change(() => p.manual = !p.manual));
      button(t('Voltar','Back'),() => {menuPlayer=0;show(garageReturn);});
      for(const i of [0,6,1,2,8,9,7,3,4,5,10]){
        const next=BGParts.prices[i][p.parts[i]+1];
        const b=button(labels[i]+' · N'+(p.parts[i]+1),()=>{menuSlot=i;show('garage-part');});
        const detail=document.createElement('small');detail.className='part-detail';
        detail.textContent=next===undefined?t('Nível máximo','Max level'):t('Próxima melhoria: ','Next upgrade: ')+'$'+next.toLocaleString(state.lang?'en-US':'pt-BR');
        b.append(detail);
      }
      }
    }
    if (mode === 'code') {
      add('h2',t('CONTINUAÇÃO','CONTINUE'));
      const code = input(BGSave.encode(state),t('Código','Code'),9000);
      button(t('Selecionar código','Select code'),() => {code.focus(); code.select();});
      button(t('Carregar código','Load code'),() => {
        try {state = BGSave.decode(code.value); save(); show('menu');}
        catch {message = t('Código inválido','Invalid code'); add('small',message);}
      });
      button(t('Voltar','Back'),() => show(codeReturn));
    }
    if (mode === 'pause') {
      add('h2',t('PAUSA','PAUSED'));
      button(t('Retomar','Resume'),() => show('race'));
      button(t('Sair da corrida','Leave race'),() => {race = null; show('menu');});
    }
    if (mode === 'results') {
      add('h2',quickTrack!==null?t('RESULTADO DO TREINO','PRACTICE RESULTS'):outcome.qualified ? t('CLASSIFICADO','QUALIFIED') : t('DESCLASSIFICADO','ELIMINATED'));
      button(outcome.qualified ? t('Continuar','Continue') : t('Tentar novamente','Retry'),outcome.qualified ? () => {const ending=state.track===64&&quickTrack===null;quickTrack=null;show(ending?'ending':'menu');} : ()=>show('preview'));
      if (!outcome.qualified) button(t('Menu','Menu'),() => {race = null; show('menu');});
      button(t('Classificação geral','Championship standings'),()=>{standingsReturn='results';show('standings');});
      if(quickTrack===null)button(t('Classificação regional','Regional standings'),()=>{regionalIndex=race.track.region;regionalReturn='results';show('regional');});
      if(quickTrack===null&&outcome.qualified&&state.track%4===0)button(t('Código de continuação da região','Region continuation code'),()=>{codeReturn=mode;show('code');});
      button(t('Resultados','Results')+' '+(resultPage+1)+'/4',()=>{resultPage=(resultPage+1)%4;show('results');});
      const results = outcome.results.slice(resultPage*5,resultPage*5+5);
      results.forEach(d=>add('p','#'+d.place+'  '+d.name+'  '+(d.time===null?'DNF':d.time.toFixed(1)+'s')+'  +'+d.points+'  $'+d.prize));
    }
    if(mode==='regional') {
      const stats=BGChampionship.regional(state,regionalIndex);
      add('h2',BGTracks.create(regionalIndex*4).name[state.lang].split(' / ')[0]);
      add('p',t('Provas concluídas','Completed races')+' '+stats.completed+'/4');
      if(stats.recorded<stats.completed)add('small',t('Resultados de versões antigas não disponíveis.','Older race results unavailable.'));
      button(t('Região anterior','Previous region'),()=>{regionalIndex=(regionalIndex+15)%16;show('regional');});
      button(t('Próxima região','Next region'),()=>{regionalIndex=(regionalIndex+1)%16;show('regional');});
      button(t('Voltar','Back'),()=>show(regionalReturn));
      if(stats.recorded)stats.rows.forEach((r,i)=>add('p','#'+(i+1)+' · '+(r.id===0?state.profiles[0].name:r.id===20?state.profiles[1].name:'CPU '+String(r.id+1).padStart(2,'0'))+' · '+r.points+' pts'));
    }
    if (mode === 'ending'||mode==='standings') {
      add('h2',mode==='ending'?t('CAMPEONATO CONCLUÍDO','CHAMPIONSHIP COMPLETE'):t('CLASSIFICAÇÃO GERAL','CHAMPIONSHIP STANDINGS'));
      button(t('Voltar','Back'),() => show(mode==='ending'?'menu':standingsReturn));
      const rivals=Object.entries(state.rivals).map(([id,points])=>({name:'CPU '+String(+id+1).padStart(2,'0'),points}));
      [...state.profiles.slice(0,state.players),...rivals].sort((a,b)=>b.points-a.points)
        .forEach((p,i)=>add('p','#'+(i+1)+'  '+p.name+'  '+p.points+' pts'));
    }
    const profile=state.profiles[menuPlayer]||state.profiles[0];
    BGPresentation.mount(mode,{lang:state.lang,mph:state.mph,track:quickTrack??state.track,progress:state.track,region:regionIndex,slot:menuSlot,tier:purchaseTier,
      profile,profiles:state.profiles.slice(0,state.players)});
    panel.querySelector('button:not(:disabled)')?.focus({preventScroll:true});
  }
  function start() {
    if(state.track===64&&quickTrack===null){show('ending');return;}
    outcome = null;
    resultPage=0;
    race = BGEngine.create(BGTracks.create(quickTrack??state.track),state.players,state.profiles,state.difficulty);
    accumulator = 0; show('race');
  }
  function result(deadline) {
    const players = race.cars.filter(c => c.player);
    const finished=players.every(c=>c.finish!==null||c.retired);
    if(!deadline && (!finished || !race.cars.every(c=>c.finish!==null||c.retired) &&
      race.time-Math.max(...players.map(c=>c.finish??0))<12)) return;
    if(quickTrack===null)outcome=BGChampionship.settle(state,race);
    else{
      const results=BGEngine.order(race).map((c,i)=>({name:c.player?state.profiles[c.id].name:'CPU '+(c.id+1),
        place:i+1,time:c.finish,points:0,prize:0,player:c.player}));
      outcome={qualified:true,results,drivers:results.filter(c=>c.player)};
    }
    save(); show('results');
  }
  function menuInput(games) {
    const now = [12,13,0,1,9].map(index => games.some(g => g.buttons[index]?.pressed));
    if (mode === 'race') {
      if(BGControls.config(state,0)[10].some(k=>pressed.has(k))||now[4]&&!pads[4])show('pause');
    } else {
      // A stick deflection moves focus once. Returning to center arms the next move.
      const upThreshold=pads[0] ? .35 : .55;
      const downThreshold=pads[1] ? .35 : .55;
      now[0] ||= games.some(g=>g.axes[1]<-upThreshold);
      now[1] ||= games.some(g=>g.axes[1]>downThreshold);
      const options = [...panel.querySelectorAll('button:not(:disabled), input')];
      if (pressed.has('Escape') || mode==='pause'&&BGControls.config(state,0)[10].some(k=>pressed.has(k)) || now[3] && !pads[3]) {
        if(mode==='title')show('menu');
        else if (mode === 'pause') show('race');
        else if(mode==='preview')show(previewReturn);
        else if(mode==='ready')show('preview');
        else if(mode==='drivers')show(settingsReturn);
        else if(mode==='garage')show(garageReturn);
        else if(mode==='standings')show(standingsReturn);
        else if(mode==='regional')show(regionalReturn);
        else if(mode==='code')show(codeReturn);
        else if (['controls','system','credits'].includes(mode)) show('options');
        else if (mode === 'purchase') show('garage-part');
        else if (mode === 'garage-part') show('garage');
        else if (!['title','menu'].includes(mode)) show('menu');
      } else if (options.length) {
        const up = pressed.has('ArrowUp') || now[0] && !pads[0];
        const down = pressed.has('ArrowDown') || now[1] && !pads[1];
        if (up || down) {
          const index = options.indexOf(document.activeElement);
          const next=index<0?(up?options.length-1:0):(index+(up?-1:1)+options.length)%options.length;
          options[next].focus();
          BGAudio.effect('navigate');
        }
        if (BGControls.config(state,0)[11].some(k=>k!=='Enter'&&pressed.has(k)) || now[2] && !pads[2] || now[4] && !pads[4]) (options.includes(document.activeElement) ? document.activeElement : options[0]).click();
      }
    }
    pads.splice(0,pads.length,...now);
  }
  function frame(time) {
    const elapsed = Math.min(.1,(time-last)/1000);
    last = time;
    const games = poll();
    menuInput(games); pressed.clear();
    BGAudio.update(mode,race);
    if (mode === 'race') {
      accumulator += elapsed;
      const controls=[0,1].map(i=>control(i,games));
      for(const [i,c] of race.cars.filter(c=>c.player).entries()){
        if(controls[i].camera&&!c.cameraHeld)c.camera=((c.camera||0)+1)%3;
        c.cameraHeld=controls[i].camera;c.lookBack=controls[i].lookBack;
      }
      while (accumulator >= BGEngine.dt && mode === 'race') {
        raceEdges.clear();
        BGEngine.step(race,controls);
        if ([1,61,121,181].includes(race.tick)) BGAudio.effect(race.tick === 181 ? 'start' : 'countdown');
        race.events.forEach(e=>BGAudio.effect(e));
        if(race.events.includes('collision'))for(const p of games.slice(0,state.players)){
          try{p.vibrationActuator?.playEffect?.('dual-rumble',{duration:140,strongMagnitude:.34,weakMagnitude:.21})?.catch(()=>{});}catch{}
        }
        const first = BGEngine.order(race)[0];
        result(race.time > 300 || first.finish !== null && race.time-first.finish > 45);
        accumulator -= BGEngine.dt;
      }
      if(mode==='race'){
        const active=BG3D.render(race,quality());
        document.querySelector('#screen-3d').hidden=!active;
        if(!active)BGRenderer.render(canvas,race);
        BGPresentation.update(race,state.lang,state.mph);
      }
    }
    requestAnimationFrame(frame);
  }
  window.addEventListener('keydown',e => {
    if(['F10','F11'].includes(e.code))return;
    if(mode==='remap'){
      e.preventDefault();
      if(e.code==='Escape'){remap=null;show('controls');return;}
      if(e.repeat)return;
      if(BGControls.set(state,controlPlayer,remap,e.code)){remap=null;save();show('controls');}
      else if(!panel.querySelector('.conflict')){
        const notice=document.createElement('p');notice.className='conflict';
        notice.textContent=t('Tecla reservada ou já usada.','Reserved or already assigned.');
        panel.querySelector('.screen-main').append(notice);
      }
      return;
    }
    if (e.target instanceof HTMLInputElement && e.code !== 'Escape') return;
    if(mode==='title') BGAudio.start();
    if (mode === 'race' || ['ArrowUp','ArrowDown','Escape'].includes(e.code)) e.preventDefault();
    if(!keys.has(e.code)){
      pressed.add(e.code);
      if(mode==='race')raceEdges.add(e.code);
    }
    keys.add(e.code);
  });
  window.addEventListener('keyup',e => keys.delete(e.code));
  window.addEventListener('blur',()=>{keys.clear();pressed.clear();raceEdges.clear();if(mode==='race')show('pause');});
  document.addEventListener('visibilitychange',()=>{if(document.hidden){keys.clear();pressed.clear();raceEdges.clear();if(mode==='race')show('pause');}});
  show('title');
  requestAnimationFrame(frame);
})();
