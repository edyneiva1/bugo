'use strict';
(() => {
  const canvas = document.querySelector('canvas'), panel = document.querySelector('#panel');
  const ctx = canvas.getContext('2d');
  const keys = new Set(), pressed = new Set(), pads = [];
  const translations = (pt,en) => state.lang ? en : pt;
  const t = translations;
  let state = BGSave.load(), mode = 'title', race, menuPlayer = 0, message = '', last = 0, accumulator = 0, outcome;
  let remap = null, controlPlayer = 0, menuSlot = 0, modeSince=0, resultPage=0, ready=0, regionIndex=0, purchaseTier=0;
  const schemes = [
    [['ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Space','KeyE','KeyQ'],['KeyW','KeyS','KeyA','KeyD','ShiftLeft','KeyR','KeyF']],
    [['KeyW','KeyS','KeyA','KeyD','Space','KeyE','KeyQ'],['ArrowUp','ArrowDown','ArrowLeft','ArrowRight','ShiftRight','PageUp','PageDown']],
    [['KeyI','KeyK','KeyJ','KeyL','KeyU','KeyO','KeyY'],['KeyW','KeyS','KeyA','KeyD','KeyQ','KeyE','KeyR']],
    [['Numpad8','Numpad5','Numpad4','Numpad6','Numpad0','Numpad9','Numpad7'],['KeyW','KeyS','KeyA','KeyD','ShiftLeft','KeyR','KeyF']],
    [['ArrowUp','ArrowDown','ArrowLeft','ArrowRight','ControlRight','BracketRight','BracketLeft'],['KeyT','KeyG','KeyF','KeyH','KeyB','KeyY','KeyV']]
  ];
  const fields = ['gas','brake','left','right','boost','up','down'];
  const bindings = i => state.custom[i] || schemes[state.layout][i];
  function poll() {
    return Array.from(navigator.getGamepads?.() || []).filter(Boolean);
  }
  function control(i, games) {
    const a = Object.fromEntries(fields.map((field,j) => [field,keys.has(bindings(i)[j])]));
    const p = games[i], down = n => p?.buttons[n]?.pressed;
    a.gas ||= down(7) || down(0) || down(3); a.brake ||= down(6) || down(1);
    a.boost ||= down(2); a.up ||= down(5); a.down ||= down(4);
    a.steer = Number(a.right || down(15) || false) - Number(a.left || down(14) || false);
    const axis = p?.axes[0] || 0, deadzone = state.deadzone[i];
    if (!a.steer && Math.abs(axis) > deadzone) a.steer = Math.sign(axis)*(Math.abs(axis)-deadzone)/(1-deadzone);
    return a;
  }
  function add(tag,text) {
    const element = document.createElement(tag);
    element.textContent = text;
    panel.append(element);
    return element;
  }
  function button(label,action) {
    const element = add('button',label);
    element.onclick = () => {BGAudio.start(); BGAudio.effect('confirm'); action();};
    return element;
  }
  function input(value, label, limit) {
    const element = add('input','');
    element.value = value; element.maxLength = limit; element.setAttribute('aria-label',label);
    return element;
  }
  function save() { BGSave.save(state); }
  function change(action) { action(); save(); show(mode); }
  function show(next) {
    modeSince=performance.now();
    mode = next; panel.replaceChildren(); panel.hidden = mode === 'race';
    document.documentElement.lang = state.lang ? 'en' : 'pt-BR';
    BGAudio.muted = state.muted;
    BGAudio.levels(state.music,state.effects);
    if (mode === 'race') {canvas.focus(); return;}
    if (mode === 'title') {
      add('h1','BUGO GEAR 2');
      button(t('INICIAR','START'),() => show('menu'));
    }
    if (mode === 'menu') {
      add('h2',t('PIT LANE','PIT LANE'));
      button(state.track===64?t('Classificação','Standings'):t('Campeonato','Championship'),
        ()=>show(state.track===64?'ending':'preview'));
      button(t('Regiões','Regions'),()=>{regionIndex=Math.min(15,state.track>>2);show('regions');});
      button(t('Garagem','Garage'),()=>show('garage'));
      button(t('Configuração','Settings'),()=>show('options'));
    }
    if (mode === 'preview') {
      const track = BGTracks.create(state.track);
      const conditions = {
        clear:t('Céu limpo','Clear'),rain:t('Chuva','Rain'),snow:t('Neve','Snow'),fog:t('Neblina','Fog'),night:t('Noite','Night')
      };
      const distance = (track.length / (state.mph ? 1609.344 : 1000)).toFixed(2);
      add('h2',track.name[state.lang]);
      add('p',track.laps+' '+t('voltas','laps')+' · '+distance+' '+(state.mph ? 'mi' : 'km'));
      add('small',conditions[track.weather]);
      button(t('Largada','Start race'),() => {ready=0;state.players===2 ? show('ready') : start();});
      button(t('Garagem','Garage'),()=>show('garage'));
      button(t('Voltar','Back'),() => show('menu'));
    }
    if(mode==='ready'){
      add('h2',t('CONFIRMAÇÃO','READY CHECK'));
      add('p','P'+(ready+1)+' · '+state.profiles[ready].name);
      button(t('Confirmar piloto','Confirm driver'),()=>{if(++ready===2)start();else show('ready');});
      button(t('Voltar','Back'),()=>show('preview'));
    }
    if(mode==='regions'){
      const name=BGTracks.create(regionIndex*4).name[state.lang].split(' / ')[0];
      const unlocked=regionIndex*4<=state.track;
      add('h2',name);
      add('p',unlocked?t('REGIÃO LIBERADA','REGION UNLOCKED'):t('REGIÃO BLOQUEADA','REGION LOCKED'));
      for(let i=0;i<4;i++){
        const id=regionIndex*4+i;
        add('small',(id<state.track?'✓ ':id===state.track?'◆ ':'· ')+BGTracks.create(id).name[state.lang].split(' / ')[1]);
      }
      button(t('Anterior','Previous'),()=>{regionIndex=(regionIndex+15)%16;show('regions');});
      button(t('Próxima','Next'),()=>{regionIndex=(regionIndex+1)%16;show('regions');});
      button(t('Voltar','Back'),()=>show('menu'));
    }
    if (mode === 'reset') {
      add('h2',t('Reiniciar campeonato?','Restart championship?'));
      button(t('Confirmar','Confirm'),() => {
        const fresh = BGSave.defaults();
        state.track = 0;
        state.rivals={};
        state.profiles.forEach((p,i) => {p.points = 0; p.money = 0; p.parts = fresh.profiles[i].parts;});
        save(); show('menu');
      });
      button(t('Cancelar','Cancel'),() => show('menu'));
    }
    if (mode==='options') {
      add('h2',t('CONFIGURAÇÃO','SETTINGS'));
      button(t('Pilotos e prova','Drivers & race'),()=>show('drivers'));
      button(t('Controles','Controls'),()=>show('controls'));
      button(t('Áudio e exibição','Sound & display'),()=>show('system'));
      button(t('Continuação','Continue code'),()=>show('code'));
      button(t('Voltar','Back'),()=>show('menu'));
    }
    if (mode==='drivers') {
      add('h2',t('PILOTOS E PROVA','DRIVERS & RACE'));
      button(t('Jogadores','Players')+' · '+state.players,()=>change(()=>state.players=3-state.players));
      button('P'+(menuPlayer+1)+' · '+state.profiles[menuPlayer].name,()=>change(()=>menuPlayer=state.players===2?1-menuPlayer:0));
      const profile=state.profiles[menuPlayer];
      const name=input(profile.name,t('Nome','Name'),12);
      name.onchange=()=>{profile.name=name.value.trim()||'P'+(menuPlayer+1);save();};
      button(t('Pintura','Paint')+' · '+(profile.paint+1),()=>change(()=>profile.paint=(profile.paint+1)%BGEngine.colors.length));
      button(profile.manual?t('Câmbio manual','Manual gears'):t('Câmbio automático','Automatic gears'),()=>change(()=>profile.manual=!profile.manual));
      button(t('Dificuldade','Difficulty')+' · '+[t('Iniciante','Rookie'),t('Profissional','Pro'),t('Campeonato','Championship')][state.difficulty],
        ()=>change(()=>state.difficulty=(state.difficulty+1)%3));
      button(t('Voltar','Back'),()=>show('options'));
    }
    if (mode==='system') {
      add('h2',t('ÁUDIO E EXIBIÇÃO','SOUND & DISPLAY'));
      button(t('Idioma · Português','Language · English'),()=>change(()=>state.lang^=1));
      button(state.mph?'MPH':'KM/H',()=>change(()=>state.mph=!state.mph));
      for(const [key,label] of [['music',t('Música','Music')],['effects',t('Efeitos','Effects')]]){
        button(label+' · '+Math.round(state[key]*100)+'%',()=>change(()=>state[key]=(Math.round(state[key]*5)+1)%6/5));
      }
      button(t('Áudio','Audio')+' · '+(state.muted?'OFF':'ON'),()=>change(()=>state.muted=!state.muted));
      button(t('Tela cheia','Fullscreen'),()=>document.documentElement.requestFullscreen?.().catch(()=>{}));
      button(t('Reiniciar campeonato','Restart championship'),()=>show('reset'));
      button(t('Voltar','Back'),()=>show('options'));
    }
    if (mode === 'controls') {
      add('h2',t('CONTROLES','CONTROLS'));
      add('small',t('Acelerar / Frear / Esquerda / Direita / Nitro / Subir / Reduzir','Throttle / Brake / Left / Right / Nitro / Shift up / Shift down'));
      add('small','P'+(controlPlayer+1)+' · '+bindings(controlPlayer).join(' / '));
      button('P'+(controlPlayer+1),() => {controlPlayer ^= 1; show('controls');});
      button(t('Esquema','Layout')+' · '+(state.layout+1),() => change(() => {
        state.layout = (state.layout + 1) % schemes.length; state.custom = [null,null];
      }));
      button(t('Remapear teclado','Remap keyboard'),() => {remap = []; show('remap');});
      button(t('Zona morta','Dead zone')+' · '+Math.round(100*state.deadzone[controlPlayer])+'%',() => change(() => {
        const options = [.08,.18,.28,.38];
        state.deadzone[controlPlayer] = options[(options.indexOf(state.deadzone[controlPlayer])+1)%options.length];
      }));
      add('small',t('Gamepad · A / B / Direcional / X / RB / LB','Gamepad · A / B / D-pad / X / RB / LB'));
      button(t('Voltar','Back'),() => show('options'));
    }
    if (mode === 'remap') {
      add('h2',t('PRESSIONE A TECLA','PRESS KEY'));
      add('p',t(['Acelerar','Frear','Esquerda','Direita','Nitro','Subir marcha','Reduzir marcha'][remap.length],
        ['Throttle','Brake','Left','Right','Nitro','Shift up','Shift down'][remap.length]));
      button(t('Cancelar','Cancel'),() => {remap = null; show('controls');});
    }
    if (['garage','garage-part','purchase'].includes(mode)) {
      const p = state.profiles[menuPlayer];
      const labels=[t('Motor','Engine'),t('Pneus secos','Dry tires'),t('Pneus chuva/neve','Wet tires'),
        t('Proteção frontal','Front armor'),t('Proteção traseira','Rear armor'),t('Proteção lateral','Side armor'),
        t('Câmbio','Gearbox'),t('Nitro','Nitro')];
      if(mode==='purchase'){
        add('h2',labels[menuSlot]);
        add('p',t('Confirmar compra','Confirm purchase')+' · $'+BGParts.prices[menuSlot][purchaseTier]);
        button(t('Comprar','Buy'),()=>{if(BGChampionship.buyPart(p,menuSlot,purchaseTier)){BGAudio.effect('purchase');save();}show('garage-part');});
        button(t('Cancelar','Cancel'),()=>show('garage-part'));
      } else if(mode==='garage-part') {
        add('h2',labels[menuSlot]+' · $'+p.money);
        const level=p.parts[menuSlot];
        const effect=t(['Aceleração e limite','Aderência em pista seca','Aderência em pista molhada',
          'Absorção frontal','Absorção traseira','Absorção lateral','Relações de marcha','Cargas e duração'][menuSlot],
          ['Power and top speed','Dry grip','Wet grip','Front absorption','Rear absorption','Side absorption','Gear ratios','Capacity and duration'][menuSlot]);
        add('p',effect);
        for(let i=0;i<4;i++){
          const description=menuSlot===6 ? ' · '+BGParts.transmissions[i].length+t(' marchas',' gears') :
            menuSlot===7 ? ' · '+BGParts.nitro[i].stock+t(' cargas',' charges') : '';
          const price=BGParts.prices[menuSlot][i];
          button('N'+(i+1)+description+' · '+(level===i?t('INSTALADO','FITTED'):'$'+price),()=>{
            purchaseTier=i;show('purchase');
          }).disabled=i<=level||price>p.money;
        }
        button(t('Voltar','Back'),()=>show('garage'));
      } else {
      add('h2',t('GARAGEM','GARAGE') + ' · P' + (menuPlayer + 1) + ' · $' + p.money);
      const name = input(p.name,t('Nome','Name'),12);
      name.onchange = () => {p.name = name.value.trim() || 'P' + (menuPlayer + 1); save();};
      if (state.players === 2) button(t('Trocar piloto','Switch driver'),() => {menuPlayer ^= 1; show('garage');});
      button(t('Pintura','Paint') + ' · ' + (p.paint+1),() => change(() => p.paint = (p.paint+1) % BGEngine.colors.length)).style.color = BGEngine.colors[p.paint];
      button(p.manual ? 'MANUAL' : t('AUTOMÁTICO','AUTOMATIC'),() => change(() => p.manual = !p.manual));
      button(t('Voltar','Back'),() => {menuPlayer=0;show('menu');});
      for(const i of [0,6,1,2,7,3,4,5]){
        button(labels[i]+' · N'+(p.parts[i]+1),()=>{menuSlot=i;show('garage-part');});
      }
      }
    }
    if (mode === 'code') {
      add('h2',t('CONTINUAÇÃO','CONTINUE'));
      const code = input(BGSave.encode(state),t('Código','Code'),9000);
      button(t('Selecionar código','Select code'),() => {code.focus(); code.select();});
      button(t('Carregar código','Load code'),() => {
        try {state = BGSave.decode(code.value); save(); show('menu');}
        catch {message = t('Código inválido','Invalid code'); add('small',message);}
      });
      button(t('Voltar','Back'),() => show('menu'));
    }
    if (mode === 'pause') {
      add('h2',t('PAUSA','PAUSED'));
      button(t('Retomar','Resume'),() => show('race'));
      button(t('Sair da corrida','Leave race'),() => {race = null; show('menu');});
    }
    if (mode === 'results') {
      add('h2',outcome.qualified ? t('CLASSIFICADO','QUALIFIED') : t('DESCLASSIFICADO','ELIMINATED'));
      button(outcome.qualified ? t('Continuar','Continue') : t('Tentar novamente','Retry'),outcome.qualified ? () => show(state.track === 64 ? 'ending' : 'menu') : start);
      if (!outcome.qualified) button(t('Menu','Menu'),() => {race = null; show('menu');});
      button(t('Classificação','Standings')+' '+(resultPage+1)+'/4',()=>{resultPage=(resultPage+1)%4;show('results');});
      const results = resultPage===0 ? [...new Set([...outcome.drivers,...outcome.results.slice(0,5)])].slice(0,7) : outcome.results.slice(resultPage*5,resultPage*5+5);
      results.forEach(d=>add('p','#'+d.place+'  '+d.name+'  '+(d.time===null?'DNF':d.time.toFixed(1)+'s')+'  +'+d.points+'  $'+d.prize));
    }
    if (mode === 'ending') {
      add('h2',t('CAMPEONATO CONCLUÍDO','CHAMPIONSHIP COMPLETE'));
      button(t('Menu','Menu'),() => {race = null; show('menu');});
      const rivals=Object.entries(state.rivals).map(([id,points])=>({name:'CPU '+String(+id+1).padStart(2,'0'),points}));
      [...state.profiles.slice(0,state.players),...rivals].sort((a,b)=>b.points-a.points)
        .forEach((p,i)=>add('p','#'+(i+1)+'  '+p.name+'  '+p.points+' pts'));
    }
    panel.querySelector('button:not(:disabled)')?.focus();
  }
  function start() {
    if (state.track === 64) {show('ending'); return;}
    outcome = null;
    resultPage=0;
    race = BGEngine.create(BGTracks.create(state.track),state.players,state.profiles,state.difficulty);
    accumulator = 0; show('race');
  }
  function result(deadline) {
    const players = race.cars.filter(c => c.player);
    const finished=players.every(c=>c.finish!==null||c.retired);
    if(!deadline && (!finished || !race.cars.every(c=>c.finish!==null||c.retired) &&
      race.time-Math.max(...players.map(c=>c.finish??0))<12)) return;
    outcome = BGChampionship.settle(state,race);
    save(); show('results');
  }
  function hud() {
    const order = BGEngine.order(race), players = race.cars.filter(c => c.player), h = canvas.height / players.length;
    ctx.save();
    ctx.font = 'bold 8px monospace'; ctx.textBaseline = 'top';
    players.forEach((c,i) => {
      const y = i*h;
      const base=y+h-17;
      const box=(color,x,top,w,height)=>{ctx.fillStyle=color;ctx.fillRect(x,top,w,height);};
      box('#172033',0,y,256,13);box('#efaa60',0,y+12,256,1);
      box('#172033',0,base,256,17);box('#46566e',0,base,256,1);
      ctx.fillStyle='#e8edda';
      ctx.fillText('P'+c.player+'   '+String(order.indexOf(c)+1).padStart(2,'0')+'/20   '+t('VOL','LAP')+' '+Math.min(race.laps,Math.floor(Math.max(0,c.z)/race.track.length)+1)+'/'+race.laps,5,y+2);
      ctx.textAlign='right';
      ctx.fillText((c.finish??c.retiredAt??Math.max(0,race.time)).toFixed(1)+' s',251,y+2);
      ctx.textAlign='start';
      ctx.font='bold 13px monospace';ctx.fillStyle='#ffcd79';
      ctx.fillText(String(Math.round(c.speed*(state.mph?2.237:3.6))).padStart(3,'0'),4,base+2);
      ctx.font='bold 7px monospace';ctx.fillStyle='#e8edda';
      ctx.fillText(state.mph?'MPH':'KM/H',32,base+8);
      box('#32475e',55,base+3,17,11);ctx.fillStyle='#ffcc7a';
      ctx.fillText(c.gear===0?'R':'G'+c.gear,58,base+5);
      for(let n=0;n<12;n++)box(n/12<c.rpm?(n>=9?'#ef7962':n>=6?'#f3b259':'#71c8b2'):'#35445b',78+n*4,base+9-(n>>2),3,4+(n>>2));
      for(let n=0;n<c.kit.max;n++)box(n<c.nitro?'#6ad9d8':'#37495f',134+n*3,base+5,2,7);
      box('#44556a',177,base+8,30,4);box('#89cf9e',177,base+8,Math.round(c.fuel*.3),4);
      ctx.fillStyle='#e8edda';ctx.fillText('F',171,base+6);
      damageHud(c.damage,223,base+2);
      ctx.font='bold 8px monospace';
      minimap(c,y);
      if (race.time < 1 || c.finish !== null || c.retired) {
        ctx.font = 'bold 17px monospace'; ctx.textAlign = 'center'; ctx.fillStyle = '#ffd36f';
        const banner = c.retired ? t('FORA DA CORRIDA','RETIRED') : c.finish !== null ? t('CHEGADA','FINISH') :
          race.time < 0 ? String(Math.ceil(-race.time)) : t('VAI!','GO!');
        ctx.fillText(banner,canvas.width/2,y+h*.34);
        ctx.textAlign = 'start'; ctx.font = 'bold 8px monospace';
      }
    });
    ctx.restore();
  }
  function damageHud(d,x,y) {
    const shade=n=>n>=100?'#11131c':n>=65?'#ed7460':n>=30?'#f9c85f':'#83cc9e';
    const block=(k,a,b,w,h)=>{ctx.fillStyle=k;ctx.fillRect(x+a,y+b,w,h);};
    block('#435568',1,1,22,13);
    block(shade(d[2]),0,3,4,8);block(shade(d[2]),20,3,4,8);
    block(shade(d[0]),4,0,16,3);block(shade(d[1]),4,11,16,3);
    block('#647d8b',7,4,10,3);block('#263950',7,8,10,2);
  }
  function minimap(driver,y) {
    const {map} = race.track;
    const originX = canvas.width-43, originY = y+17, size = 38;
    ctx.fillStyle = '#172033'; ctx.fillRect(originX,originY,size,size);
    ctx.strokeStyle='#3d566a';ctx.strokeRect(originX+.5,originY+.5,size-1,size-1);
    ctx.strokeStyle = '#8895a5'; ctx.beginPath();
    map.forEach(({x,y},i) => ctx[i ? 'lineTo' : 'moveTo'](originX+x*size,originY+y*size));
    ctx.stroke();
    for (const car of race.cars) {
      const {x,y} = race.track.mapPoint(Math.max(0,car.z)), marker = car === driver ? 3 : 2;
      ctx.fillStyle = car.player ? car.color : '#f3dfac';
      ctx.fillRect(Math.round(originX+x*size)-1,Math.round(originY+y*size)-1,marker,marker);
    }
  }
  function menuInput(games) {
    const now = [12,13,0,1,9].map(index => games.some(g => g.buttons[index]?.pressed));
    if (mode === 'race') {
      if (pressed.has('Escape') || now[4] && !pads[4]) show('pause');
    } else {
      const options = [...panel.querySelectorAll('button:not(:disabled), input')];
      if (pressed.has('Escape') || now[3] && !pads[3]) {
        if (mode === 'pause') show('race');
        else if (['controls','drivers','system','code'].includes(mode)) show('options');
        else if (mode === 'purchase') show('garage-part');
        else if (mode === 'garage-part') show('garage');
        else if (!['title','menu'].includes(mode)) show('menu');
      } else if (options.length) {
        const up = pressed.has('ArrowUp') || now[0] && !pads[0];
        const down = pressed.has('ArrowDown') || now[1] && !pads[1];
        if (up || down) {
          const index = options.indexOf(document.activeElement);
          options[(index + (up ? options.length-1 : 1)) % options.length].focus();
          BGAudio.effect('navigate');
        }
        if (now[2] && !pads[2] || now[4] && !pads[4]) (options.includes(document.activeElement) ? document.activeElement : options[0]).click();
      }
    }
    pads.splice(0,pads.length,...now);
  }
  function frame(time) {
    const elapsed = Math.min(.1,(time-last)/1000);
    last = time;
    const games = poll();
    menuInput(games); pressed.clear();
    BGAudio.update(mode,race);
    if (mode === 'race') {
      accumulator += elapsed;
      const controls = [0,1].map(i => control(i,games));
      while (accumulator >= BGEngine.dt && mode === 'race') {
        const tick = race.tick;
        BGEngine.step(race,controls);
        if ([1,61,121,181].includes(race.tick)) BGAudio.effect(tick === 180 ? 'start' : 'countdown');
        race.events.forEach(e => BGAudio.effect(e));
        const first = BGEngine.order(race)[0];
        result(race.time > 300 || first.finish !== null && race.time-first.finish > 45);
        accumulator -= BGEngine.dt;
      }
      BGRenderer.render(canvas,race); hud();
    } else BGMenu.render(ctx,panel,mode,time/1000,{age:(time-modeSince)/1000,slot:menuSlot,level:state.profiles[menuPlayer].parts[menuSlot],region:regionIndex,track:state.track,lang:state.lang,profiles:state.profiles.slice(0,state.players),paint:state.profiles[menuPlayer].paint,tier:purchaseTier});
    requestAnimationFrame(frame);
  }
  window.addEventListener('keydown',e => {
    if (mode === 'remap') {
      e.preventDefault();
      if (e.code === 'Escape') {remap = null; show('controls'); return;}
      if (e.repeat || !/^[a-zA-Z0-9]{1,24}$/.test(e.code) || ['Enter','Tab'].includes(e.code) ||
          remap.includes(e.code) || bindings(controlPlayer^1).includes(e.code)) return;
      remap.push(e.code);
      if (remap.length === fields.length) {state.custom[controlPlayer] = remap; remap = null; save(); show('controls');}
      else show('remap');
      return;
    }
    if (e.target instanceof HTMLInputElement && e.code !== 'Escape') return;
    if (mode === 'race' || ['ArrowUp','ArrowDown','Escape'].includes(e.code)) e.preventDefault();
    if (!keys.has(e.code)) pressed.add(e.code);
    keys.add(e.code);
  });
  window.addEventListener('keyup',e => keys.delete(e.code));
  window.addEventListener('blur',() => {keys.clear(); if (mode === 'race') show('pause');});
  canvas.addEventListener('click',e=>{
    if(mode==='race')return;
    const rect=canvas.getBoundingClientRect();
    BGMenu.activate((e.clientX-rect.left)*256/rect.width,(e.clientY-rect.top)*224/rect.height);
  });
  canvas.addEventListener('wheel',e=>{if(mode!=='race'){e.preventDefault();BGMenu.move(e.deltaY);}},{passive:false});
  show('title');
  requestAnimationFrame(frame);
})();
