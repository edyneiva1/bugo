'use strict';
globalThis.BGNetwork = (() => {
  const version = 1;
  const inputFields = ['gas','brake','boost','up','down'];
  const validId = value => typeof value === 'string' && /^[A-Za-z0-9_-]{1,64}$/.test(value);

  function room(id, raceId, playerIds) {
    if (!validId(id) || !validId(raceId) || !Array.isArray(playerIds) ||
        playerIds.length === 0 || playerIds.length > 2 || !playerIds.every(validId) ||
        new Set(playerIds).size !== playerIds.length) throw new TypeError('Invalid race room');
    return Object.freeze({id,raceId,playerIds:Object.freeze([...playerIds])});
  }

  function readInput(message, session, authenticatedId, currentTick) {
    if (!message || message.version !== version || message.type !== 'input' ||
        message.room !== session.id || message.race !== session.raceId ||
        message.player !== authenticatedId || !session.playerIds.includes(authenticatedId) ||
        !Number.isSafeInteger(message.tick) || message.tick <= currentTick || message.tick > currentTick + 120 ||
        !message.input || !Number.isFinite(message.input.steer) || Math.abs(message.input.steer) > 1 ||
        !inputFields.every(key => typeof message.input[key] === 'boolean')) return null;
    const {gas,brake,boost,up,down,steer} = message.input;
    return {player:authenticatedId,tick:message.tick,input:{gas,brake,boost,up,down,steer}};
  }

  function inputMessage(session,player,tick,input) {
    return {version,type:'input',room:session.id,race:session.raceId,player,tick,input:{
      gas:!!input.gas,brake:!!input.brake,boost:!!input.boost,up:!!input.up,down:!!input.down,
      steer:Math.max(-1,Math.min(1,Number(input.steer) || 0))
    }};
  }

  function checkpoint(race, session) {
    const {track,cars,contacts,...state} = race;
    return {version,type:'checkpoint',room:session.id,race:session.raceId,track:track.index,state:structuredClone({
      ...state, contacts:[...contacts], cars:cars.map(({picked,...car}) => ({...car,picked:[...picked]}))
    })};
  }

  function restore(message,session,createTrack) {
    if (message?.version !== version || message.type !== 'checkpoint' ||
        message.room !== session.id || message.race !== session.raceId ||
        !Number.isSafeInteger(message.track) || !Number.isSafeInteger(message.state?.tick) ||
        message.state.tick < 0) throw new TypeError('Invalid race checkpoint');
    const {cars,contacts,...state} = structuredClone(message.state);
    return {...state,track:createTrack(message.track),contacts:new Set(contacts),
      cars:cars.map(({picked,...car}) => ({...car,picked:new Set(picked)}))};
  }

  function createAuthority(engine,race,session) {
    const pending = session.playerIds.map(() => new Map());
    return {
      receive(authenticatedId,message) {
        const command = readInput(message,session,authenticatedId,race.tick);
        if (!command) return false;
        const queue = pending[session.playerIds.indexOf(authenticatedId)];
        if (queue.has(command.tick)) return false;
        queue.set(command.tick,command.input);
        return true;
      },
      step() {
        const tick = race.tick + 1;
        const controls = pending.map(queue => {
          const input = queue.get(tick);
          queue.delete(tick);
          return input;
        });
        engine.step(race,controls);
      },
      checkpoint: () => checkpoint(race,session),
      frame: () => ({version,type:'frame',room:session.id,race:session.raceId,...engine.frame(race)}),
      results: () => {
        const order = engine.order(race);
        if (order.some(car => car.player && car.finish === null && !car.retired)) return null;
        return {version,type:'results',room:session.id,race:session.raceId,tick:race.tick,
          finishers:order.map(({id,player,finish,retired}) => ({id,player,finish,retired}))};
      }
    };
  }

  function reconcile(engine,message,session,createTrack,throughTick,inputsAt) {
    const race = restore(message,session,createTrack);
    if (!Number.isSafeInteger(throughTick) || throughTick < race.tick || throughTick > race.tick + 120) {
      throw new RangeError('Invalid prediction window');
    }
    while (race.tick < throughTick) engine.step(race,inputsAt(race.tick + 1));
    return race;
  }

  return Object.freeze({version,room,inputMessage,createAuthority,restore,reconcile});
})();
