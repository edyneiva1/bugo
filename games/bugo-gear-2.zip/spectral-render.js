'use strict';
// Spectral GT RS by Jaron K Bragg, CC0. Standalone WebGL1 renderer, no network.
globalThis.BGSpectralRender=(()=>{
 let state=null;
 const decode=s=>{const b=atob(s),a=new Uint8Array(b.length);for(let i=0;i<b.length;i++)a[i]=b.charCodeAt(i);return a;};
 function reset(){state=null;}
 function init(gl){
  const shader=(type,src)=>{const s=gl.createShader(type);gl.shaderSource(s,src);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(s));return s;};
  const vs=shader(gl.VERTEX_SHADER,`attribute vec3 aPos;attribute vec3 aNormal;attribute float aGroup;
  uniform vec3 center,eye;uniform vec3 pivot1,pivot2,pivot3,pivot4;uniform vec2 rollWheel,steerWheel;uniform float bodyLift;uniform vec2 bodyRoll,bodyPitch;uniform vec2 heading,forward,right,pitch;uniform float aspect,f;
  varying vec3 normal,view,localPos;varying float depth,mirrorFace;
  vec3 spinX(vec3 v,vec2 a){return vec3(v.x,a.x*v.y-a.y*v.z,a.y*v.y+a.x*v.z);}
  vec3 turnY(vec3 v,vec2 a){return vec3(a.x*v.x+a.y*v.z,v.y,-a.y*v.x+a.x*v.z);}
  vec3 spinZ(vec3 v,vec2 a){return vec3(a.x*v.x-a.y*v.y,a.y*v.x+a.x*v.y,v.z);}
  void main(){vec3 lp=aPos,ln=aNormal;localPos=aPos;
  // Original external mirror shells occupy this narrow local-space envelope.
  // Only their rear-facing surface receives the mirror finish.
  mirrorFace=step(.632,abs(aPos.x))*step(abs(aPos.x),.770)*step(.886,aPos.y)*step(aPos.y,1.024)*step(.385,aPos.z)*step(aPos.z,.670)*smoothstep(.28,.72,-aNormal.z);
  if(aGroup>.5){float g=aGroup>4.5?aGroup-4.:aGroup;vec3 pivot=g<1.5?pivot1:g<2.5?pivot2:g<3.5?pivot3:pivot4;
    lp-=pivot;
    if(aGroup<4.5){lp=spinX(lp,rollWheel);ln=spinX(ln,rollWheel);}
    if(g>2.5){lp=turnY(lp,steerWheel);ln=turnY(ln,steerWheel);}
    lp+=pivot;
  }else{lp.y-=.50;lp=spinZ(spinX(lp,bodyPitch),bodyRoll);lp.y+=.50+bodyLift;ln=spinZ(spinX(ln,bodyPitch),bodyRoll);}
  vec3 p=center+vec3(lp.z*heading.x-lp.x*heading.y,lp.y,lp.z*heading.y+lp.x*heading.x);
  normal=vec3(ln.z*heading.x-ln.x*heading.y,ln.y,ln.z*heading.y+ln.x*heading.x);view=eye-p;
  vec3 d=p-eye;float z=dot(d.xz,forward);float x=dot(d.xz,right);float y=d.y*pitch.x+z*pitch.y;depth=z*pitch.x-d.y*pitch.y;
  gl_Position=vec4(x*f/aspect,y*f,depth*1.0004-.38,depth);}`);
  const fs=shader(gl.FRAGMENT_SHADER,`precision mediump float;varying vec3 normal,view,localPos;varying float depth,mirrorFace;
  uniform vec3 base,emission,haze,envSky,envGround,damageZones;uniform vec4 finish;
  uniform vec4 carLight;
  uniform float illumination,fog,paintSurface,materialKind,envStrength,studio,damageDetail;
  // Analytic environment, in linear RGB. No texture sampling or external downloads.
  vec3 env(vec3 r,float rough){float sky=smoothstep(-.28,.52,r.y);
    float horizon=pow(max(0.,1.-abs(r.y)),mix(12.,2.,rough));
    vec3 c=mix(envGround,envSky,sky)+envSky*horizon*.18;
    float strip=pow(max(0.,dot(r,normalize(vec3(-.5,.8,.4)))),mix(65.,4.,rough));
    float rim=pow(max(0.,dot(r,normalize(vec3(.7,.45,-.5)))),mix(45.,3.,rough));
    return (c+envSky*(strip*(.65+studio*.9)+rim*.50))*envStrength;
  }
  vec3 schlick(vec3 f0,float v){return f0+(1.-f0)*pow(1.-clamp(v,0.,1.),5.);}
  void main(){vec3 N=normalize(normal);vec3 V=normalize(view);if(dot(N,V)<0.)N=-N;
    vec3 L=carLight.xyz;vec3 H=normalize(L+V);
    float nv=clamp(dot(N,V),0.,1.),nl=clamp(dot(N,L),0.,1.);
    float m=finish.x,r=clamp(finish.y,.06,1.),cc=finish.z,cr=clamp(finish.w,.06,1.);
    vec3 pigment=base;
    if(materialKind>1.5&&materialKind<2.5){ // original carbon has no baked weave; local, filtered approximation
      float fade=1.-smoothstep(4.,12.,depth);
      float weave=sin((localPos.x+localPos.z)*105.)*sin((localPos.y-localPos.z)*105.);
      pigment*=1.+weave*.22*fade;
    }
    // Damage is anchored to the original body coordinates, not the camera or world.
    // Engine slots: front, rear, both sides. Cosmetic only; undamaged paint is unchanged.
    float wear=0.,scratch=0.;
    if(paintSurface>.5&&max(max(damageZones.x,damageZones.y),damageZones.z)>.001){
      float front=smoothstep(1.15,1.95,localPos.z)*damageZones.x;
      float rear=smoothstep(1.15,1.95,-localPos.z)*damageZones.y;
      float side=smoothstep(.54,.94,abs(localPos.x))*(1.-smoothstep(.60,.99,localPos.y))*damageZones.z;
      wear=max(max(front,rear),side)* (1.-smoothstep(.94,1.15,localPos.y));
      float patches=.55+.45*sin(localPos.z*7.+localPos.x*5.)*sin(localPos.y*12.+localPos.z*3.);
      wear*=patches;
      if(damageDetail>.5){
        float fade=1.-smoothstep(9.,24.,depth);
        float stripe=1.-smoothstep(.045,.16,abs(fract(localPos.y*12.+localPos.z*2.6+localPos.x*3.1)-.5));
        float broken=smoothstep(.22,.76,sin(localPos.z*11.+localPos.x*14.+localPos.y*4.)*.5+.5);
        scratch=stripe*broken*fade*smoothstep(.08,.55,wear);
      }
      pigment=mix(pigment,pigment*.43+vec3(.075,.070,.065),wear*.72);
      pigment=mix(pigment,vec3(.37,.39,.40),scratch*.65);
      r=mix(r,.85,wear*.82);cc*=1.-wear*.88;
    }
    vec3 R=reflect(-V,N),F0=mix(vec3(.04),pigment,m),F=schlick(F0,nv);
    vec3 reflected=env(R,r);float spec=pow(max(dot(N,H),0.),mix(85.,5.,r));
    vec3 col=pigment*(1.-m)*(.32+.75*nl)+pigment*m*.18+reflected*F*(.85+.3*(1.-r))+F0*spec*nl*.7;
    float coatF=.04+.96*pow(1.-nv,5.);
    col=col*(1.-cc*coatF*.35)+cc*coatF*env(R,cr)*.18;
    if(paintSurface>.5){ // keep approved paint hue; colored base reflection + separate neutral coat
      vec3 chroma=pigment/max(max(pigment.r,pigment.g),max(pigment.b,.001));
      vec3 tint=mix(vec3(.16),chroma,.84);
      col=pigment*(.68+.70*nl)+reflected*tint*(.065+.15*pow(1.-nv,3.))+F0*spec*nl*.38;
      col+=cc*coatF*env(R,cr)*.19+cc*vec3(.12)*pow(max(dot(N,H),0.),mix(90.,12.,cr));
      // A thin wet sheen on painted panels only, with distance and damage attenuation.
      float sheen=carLight.w*(1.-smoothstep(12.,38.,depth))*(1.-wear*.8);
      col+=reflected*sheen*(.025+.13*coatF);
    }
    if(materialKind>.5&&materialKind<1.5){ // dark glass, reflection only; no refraction pass
      col=pigment*(.75+.35*nl)+env(R,r)*(.035+.30*pow(1.-nv,3.));
    }
    if(materialKind>2.5&&materialKind<3.5){ // rubber: no sharp metallic highlight
      col=pigment*(.85+.72*nl)+env(R,.88)*.018+vec3(.015)*spec*nl;
    }
    if(paintSurface>.5 && mirrorFace>.01){vec3 mirror=env(R,.12)*vec3(.62,.77,.85);col=mix(col,mirror,mirrorFace*.86);}
    col=col*illumination+emission;col=col/(1.+col*.45);col=pow(clamp(col,0.,1.),vec3(1./2.2));
    gl_FragColor=vec4(mix(col,haze,clamp(depth*fog,0.,.87)),1.);
  }`);
  const program=gl.createProgram();gl.attachShader(program,vs);gl.attachShader(program,fs);gl.linkProgram(program);if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(program));
  const loc=Object.fromEntries(['pivot1','pivot2','pivot3','pivot4','rollWheel','steerWheel','bodyLift','bodyRoll','bodyPitch','center','eye','heading','forward','right','pitch','aspect','f','base','emission','haze','finish','illumination','fog','paintSurface','materialKind','envSky','envGround','envStrength','studio','damageZones','damageDetail','carLight'].map(n=>[n,gl.getUniformLocation(program,n)]));
  const attrs=['aPos','aNormal','aGroup'].map(n=>gl.getAttribLocation(program,n));
  // Cache attribute layouts when WebGL1 exposes the standard OES VAO extension.
  // The ordinary buffer path remains available on older/limited GPUs.
  const candidate=gl.getExtension('OES_vertex_array_object');
  const vaoExt=candidate&&typeof candidate.createVertexArrayOES==='function'&&typeof candidate.bindVertexArrayOES==='function'&&typeof candidate.deleteVertexArrayOES==='function'?candidate:null;
  const upload=data=>data.batches.map(b=>{
   const v=gl.createBuffer(),i=gl.createBuffer();
   gl.bindBuffer(gl.ARRAY_BUFFER,v);gl.bufferData(gl.ARRAY_BUFFER,decode(b.vertices),gl.STATIC_DRAW);
   const vao=vaoExt?.createVertexArrayOES()||null;
   if(vao)vaoExt.bindVertexArrayOES(vao);
   gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,i);gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,decode(b.indices),gl.STATIC_DRAW);
   if(vao){attrs.forEach((a,j)=>{gl.enableVertexAttribArray(a);gl.vertexAttribPointer(a,j===2?1:3,gl.FLOAT,false,28,j*12);});vaoExt.bindVertexArrayOES(null);}
   return {v,i,vao,count:b.indexCount,material:b.material};
  });
  const sources={full:BGSpectralData,near:globalThis.BGSpectralNear,far:globalThis.BGSpectralFar};
  const uploaded=new Map();
  const batchesFor=lod=>{
   const source=sources[lod]||sources.full;
   if(!uploaded.has(source))uploaded.set(source,upload(source));
   return uploaded.get(source);
  };
  return {gl,program,loc,attrs,vaoExt,batchesFor};
 }
 function prepare(gl){if(state?.gl===gl)return;state=init(gl);}
 // Distance-driven, independent of FPS and number of split-screen views.
 function motion(c){
  const radius=BGSpectralData.wheelRadius;
  const dist=Number.isFinite(c.z)?c.z+2:0;
  const spin=(dist/radius)%(Math.PI*2);
  const steer=Math.max(-1,Math.min(1,Number(c.steer)||0))*.33;
  // Subtle visual chassis heave only. No changes to collision or grip.
  const speed=Math.max(0,Number(c.speed)||0), amp=Math.min(1,speed/18);
  const lift=amp===0?0:amp*(Math.sin(dist*1.7)*.013+Math.sin(dist*3.8)*.006)-(c.brake?amp*.009:0);
  return {spin,steer,lift};
 }
 // Render-only load transfer; input is the actual fixed-step race state. Never mutates cars.
 const bounded=(n,a,b)=>Math.max(a,Math.min(b,n));
 const finite=n=>Number.isFinite(n)?n:0;
 function bodyPose(c,road,prior,tick){
  const speed=Math.max(0,finite(c.speed)), signed=speed*(c.gear===0?-1:1), vx=finite(c.vx);
  const base={tick,signed,vx,pitch:0,roll:0,lift:0};
  if(!prior||tick<prior.tick||tick-prior.tick>60||tick<=180)return base;
  if(tick===prior.tick)return prior;
  const dt=(tick-prior.tick)/60, alpha=1-Math.exp(-dt*9);
  const active=speed>.15&&!c.retired;
  const longitudinal=bounded((signed-prior.signed)/dt,-30,30);
  const lateral=bounded((vx-prior.vx)/dt+finite(road.curvature)*speed*speed,-22,22);
  const targetPitch=active?bounded(-longitudinal*.00165,-.043,.043):0;
  const targetRoll=active?bounded(lateral*.0025,-.048,.048):0;
  const edge=Number.isFinite(road.width)?bounded((Math.abs(finite(c.x))-road.width+.35)/1.2,0,1):0;
  const z=finite(c.z), bump=edge*Math.min(1,speed/14)*(.023*Math.sin(z*3.1)+.012*Math.sin(z*5.7));
  const targetLift=active?bounded(motion(c).lift+bump,-.045,.045):0;
  return {...base,pitch:prior.pitch+(targetPitch-prior.pitch)*alpha,roll:prior.roll+(targetRoll-prior.roll)*alpha,lift:prior.lift+(targetLift-prior.lift)*alpha};
 }
 // Same local-space transform as the vertex shader, for attached effects and lamp positions.
 function bodyPoint(x,y,z,pose){
  if(!pose)return [x,y,z];
  y-=.50;const cp=Math.cos(pose.pitch),sp=Math.sin(pose.pitch),cr=Math.cos(pose.roll),sr=Math.sin(pose.roll);
  const yp=cp*y-sp*z,zp=sp*y+cp*z;
  return [cr*x-sr*yp,sr*x+cr*yp+.50+pose.lift,zp];
 }
 // Mounts measured in game-space from Headlight_Main and Exhaust_Inner nodes of the original GLB.
 const mounts=Object.freeze({head:Object.freeze([.54081,.66756,2.05212]),exhaust:Object.freeze([.47321,.49011,-2.2])});
 function lights(c,mode='clear'){
  const low=mode==='night'||mode==='tunnel', poor=mode==='rain'||mode==='fog'||mode==='snow';
  return {head:low?.24:poor?.12:.035, running:low?.055:.022,
    tail:(c.brake||c.previous?.handbrake)? .25:low?.065:poor?.040:.025,
    amber:.006,beam:low?1:poor?.35:0};
 }
 function emissionFor(m,index,light){
  // glTF intensities are HDR; the lightweight shader has no HDR bloom pass.
  // Scale each original emission channel separately to prevent clipped brake lights.
  const power=index===17?light.head:index===18?light.tail:index===16?light.amber:index===8?light.running:.09;
  return m.emissive.map(v=>v*power);
 }
 // Approximate the actual sky palette; garage uses separate studio lighting.
 function environment(mode,haze){
  if(mode==='studio')return {sky:[.70,.78,.90],ground:[.045,.055,.075],strength:1.0,studio:1};
  if(mode==='tunnel')return {sky:[.16,.14,.11],ground:[.045,.040,.035],strength:.57,studio:0};
  const sky=haze.map(v=>Math.pow(Math.max(0,Math.min(1,v)),2.2));
  const night=mode==='night', poor=['rain','fog','snow'].includes(mode);
  return {sky:sky.map(v=>v*(night?.75:1.12)+(night?.025:.13)),ground:mode==='snow'?[.30,.34,.38]:[.055,.06,.065],strength:night?.65:poor?.88:1,studio:0};
 }
 function materialKind(index){return index===1||index===2?1:index===6?2:index===9||index===10?3:0;}
 const carLighting=Object.fromEntries(Object.entries({
  clear:[.36,.88,-.30,0],rain:[-.27,.93,-.25,1],snow:[.12,.98,-.18,.26],
  fog:[.16,.98,-.12,.2],night:[-.56,.75,.35,0],tunnel:[.05,.96,.28,0],
  studio:[-.49,.70,-.52,0],
 }).map(([mode,[x,y,z,wet]])=>{
  const length=Math.hypot(x,y,z);
  return [mode,[x/length,y/length,z/length,wet]];
 }));
 // Read only the existing damage counters; garage previews are always clean.
 function damageState(c,mode){return [0,1,2].map(i=>mode==='studio'?0:bounded(finite(c.damage?.[i])/100,0,1));}
 // Hysteresis avoids swapping meshes repeatedly near the distance boundary.
 function rivalLOD(gap,effects,prior){if(!effects)return 0;return Math.abs(gap)<=(prior===1?35:27)?1:0;}
 function draw(gl,cars,camera,aspect,f,haze,fog){if(!cars.length)return;prepare(gl);const {program,loc:u,attrs,batchesFor,vaoExt}=state;gl.useProgram(program);
  gl.uniform3fv(u.eye,[camera.x,camera.y,camera.z]);gl.uniform2fv(u.forward,[camera.fx,camera.fz]);gl.uniform2fv(u.right,[camera.rx,camera.rz]);gl.uniform2fv(u.pitch,[camera.cp,camera.sp]);gl.uniform1f(u.aspect,aspect);gl.uniform1f(u.f,f);gl.uniform3fv(u.haze,haze);gl.uniform1f(u.fog,fog);
  BGSpectralData.pivots.forEach((p,i)=>gl.uniform3fv(u["pivot"+(i+1)],p));
  for(const {c,center,heading,lit,lod,mode,pose} of cars){gl.uniform3fv(u.center,center);gl.uniform2fv(u.heading,[Math.cos(heading),Math.sin(heading)]);gl.uniform1f(u.illumination,Math.min(lit,1.2));
   const {spin,steer,lift}=motion(c);gl.uniform2fv(u.rollWheel,[Math.cos(spin),Math.sin(spin)]);gl.uniform2fv(u.steerWheel,[Math.cos(steer),Math.sin(steer)]);gl.uniform1f(u.bodyLift,pose?.lift??lift);
   const br=pose?.roll||0,bp=pose?.pitch||0;gl.uniform2fv(u.bodyRoll,[Math.cos(br),Math.sin(br)]);gl.uniform2fv(u.bodyPitch,[Math.cos(bp),Math.sin(bp)]);
   const batches=batchesFor(lod),light=lights(c,mode),env=environment(mode,haze);
   const customPaint=c.color&&c.color!=='#1f4b84'&&/^#[0-9a-f]{6}$/i.test(c.color)?[1,3,5].map(i=>Math.pow(parseInt(c.color.slice(i,i+2),16)/255,2.2)):null;
   gl.uniform3fv(u.damageZones,damageState(c,mode));gl.uniform1f(u.damageDetail,lod==='far'?0:1);
   gl.uniform3fv(u.envSky,env.sky);gl.uniform3fv(u.envGround,env.ground);gl.uniform1f(u.envStrength,env.strength);gl.uniform1f(u.studio,env.studio);
   gl.uniform4fv(u.carLight,carLighting[mode]||carLighting.clear);
   for(const b of batches){const m=BGSpectralData.materials[b.material];let base=m.base;
    // Slot 0 uses original Spectral blue. Other saved paints still work.
    if(b.material===0&&customPaint)base=customPaint;
    if(b.material===5&&customPaint)base=customPaint.map(v=>.28*v);
    if(b.material===6)base=[.022,.026,.032]; // original procedural carbon has no baked texture in GLB
    gl.uniform1f(u.paintSurface,b.material===0||b.material===5?1:0);
    gl.uniform1f(u.materialKind,materialKind(b.material));
    gl.uniform3fv(u.base,base);gl.uniform3fv(u.emission,emissionFor(m,b.material,light));gl.uniform4fv(u.finish,[m.metal,m.rough,m.coat,m.coatRough]);
    if(b.vao){vaoExt.bindVertexArrayOES(b.vao);}
    else{if(vaoExt)vaoExt.bindVertexArrayOES(null);gl.bindBuffer(gl.ARRAY_BUFFER,b.v);attrs.forEach((a,i)=>{gl.enableVertexAttribArray(a);gl.vertexAttribPointer(a,i===2?1:3,gl.FLOAT,false,28,i*12);});gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,b.i);}
    gl.drawElements(gl.TRIANGLES,b.count,gl.UNSIGNED_SHORT,0);
   }
  }
  if(vaoExt)vaoExt.bindVertexArrayOES(null);
  attrs.forEach(a=>gl.disableVertexAttribArray(a));
 }
 return {prepare,draw,reset,motion,lights,emissionFor,mounts,environment,materialKind,bodyPose,bodyPoint,damageState,rivalLOD};
})();
