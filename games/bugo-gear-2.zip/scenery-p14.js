'use strict';
// Visual-only placements; track objects and collision logic are untouched.
globalThis.BGSceneryP14=(()=>{
 const desert=[2,7,12], coastal=[0,5,11,14], towns=[0,3,4,5,8,11,13,14], urban=[0,3,8,11,14];
 const cache=new WeakMap(), waterCache=new WeakMap();
 function rivers(track){
  if(waterCache.has(track))return waterCache.get(track);
  const channels=[];
  if([3,5,11,14].includes(track.region)){
   const road=[];
   for(let z=0;z<track.length;z+=7)road.push(track.sample(z));
   const structures=[...track.tunnels,...track.bridges];
   for(const side of [track.index%2?-1:1,track.index%2?1:-1]){
    for(let start=65;start+80<track.length&&channels.length===0;start+=85){
     if(structures.some(part=>part.start-18<start+80&&part.end+18>start))continue;
     const banks=[];
     for(let j=0;j<=8;j++){
      const z=start+10*j, p=track.sample(z);
      const offset=side*(p.width+12+2*Math.sin(j*.75)), half=.55+3*Math.sin(j*Math.PI/8);
      const x=p.px-Math.sin(p.heading)*offset, worldZ=p.py+Math.cos(p.heading)*offset;
      const previous=banks[banks.length-1];
      const clear=(u,v,w,h)=>!road.some(q=>Math.abs(q.y-h)<4&&Math.hypot(u-q.px,v-q.py)<q.width+w+4);
      if(!clear(x,worldZ,half,p.y))break;
      if(previous&&!clear((x+previous.x)/2,(worldZ+previous.worldZ)/2,Math.max(half,previous.half),(p.y+previous.height)/2))break;
      banks.push({z,offset,half,x,worldZ,height:p.y});
     }
     if(banks.length===9)channels.push(banks);
    }
   }
  }
  waterCache.set(track,channels);
  return channels;
 }
 function plan(t){
  if(cache.has(t))return cache.get(t);
  const out=[], occupied=[], extras=[];const models=globalThis.BGKenneyScenery;if(!models)return out;
  const structures=[...t.tunnels,...t.bridges];
  const blocked=z=>structures.some(s=>s.start-18<=z&&z<=s.end+18);
  const roadSamples=[];
  for(let z=0;z<t.length;z+=8)roadSamples.push(t.sample(z));
  const channels=rivers(t);
  const catalog=Object.keys(models);
  const townModels=catalog.filter(k=>k.startsWith('building-type-'));
  const cityModels=catalog.filter(k=>/^building-(?:[a-n]|skyscraper-[a-e])$/.test(k));
  const skylineModels=catalog.filter(k=>k.startsWith('low-detail-building-'));
  const add=(name,z,side,offset,height,kind,anchor=-1)=>{
   const model=models[name];if(!model||z<0||z>=t.length||blocked(z))return;
   const p=t.sample(z),r=Math.hypot(model.width,model.depth)*height/2;
   const x=side*(p.width+offset+r);if(!Number.isFinite(x))return;
   // Reject overlaps with other portions of the road (hairpins/crossings).
   const wx=p.px-Math.sin(p.heading)*x,wz=p.py+Math.cos(p.heading)*x;
   for(const a of roadSamples)if(Math.abs(a.y-p.y)<height+3&&Math.hypot(a.px-wx,a.py-wz)<a.width+r+3)return;
   if(occupied.some(o=>Math.abs(o.y-p.y)<Math.max(height,o.h)&&Math.hypot(o.x-wx,o.z-wz)<r+o.r+0.5))return;
   if(channels.some(banks=>banks.some(bank=>Math.abs(bank.z-z)<12&&Math.hypot(bank.x-wx,bank.worldZ-wz)<r+bank.half+4)))return;
   occupied.push({x:wx,z:wz,y:p.y,r,h:height});
   const turn=name.startsWith('cliff_waterfall')?side*Math.PI/2:kind==='building'?0:((out.length*37)%360)*Math.PI/180;
   out.push({name,z,x,height,kind,anchor,heading:p.heading+turn});
  };
  for(const [i,o] of t.objects.entries()){
   if(o.kind!=='tree'||blocked(o.z))continue;
   const dry=desert.includes(t.region),cold=t.weather==='snow'||[1,6,9,15].includes(t.region),sea=coastal.includes(t.region);
   const choices=dry?['rock_largeA','rock_largeB','rock_tallA','cactus_short','cliff_rock','cactus_tall','rock_smallA','rock_largeC','rock_largeD','rock_largeE','rock_largeF','rock_tallB','rock_tallC','cliff_large_rock']:cold?['tree_pineTallA','tree_pineDefaultA','rock_largeB','tree_pineRoundA','cliff_stone','tree_pineDefaultB','tree_pineTallB','tree_pineTallC','tree_pineRoundB','tree_pineRoundC','cliff_large_stone']:sea?['tree_palmTall','tree_palmShort','tree_oak','tree_palmBend','tree_palmDetailedShort']:['tree_default','tree_oak','tree_pineTallA','tree_detailed','tree_fat','tree_oak_fall','tree_default_dark'];
   const name=choices[(i+t.index)%choices.length],side=Math.sign(o.x)||1;
   add(name,o.z,side,3.5, dry?1.6+i%3:4.8+i%4,'nature',i);
   if(i%3===0&&!dry)add(i%2?'plant_bush':'plant_bushLarge',o.z+8,-side,5,1.1,'nature');
   if(i%4===0&&!dry&&!cold){
    const details=['grass','grass_large','flower_purpleA','flower_redA','flower_yellowA','plant_bushSmall','plant_bushDetailed','plant_flatShort','plant_flatTall'];
    // The setback leaves room for the safety margin used by the road check.
    add(details[(i/4+t.index)%details.length],o.z+4,side,4.2,.5+i%3*.25,'nature');
   }
   if(i%6===0&&[3,5,11,14].includes(t.region)){
    const water=['ground_riverTile','ground_riverBend','ground_riverStraight'];
    add(water[(i+t.index)%3],o.z+27,-side,22,.35,'nature');
    if(i%12===0)add(i%24?'bridge_stone':'bridge_wood',o.z+32,side,16,2,'nature');
   }
   if(i%5===0){const rocks=['rock_smallB','rock_smallC'];add(rocks[(i+t.index)%2],o.z+10,-side,3,1.1,'nature');}
   if(i%7===0&&dry)extras.push(['stone_tallD',o.z+16,-side,9,4,'nature']);
   if(i%6===0&&cold){
    const forest=['tree_pineSmallB','tree_pineTallD','log_stack'];
    const name=forest[(i/6+t.index)%forest.length];
    extras.push([name,o.z+12,-side,11,name==='log_stack'?1.5:5,'nature']);
   }
   if(i%6===0&&!dry&&!cold){
    const name=sea?'tree_palmDetailedTall':'tree_detailed_fall';
    extras.push([name,o.z+11,-side,13,7,'nature']);
   }
   if(i%9===0&&!dry&&!cold&&[3,4,5,13].includes(t.region)){
    const fields=['crops_wheatStageB','crops_cornStageD','crops_bambooStageB','fence_planks','fence_simple','fence_simpleLow'];
    add(fields[(i+t.index)%fields.length],o.z+19,side,8,1.4,'nature');
   }
   if(i%11===0&&[1,3,9,15].includes(t.region)){
    const cliffs=['cliff_cave_rock','cliff_cave_stone','cliff_waterfall_rock','cliff_waterfall_stone','cliff_waterfallTop_stone','cliff_blockSlope_rock','cliff_blockSlope_stone'];
    add(cliffs[(i+t.index)%cliffs.length],o.z+20,-side,18,8,'nature');
   }
   if(i%9===0&&[3,5,11,14].includes(t.region)){
    const endModels=['ground_riverEnd','ground_riverRocks'];
    extras.push([endModels[(i/9+t.index)%endModels.length],o.z+36,-side,27,.6,'nature']);
   }
   if(i%7===0&&towns.includes(t.region)){
    const city=urban.includes(t.region)&&t.stage===2;
    const names=city?cityModels:townModels;
    add(names[(i+t.index)%names.length],o.z+13,-side,12,city?10+i%9:5+i%3,'building');
    if(city)add(skylineModels[(i+t.index)%skylineModels.length],o.z+21,side,30,12+i%8,'building');
    else {const details=['fence','fence-low','planter','tree-large','tree-small','path-stones-short','driveway-short','fence-1x3','driveway-long','path-stones-messy'];add(details[(i+t.index)%details.length],o.z+22,side,7,1.3,'nature');}

   }
   if(i%8===0&&urban.includes(t.region)){
    const service=['electricity-pole-single','construction-fence','construction-light'];
    const model=service[(i/8+t.index)%service.length];
    extras.push([model,o.z+17,side,6,model==='electricity-pole-single'?7:1.8,'nature']);
   }
  }
  for(const args of extras)add(...args);
  cache.set(t,out);return out;
 }
 return {plan,rivers};
})();
