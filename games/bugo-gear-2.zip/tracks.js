'use strict';
globalThis.BGTracks = (() => {
  const regions = [
    ['Costa de Cobre','Copper Coast'], ['Serra Azul','Blue Range'],
    ['Dunas do Sal','Salt Dunes'], ['Lagos de Vidro','Glass Lakes'],
    ['Vale do Cedro','Cedar Vale'], ['Ilhas do Vento','Wind Isles'],
    ['Campos de Geada','Frost Fields'], ['Deserto de Ferro','Iron Desert'],
    ['Costa das Brumas','Mist Coast'], ['Montes de Basalto','Basalt Peaks'],
    ['Floresta Lunar','Moon Forest'], ['Península do Sol','Sun Peninsula'],
    ['Chapada Rubra','Red Mesa'], ['Campos de Prata','Silver Plains'],
    ['Baía do Farol','Beacon Bay'], ['Estrada Boreal','Boreal Road']
  ];
  const stages = [['Travessia','Crossing'],['Mirante','Overlook'],['Circuito','Circuit'],['Passo','Pass']];
  const climates = ['clear','rain','clear','fog','clear','rain','snow','clear','fog','night','night','clear','clear','snow','rain','snow'];
  const mod = (n,d) => ((n%d)+d)%d;
  const lerp = (a,b,t) => a+(b-a)*t;
  const angle = (a,b) => mod(b-a+Math.PI,2*Math.PI)-Math.PI;
  function curve(a,b,c,d,t) {
    return b + .5*t*(c-a+t*(2*a-5*b+4*c-d+t*(3*b-a-3*c+d)));
  }
  function create(index) {
    const [length,laps,points,structures,pickups] = BGTrackData[index];
    const region = index >> 2, stage = index % 4;
    const weather = stage === 2 && region % 3 === 0 ? 'night' : climates[region];
    const raw = [];
    const point = i => points[mod(i,points.length)];
    let distance = 0;
    for (let k=0;k<=points.length*32;k++) {
      const i = k>>5, fraction = (k%32)/32;
      const p = [0,1,2,3].map(n => curve(point(i-1)[n],point(i)[n],point(i+1)[n],point(i+2)[n],fraction));
      if (k) distance += Math.hypot(p[0]-raw[k-1].p[0],p[1]-raw[k-1].p[1]);
      raw.push({distance,p});
    }
    const scale = length/distance, count = Math.ceil(length/4);
    const road = [];
    let rawIndex = 0;
    for (let i=0;i<count;i++) {
      const d = distance*i/count;
      while (raw[rawIndex+1].distance < d) rawIndex++;
      const a=raw[rawIndex], b=raw[rawIndex+1], f=(d-a.distance)/(b.distance-a.distance);
      road.push({px:lerp(a.p[0],b.p[0],f)*scale,py:lerp(a.p[1],b.p[1],f)*scale,
        y:lerp(a.p[2],b.p[2],f),width:lerp(a.p[3],b.p[3],f)/10});
    }
    road.forEach((p,i) => {
      const a=road[mod(i-1,count)], b=road[(i+1)%count];
      p.heading=Math.atan2(b.py-a.py,b.px-a.px);
    });
    road.forEach((p,i) => p.curvature=angle(road[mod(i-1,count)].heading,road[(i+1)%count].heading)/(2*length/count));
    function sample(z) {
      const position=mod(z,length)/length*count, i=Math.floor(position), t=position-i;
      const a=road[i%count], b=road[(i+1)%count];
      return {x:lerp(a.px,b.px,t),px:lerp(a.px,b.px,t),py:lerp(a.py,b.py,t),
        y:lerp(a.y,b.y,t),width:lerp(a.width,b.width,t),
        heading:a.heading+angle(a.heading,b.heading)*t,curvature:lerp(a.curvature,b.curvature,t)};
    }
    const xs=road.map(p=>p.px), ys=road.map(p=>p.py), minX=Math.min(...xs), minY=Math.min(...ys);
    const w=Math.max(...xs)-minX,h=Math.max(...ys)-minY, extent=Math.max(w,h);
    function mapPoint(z) {
      const {px,py}=sample(z);
      return {x:.5+(px-minX-w/2)*.88/extent,y:.5+(py-minY-h/2)*.88/extent};
    }
    const map=Array.from({length:129},(_,i)=>mapPoint(length*i/128));
    const objects=pickups.map(([fraction,x,kind])=>({z:length*fraction,x,kind}));
    for (let z=75,n=0;z<length-35;z+=33+(++n*(index+7)%24)) {
      const edge=sample(z).width, side=n%2 ? 1 : -1;
      objects.push({z,x:side*(edge+1.6+n%4),kind:n%9===0?'barrier':n%4===0?'sign':'tree'});
    }
    objects.sort((a,b)=>a.z-b.z);
    const ranges=kind=>structures.filter(s=>s[0]===kind).map(([,start,end])=>({start:start*length,end:end*length,height:7}));
    return {index,region,stage,length,laps,weather,sample,objects,map,mapPoint,tunnels:ranges('tunnel'),bridges:ranges('bridge'),
      name:[0,1].map(i=>regions[region][i]+' / '+stages[stage][i])};
  }
  return {create,mod,count:BGTrackData.length};
})();
