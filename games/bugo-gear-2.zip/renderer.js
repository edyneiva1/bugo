(function (global) {
  'use strict';

  const terrains = {
    clear: ['#326274', '#5e9fa3', '#edab74', '#475865', '#344855', '#283f38', '#36514a', '#606063', '#54565d', '#c45241', '#ead2a0', '#edcf92'],
    rain: ['#344552', '#70808a', '#a1a9a2', '#4d5c64', '#34464e', '#303e37', '#3a4940', '#4e565d', '#474e58', '#8d5752', '#bbb39a', '#c5c2aa'],
    snow: ['#4a6987', '#909fb5', '#d6d8d1', '#798493', '#5c6e7f', '#9eaeb3', '#b9c5c2', '#66707a', '#5b6871', '#ab5e59', '#e5e6da', '#d5d5c5'],
    fog: ['#677879', '#acb2a3', '#d6c7a2', '#849190', '#67746f', '#4c604f', '#5e6d55', '#686a68', '#606561', '#935c50', '#c2b69e', '#d8c6a3'],
    night: ['#201e39', '#353750', '#cc956c', '#37354a', '#25283d', '#232f32', '#29383b', '#505368', '#474a61', '#9b4c56', '#e2b17d', '#eac897']
  };
  const biomes = [
    ['coast','pine', '#3b6473','#81b5ae','#567582','#426573','#476252','#58735f'],
    ['ridge','fir', '#3f537c','#7ba5b8','#667c8c','#414d70','#364d49','#43594e'],
    ['dune','stone', '#85738d','#e5a66e','#b4745d','#a25f4e','#987555','#a78560'],
    ['lake','reed', '#416a7c','#91b8b8','#537983','#40707b','#416369','#52767c'],
    ['forest','cedar', '#37675d','#91b58b','#567567','#36594b','#3f654a','#4c754e'],
    ['cliff','cypress', '#406781','#8ab9bf','#5d8591','#4d696c','#4b6359','#5a7465'],
    ['ridge','fir', '#475f8b','#98b6ca','#8798b0','#687e9c','#91a5b3','#b3c3cb'],
    ['mesa','cactus', '#8a6478','#d69470','#9d6756','#754c46','#865747','#9b6650'],
    ['coast','reed', '#5e777c','#a0b6ac','#698c86','#557676','#536b61','#637f6f'],
    ['mesa','stone', '#514d71','#8f7797','#6a5576','#50435c','#534859','#615065'],
    ['forest','fir', '#333f66','#67708d','#4e5f77','#3d4866','#354a43','#425a4c'],
    ['coast','palm', '#487996','#90c1bb','#61949a','#548382','#61784e','#768c5c'],
    ['mesa','cactus', '#826c83','#d3a37a','#b1745e','#855b5b','#976648','#a98057'],
    ['plain','stone', '#5f7192','#a4b3bd','#8393a1','#6d8294','#889da6','#a0b2b7'],
    ['harbor','lamp', '#45677e','#8eaab2','#59768b','#425d77','#485b64','#596d75'],
    ['ridge','fir', '#3d6380','#94b0c7','#829cae','#627e97','#73929c','#8ca8af']
  ];
  const bodies = [
    { sides: [10, 29], top: [13, 25, 2], glass: [15, 23, 4], wing: 0 },
    { sides: [7, 31], top: [11, 27, 4], glass: [13, 25, 6], wing: 1 },
    { sides: [12, 27], top: [15, 24, 1], glass: [16, 23, 3], wing: 2 },
    { sides: [9, 30], top: [12, 26, 3], glass: [14, 24, 5], wing: 3 }
  ];
  const sprites = new Map();
  const skies = new Map();
  const palettes = new Map();
  const mod = (a, b) => ((a % b) + b) % b;

  function blend(a, b, alpha) {
    const channel = i => Math.round(parseInt(a.slice(i, i + 2), 16) * (1 - alpha) + parseInt(b.slice(i, i + 2), 16) * alpha);
    return `rgb(${channel(1)},${channel(3)},${channel(5)})`;
  }

  function regionalPalette(weather, biome) {
    const key = `${weather}/${biomes.indexOf(biome)}`;
    if (palettes.has(key)) return palettes.get(key);
    const original = terrains[weather];
    const strength = { clear: 1, rain: 0.54, snow: 0.5, fog: 0.48, night: 0.37 }[weather];
    const palette = original.map((color, i) => {
      const tint = biome[[2, 3, -1, 4, 5, 6, 7][i]];
      return tint ? blend(color, tint, strength) : color;
    });
    palettes.set(key, palette);
    return palette;
  }

  function box(ctx, color, x, y, w, h) {
    ctx.fillStyle = color;
    ctx.fillRect(Math.round(x), Math.round(y), Math.ceil(w), Math.ceil(h));
  }

  function polygon(ctx, color, points) {
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.moveTo(Math.round(points[0]), Math.round(points[1]));
    for (let i = 2; i < points.length; i += 2) ctx.lineTo(Math.round(points[i]), Math.round(points[i + 1]));
    ctx.closePath();
    ctx.fill();
  }

  function canvas(w, h) {
    const image = document.createElement('canvas');
    image.width = w;
    image.height = h;
    return image;
  }

  function skyline(palette, weather, biome, biomeId) {
    const key = `${weather}/${biomeId}`;
    if (skies.has(key)) return skies.get(key);
    const image = canvas(384, 96);
    const ctx = image.getContext('2d');
    box(ctx, palette[0], 0, 0, 384, 96);
    box(ctx, palette[1], 0, 48, 384, 48);
    for (let stripe = 0; stripe < 10; stripe++) {
      for (let x = stripe % 2; x < 384; x += 2) box(ctx, palette[0], x, 43 + stripe, 1, 1);
    }
    if (weather === 'night') {
      for (let i = 0; i < 49; i++) box(ctx, i % 4 ? '#788095' : '#ebd5af', (i * 157) % 384, 7 + (i * 29) % 55, 1, 1);
    }
    if (weather === 'clear' || weather === 'night') {
      for (let y = -12; y <= 12; y++) {
        const edge = Math.floor(Math.sqrt(155 - y * y));
        box(ctx, palette[2], 235 - edge, 36 + y, edge * 2 + 1, 1);
      }
    }
    const silhouettes = [];
    const type = biome[0];
    for (let layer = 0; layer < 2; layer++) {
      const silhouette = canvas(384, 96);
      const land = silhouette.getContext('2d');
      for (let x = 0; x < 384; x++) {
        const a = x * Math.PI / 192 + biomeId * Math.PI / 8;
        const wave = Math.sin(a * 4 + layer) + Math.cos(a * 7 + 2 * layer) * 0.45;
        let edge = 78 + layer * 9 + 5 * wave;
        if (type === 'ridge') edge -= 23 * Math.pow(Math.max(0, Math.cos(a * 3 + layer)), 2.5) + 4 * Math.sin(a * 11);
        if (type === 'dune') edge = 73 + layer * 10 + 11 * Math.sin(a * 3 + layer * 1.7) + 4 * Math.sin(a * 6);
        if (type === 'mesa' && Math.sin(a * 3 + layer) > 0.16) edge -= 15 + 2 * Math.floor(wave);
        if (type === 'forest') edge -= Math.abs(7 - mod(x + layer * 5, 14)) + mod(x >> 3, 3);
        if (type === 'cliff') edge -= Math.floor(6 * Math.max(0, Math.sin(a * 5 + layer))) * 3;
        if (type === 'plain' || type === 'lake') edge = 78 + layer * 8 + 3 * Math.sin(a * 5);
        if (type === 'harbor') edge -= mod(Math.floor(x / 8) * 47 + layer * 11, 17);
        box(land, palette[3 + layer], x, edge, 1, 96 - edge);
        if (weather === 'snow' && type === 'ridge' && x % 5 !== 0) box(land, '#c4c9cb', x, edge, 1, 3 + x % 4);
      }
      if (layer === 1 && ['lake', 'coast', 'harbor'].includes(type)) {
        const water = weather === 'night' ? '#474361' : '#679b9c';
        box(land, water, 0, 88, 384, 8);
        for (let i = 0; i < 19; i++) box(land, palette[3], (i * 127) % 381, 88 + i % 7, 3 + i % 11, 1);
      }
      silhouettes.push(silhouette);
    }
    const layers = [image, ...silhouettes];
    skies.set(key, layers);
    return layers;
  }

  function carSprite(color, direction, braking, bodyId) {
    const key = `${color}/${direction}/${braking}/${bodyId}`;
    if (sprites.has(key)) return sprites.get(key);
    const image = canvas(38, 22);
    const ctx = image.getContext('2d');
    const shift = direction * 2;
    const { sides: [left, right], top: [roofLeft, roofRight, roofY], glass: [glassLeft, glassRight, glassY], wing } = bodies[bodyId];
    polygon(ctx, '#1a2026', [1, 20, 5, 16, 33, 16, 37, 20, 32, 22, 6, 22]);
    box(ctx, '#171921', 3, 13, 7, 8);
    box(ctx, '#171921', 28, 13, 7, 8);
    polygon(ctx, '#24263a', [2, 15, 5, 9, left + shift, 8, roofLeft + shift, roofY, roofRight + shift, roofY, right + shift, 8, 33, 9, 36, 15, 33, 19, 5, 19]);
    polygon(ctx, color, [3, 15, 6, 10, left + 1 + shift, 9, roofLeft + 1 + shift, roofY + 1,
      roofRight - 1 + shift, roofY + 1, right - 1 + shift, 9, 32, 10, 35, 15, 32, 17, 6, 17]);
    polygon(ctx, '#203340', [left + 2 + shift, 9, glassLeft + shift, glassY, glassRight + shift, glassY, right - 2 + shift, 9]);
    box(ctx, '#527788', glassLeft + shift, glassY + 1, glassRight - glassLeft, 1);
    box(ctx, '#9ebcc2', glassLeft + shift + 1, glassY+1, Math.max(1,glassRight-glassLeft-4),1);
    if (wing) {
      box(ctx, '#24263a', 4 + wing, 9, 30 - 2 * wing, 2);
      box(ctx, '#a4a9a3', 7 + wing, 9, 24 - 2 * wing, 1);
    }
    box(ctx, '#343343', 5, 12, 28, 3);
    const lamp = braking ? '#ff9a65' : '#db4a42';
    if (wing === 2) {
      for (const x of [7, 11, 25, 29]) box(ctx, lamp, x, 12, 3, 2);
    } else {
      box(ctx, lamp, 6, 12, 7 + (wing % 2), 2);
      box(ctx, lamp, 25 - (wing % 2), 12, 7 + (wing % 2), 2);
    }
    box(ctx, '#f4d7a3', 16, 13, 6, 2);
    box(ctx, '#f0d6be', 9+shift, 10, 11, 1);
    box(ctx, '#913c48', 22, 11, 9, 1);
    box(ctx, '#292b39', 11, 15, 17, 1);
    for(const x of [6,8,29,31])box(ctx,braking?'#ffd7a3':'#f08266',x,12,1,1);
    for(const x of [4,32])for(let y=16;y<=19;y+=2)box(ctx,'#384250',x,y,2,1);
    box(ctx, '#a4a9a3', 8, 17, 22, 1);
    box(ctx, '#bdc8c9', 25, 18, 5, 2);
    box(ctx, '#292933', 26, 19, 3, 1);
    sprites.set(key, image);
    return image;
  }

  function drawCar(ctx, car, point, frame) {
    const drift = Math.abs(car.spin || 0) > 0.06;
    const steering = drift ? Math.sign(car.spin) : Math.abs(car.steer || 0) < 0.2 ? 0 : Math.sign(car.steer);
    const sprite = carSprite(car.color || '#42a8a0', steering, !!car.brake, mod(car.body ?? car.id ?? 0, bodies.length));
    const width = Math.max(3, Math.round(point.scale * (drift ? 4.1 : 4.5)));
    const height = Math.max(2, Math.round(width * sprite.height / sprite.width));
    if (drift && width > 9) {
      box(ctx, '#333744', point.x - width * 0.33, point.y - 1, 2, 4);
      box(ctx, '#333744', point.x + width * 0.26, point.y - 1, 2, 4);
    }
    ctx.drawImage(sprite, Math.round(point.x - width / 2), Math.round(point.y - height), width, height);
    if (car.boost > 0) {
      const length = Math.max(1, Math.round(width * (0.08 + frame % 3 * 0.035)));
      box(ctx, '#fa7140', point.x + width * 0.21, point.y - length, length, length);
      box(ctx, '#f8ce76', point.x + width * 0.23, point.y - length, 1, length);
    }
  }

  function preview(ctx, car, x, y, width) {
    const sprite = carSprite(car.color || '#42a8a0', 0, false, mod(car.body ?? car.id ?? 0, bodies.length));
    ctx.drawImage(sprite, x, y, width, Math.round(width * sprite.height / sprite.width));
  }

  function drawObject(ctx, object, point, weather, biome) {
    const { x, y, scale } = point;
    const unit = Math.max(1, scale);
    if (object.kind === 'tree') {
      const variant = object.variant || biome[1];
      if (variant === 'stone') {
        polygon(ctx, '#4d4d59', [x - unit * 1.5, y, x - unit, y - unit * 1.3, x + unit * 0.25, y - unit * 1.8, x + unit * 1.5, y - unit * 0.6, x + unit * 1.7, y]);
        polygon(ctx, '#8c7d78', [x - unit * 1.1, y - unit * 0.5, x - unit, y - unit * 1.3, x + unit * 0.25, y - unit * 1.8, x + unit * 0.82, y - unit * 0.95]);
        return;
      }
      if (variant === 'cactus' || variant === 'reed' || variant === 'lamp') {
        const tone = variant === 'cactus' ? '#547e60' : variant === 'reed' ? '#9b9865' : '#ab8c73';
        const size = variant === 'reed' ? 2.6 : 4.5;
        box(ctx, '#3f4640', x - unit * 0.23, y - unit * size, unit * 0.46, unit * size);
        box(ctx, tone, x - unit * 0.16, y - unit * size, unit * 0.26, unit * size);
        if (variant === 'lamp') {
          box(ctx, '#323943', x - unit * 0.62, y - unit * size, unit * 1.24, unit * 0.65);
          box(ctx, '#ead4a3', x - unit * 0.5, y - unit * (size - 0.28), unit, unit * 0.3);
        } else {
          for (const side of [-1,1]) {
            box(ctx, tone, x + side * unit * 0.72, y - unit * (size - 0.7 + side * 0.22), unit * 0.28, unit * 0.9);
            box(ctx, tone, side < 0 ? x - unit * 0.72 : x, y - unit * (size - 1.5 + side * 0.22), unit * 0.84, unit * 0.24);
          }
        }
        return;
      }
      if (variant === 'palm') {
        polygon(ctx, '#785b4d', [x - unit * 0.3,y,x + unit * 0.3,y,x + unit * 0.6,y - unit * 4.9,x + unit * 0.18,y - unit * 4.9]);
        for (const side of [-1,1]) {
          polygon(ctx, '#405d46', [x + unit * 0.4,y - unit * 4.8,x + side * unit * 1.45,y - unit * 5.5,x + side * unit * 2.75,y - unit * 4.25,x + side * unit * 1.35,y - unit * 4.65]);
          polygon(ctx, '#7b9357', [x + unit * 0.4,y - unit * 4.85,x + side * unit * 1.05,y - unit * 5.8,x + side * unit * 2.12,y - unit * 5.52]);
        }
        return;
      }
      box(ctx, '#4d3c3b', x - unit * 0.22, y - unit * 2.8, unit * 0.44, unit * 2.8);
      const spread = variant === 'cypress' ? 0.55 : variant === 'cedar' ? 1.2 : 1;
      for (let i = 0; i < 3; i++) {
        const crown = y - unit * (5.8 - i);
        polygon(ctx, '#213d3a', [x, crown, x + unit * spread * (1.6 + i * 0.35), crown + unit * 3, x - unit * spread * (1.6 + i * 0.35), crown + unit * 3]);
        polygon(ctx, weather === 'snow' ? '#d1d8cc' : '#54785b', [x, crown, x, crown + unit * 2.35, x - unit * spread * (1.1 + i * 0.25), crown + unit * 2.5]);
      }
      return;
    }
    const pickup = ['nitro','fuel','cash','boost'].includes(object.kind);
    const width = unit * (pickup ? 1.05 : 1.9);
    const height = unit * (pickup ? 0.85 : 0.8);
    const top = y - height - unit * (pickup ? 0.2 : 0.65);
    if (!pickup) box(ctx, '#4e4846', x - unit * 0.12, top, unit * 0.24, y - top);
    box(ctx, '#252838', x - width / 2, top, width, height);
    const tone = { fuel:'#e2b95f', nitro:'#63d2d2', cash:'#8fd38f', boost:'#fa8d68', barrier:'#d58e71' }[object.kind] || '#e2c17a';
    box(ctx, tone, x - width * 0.39, top + height * 0.18, width * 0.78, height * 0.64);
    if (width > 6) {
      if (object.kind === 'barrier' || object.kind === 'boost') {
        polygon(ctx, '#483c48', [x - width * .34,top + height * .7,x - width * .13,top + height * .22,x + width * .08,top + height * .22,x - width * .14,top + height * .7]);
        polygon(ctx, '#483c48', [x + width * .08,top + height * .7,x + width * .29,top + height * .22,x + width * .38,top + height * .22,x + width * .28,top + height * .7]);
      } else box(ctx, '#635354', x - width * 0.09, top + height * 0.35, width * 0.18, height * 0.34);
    }
  }

  function stripe(ctx, color, near, far, middle, width) {
    polygon(ctx, color, [near.x + near.half * (middle - width), near.y, near.x + near.half * (middle + width), near.y,
      far.x + far.half * (middle + width), far.y, far.x + far.half * (middle - width), far.y]);
  }

  function tunnelAt(tunnels, z, length) {
    const position = mod(z, length);
    return tunnels.find(({ start, end }) => start <= position && position < end);
  }

  function drawTunnel(ctx, near, far, tunnel, dark, portal) {
    const height = tunnel.height || 6;
    const nearRoof = near.y - near.scale * height;
    const farRoof = far.y - far.scale * height;
    const nearWall = near.half * 1.17;
    const farWall = far.half * 1.17;
    const concrete = dark ? '#514950' : '#68606a';
    for (const side of [-1, 1]) {
      polygon(ctx, concrete, [near.x + side * nearWall, near.y, near.x + side * nearWall, nearRoof,
        far.x + side * farWall, farRoof, far.x + side * farWall, far.y]);
      polygon(ctx, '#a78b73', [near.x + side * nearWall, near.y - near.scale * 0.7,
        far.x + side * farWall, far.y - far.scale * 0.7, far.x + side * farWall, far.y - far.scale * 0.48,
        near.x + side * nearWall, near.y - near.scale * 0.48]);
    }
    polygon(ctx, dark ? '#37333c' : '#45404b', [near.x - nearWall, nearRoof, near.x + nearWall, nearRoof,
      far.x + farWall, farRoof, far.x - farWall, farRoof]);
    if (!dark) {
      polygon(ctx, '#efc98e', [near.x - near.scale * 0.28, nearRoof, near.x + near.scale * 0.28, nearRoof,
        far.x + far.scale * 0.28, farRoof, far.x - far.scale * 0.28, farRoof]);
    }
    if (portal) {
      const beam = Math.max(2, near.scale * 0.75);
      box(ctx, '#746579', near.x - nearWall - beam, nearRoof - beam, 2 * (nearWall + beam), beam);
      box(ctx, '#504652', near.x - nearWall - beam, nearRoof, beam, near.y - nearRoof);
      box(ctx, '#504652', near.x + nearWall, nearRoof, beam, near.y - nearRoof);
      box(ctx, '#d3a876', near.x - nearWall - beam, nearRoof - beam, 2 * (nearWall + beam), 1);
    }
  }

  function drawBridge(ctx, near, far, dark) {
    for (const side of [-1, 1]) {
      const nearX = near.x + side * near.half * 1.15;
      const farX = far.x + side * far.half * 1.15;
      const nearRail = near.y - near.scale * 1.25;
      const farRail = far.y - far.scale * 1.25;
      polygon(ctx, dark ? '#665f67' : '#817980', [nearX,nearRail,farX,farRail,farX,farRail + far.scale * 0.23,nearX,nearRail + near.scale * 0.23]);
      if (!dark) box(ctx, '#575561', farX - far.scale * 0.17, farRail, far.scale * 0.34, far.y - farRail);
    }
  }

  function view(ctx, w, h, top, race, driver, frame) {
    const track = race.track;
    const weather = terrains[track.weather] ? track.weather : 'clear';
    const biomeId = mod(track.biome ?? track.region ?? 0, biomes.length);
    const biome = biomes[biomeId];
    const p = regionalPalette(weather, biome);
    const split = h < 150;
    const horizon = Math.round(h * (split ? 0.39 : 0.665));
    const tireLine = Math.min(h - 18, Math.round(h * (split ? 0.77 : 0.92)));
    const focal = w * 0.87;
    const follow = split ? 28 : 22;
    const cameraZ = driver.z - follow;
    const here = track.sample(driver.z);
    const rear = track.sample(cameraZ);
    const planar = Number.isFinite(here.px) && Number.isFinite(here.py) && Number.isFinite(here.heading);
    const heading = planar ? Math.atan2(here.py - rear.py, here.px - rear.px) : 0;
    const rightX = -Math.sin(heading);
    const rightY = Math.cos(heading);
    const tangent = planar ? 0 : (here.x - rear.x) / follow;
    const pitch = Math.max(-0.18, Math.min(0.18, (here.y - rear.y) / follow));
    const cameraX = rear.x + driver.x * 0.68;
    const cameraY = here.y - pitch * follow + (tireLine - horizon) * follow / focal;
    const farClip = 510;
    const tunnels = track.tunnels || [];
    const bridges = track.bridges || [];
    const inTunnel = tunnelAt(tunnels, cameraZ, track.length);

    function project(z, lateral, sample) {
      const depth = z - cameraZ;
      const scale = focal / depth;
      const angle = planar ? sample.heading - heading : 0;
      const facing = Math.cos(angle);
      const localX = planar ? (sample.px - rear.px) * rightX + (sample.py - rear.py) * rightY + lateral * facing - driver.x * 0.68 :
        sample.x + lateral - cameraX - tangent * depth;
      return {
        x: w / 2 + localX * scale,
        y: horizon + (cameraY + pitch * depth - sample.y) * scale,
        half: sample.width * scale * Math.max(0.55, facing),
        scale
      };
    }

    ctx.save();
    ctx.translate(0, top);
    ctx.beginPath();
    ctx.rect(0, 0, w, h);
    ctx.clip();
    ctx.imageSmoothingEnabled = false;
    if (inTunnel) {
      box(ctx, '#302a34', 0, 0, w, h);
      box(ctx, '#39313b', 0, horizon * 0.65, w, h - horizon * 0.65);
    } else {
      const layers = skyline(p, weather, biome, biomeId);
      ctx.drawImage(layers[0], 0, 0, w, horizon + 6);
      for (let i = 1; i < layers.length; i++) {
        const shift = Math.round(mod(planar ? heading * w * i / (Math.PI * 2) : (here.x * 0.16 + tangent * 19) * i, w));
        ctx.drawImage(layers[i], -shift, 0, w, horizon + 6);
        ctx.drawImage(layers[i], w - shift, 0, w, horizon + 6);
      }
    }
    box(ctx, p[5], 0, horizon + 5, w, h - horizon);

    const stride = 5;
    const baseZ = Math.floor((cameraZ + 9) / stride) * stride;
    const slices = [];
    const visible = [];
    let covered = h;
    for (let z = baseZ; z < cameraZ + farClip; z += stride) {
      const near = project(z, 0, track.sample(z));
      const far = project(z + stride, 0, track.sample(z + stride));
      slices.push({ z, near, far, covered });
      if (Math.round(far.y) >= covered) continue;
      visible.push({ z, near, far, covered });
      covered = Math.round(far.y);
    }

    for (let i = visible.length - 1; i >= 0; i--) {
      const { z, near, far, covered: clip } = visible[i];
      const alt = mod(Math.floor(z / 15), 2);
      const tunnel = tunnelAt(tunnels, z + stride * 0.5, track.length);
      const bridge = tunnelAt(bridges, z + stride * 0.5, track.length);
      ctx.save();
      ctx.beginPath();
      ctx.rect(0, 0, w, Math.max(0, clip + 1));
      ctx.clip();
      box(ctx, bridge ? (alt ? '#537b80' : '#608a90') : p[5 + alt], 0, far.y, w, near.y - far.y + 1);
      stripe(ctx, p[9 + alt], near, far, 0, 1.12);
      stripe(ctx, tunnel ? (alt ? '#4b444b' : '#585059') : p[7 + alt], near, far, 0, 1);
      stripe(ctx, p[11], near, far, -0.965, 0.018);
      stripe(ctx, p[11], near, far, 0.965, 0.018);
      if (mod(Math.floor(z / 10), 3) === 0) {
        stripe(ctx, p[11], near, far, -1 / 3, 0.019);
        stripe(ctx, p[11], near, far, 1 / 3, 0.019);
      }
      if (mod(z, track.length) < stride) {
        for (let tile = 0; tile < 16; tile++) stripe(ctx, tile % 2 ? '#282630' : '#e0d7ba', near, far, -0.9375 + tile * 0.125, 0.0625);
      }
      if (tunnel) drawTunnel(ctx, near, far, tunnel, !alt, tunnel !== tunnelAt(tunnels, z - stride * 0.5, track.length));
      if (bridge) drawBridge(ctx, near, far, !alt);
      ctx.restore();
    }

    const objects = [];
    function requireVisible(entity, isCar, z) {
      const index = Math.floor((z - baseZ) / stride);
      if (index < 0 || index >= slices.length) return;
      const point = project(z, entity.x, track.sample(z));
      const clip = entity === driver ? tireLine + 1 : slices[index].covered;
      if (point.x < -45 || point.x > w + 45) return;
      objects.push({ entity, isCar, point, clip, z });
    }

    for (const car of race.cars) requireVisible(car, true, cameraZ + mod(car.z - cameraZ, track.length));
    for (const object of track.objects || []) {
      const z = cameraZ + mod(object.z - cameraZ, track.length);
      const pickup = ['nitro','fuel','cash','boost'].includes(object.kind);
      const alreadyPicked = pickup && driver.picked?.has(`${Math.floor((z + 0.00001) / track.length)}:${object.z}`);
      if (!alreadyPicked && !object.collected && !object.used) requireVisible(object, false, z);
    }
    objects.sort((a, b) => b.z - a.z);
    for (const { entity, isCar, point, clip } of objects) {
      ctx.save();
      ctx.beginPath();
      ctx.rect(0, 0, w, Math.max(0, clip + 1));
      ctx.clip();
      if (isCar) drawCar(ctx, entity, point, frame);
      else drawObject(ctx, entity, point, weather, biome);
      ctx.restore();
    }
    if (!inTunnel && (weather === 'rain' || weather === 'snow')) {
      const rain = weather === 'rain';
      ctx.globalAlpha = rain ? 0.42 : 0.82;
      for (let i = 0; i < 55; i++) {
        const x = mod(i * 73 + frame * (rain ? -4 : 1), w);
        const y = mod(i * 117 + frame * (rain ? 7 : 2), h);
        box(ctx, '#e0ebef', x, y, 1, rain ? 3 : 1 + i % 2);
        if (rain) box(ctx, '#b5c9d7', x - 1, y + 3, 1, 2);
      }
    }
    ctx.restore();
  }

  function render(target, race) {
    const ctx = target.getContext('2d');
    const drivers = race.cars.filter(car => car.player > 0);
    const frame = Math.floor((race.time || 0) * 60);
    const h = Math.floor(target.height / Math.max(1, drivers.length));
    drivers.forEach((driver, index) => view(ctx, target.width, h, index * h, race, driver, frame));
    if (drivers.length === 2) box(ctx, '#231e2b', 0, h - 1, target.width, 2);
  }

  global.BGRenderer = { render, preview };
})(globalThis);
