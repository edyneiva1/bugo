(function (global) {
  'use strict';

  const terrains = {
    clear: ['#326274', '#5e9fa3', '#edab74', '#475865', '#344855', '#283f38', '#36514a', '#606063', '#54565d', '#c45241', '#ead2a0', '#edcf92'],
    rain: ['#344552', '#70808a', '#a1a9a2', '#4d5c64', '#34464e', '#303e37', '#3a4940', '#4e565d', '#474e58', '#8d5752', '#bbb39a', '#c5c2aa'],
    snow: ['#4a6987', '#909fb5', '#d6d8d1', '#798493', '#5c6e7f', '#9eaeb3', '#b9c5c2', '#66707a', '#5b6871', '#ab5e59', '#e5e6da', '#d5d5c5'],
    fog: ['#677879', '#acb2a3', '#d6c7a2', '#849190', '#67746f', '#4c604f', '#5e6d55', '#686a68', '#606561', '#935c50', '#c2b69e', '#d8c6a3'],
    night: ['#201e39', '#353750', '#cc956c', '#37354a', '#25283d', '#232f32', '#29383b', '#505368', '#474a61', '#9b4c56', '#e2b17d', '#eac897']
  };
  const biomes = [
    ['coast','pine', '#3b6473','#81b5ae','#567582','#426573','#476252','#58735f'],
    ['ridge','fir', '#3f537c','#7ba5b8','#667c8c','#414d70','#364d49','#43594e'],
    ['dune','stone', '#85738d','#e5a66e','#b4745d','#a25f4e','#987555','#a78560'],
    ['lake','reed', '#416a7c','#91b8b8','#537983','#40707b','#416369','#52767c'],
    ['forest','cedar', '#37675d','#91b58b','#567567','#36594b','#3f654a','#4c754e'],
    ['cliff','cypress', '#406781','#8ab9bf','#5d8591','#4d696c','#4b6359','#5a7465'],
    ['ridge','fir', '#475f8b','#98b6ca','#8798b0','#687e9c','#91a5b3','#b3c3cb'],
    ['mesa','cactus', '#8a6478','#d69470','#9d6756','#754c46','#865747','#9b6650'],
    ['coast','reed', '#5e777c','#a0b6ac','#698c86','#557676','#536b61','#637f6f'],
    ['mesa','stone', '#514d71','#8f7797','#6a5576','#50435c','#534859','#615065'],
    ['forest','fir', '#333f66','#67708d','#4e5f77','#3d4866','#354a43','#425a4c'],
    ['coast','palm', '#487996','#90c1bb','#61949a','#548382','#61784e','#768c5c'],
    ['mesa','cactus', '#826c83','#d3a37a','#b1745e','#855b5b','#976648','#a98057'],
    ['plain','stone', '#5f7192','#a4b3bd','#8393a1','#6d8294','#889da6','#a0b2b7'],
    ['harbor','lamp', '#45677e','#8eaab2','#59768b','#425d77','#485b64','#596d75'],
    ['ridge','fir', '#3d6380','#94b0c7','#829cae','#627e97','#73929c','#8ca8af']
  ];
  const bodies = [
    { sides: [10, 29], top: [13, 25, 2], glass: [15, 23, 4], wing: 0 },
    { sides: [7, 31], top: [11, 27, 4], glass: [13, 25, 6], wing: 1 },
    { sides: [12, 27], top: [15, 24, 1], glass: [16, 23, 3], wing: 2 },
    { sides: [9, 30], top: [12, 26, 3], glass: [14, 24, 5], wing: 3 }
  ];
  const sprites = new Map();
  const skies = new Map();
  const foliage = new Map();
  const grainPatterns = new WeakMap();
  const palettes = new Map();
  const mod = (a, b) => ((a % b) + b) % b;

  function blend(a, b, alpha) {
    const channel = i => Math.round(parseInt(a.slice(i, i + 2), 16) * (1 - alpha) + parseInt(b.slice(i, i + 2), 16) * alpha);
    return `rgb(${channel(1)},${channel(3)},${channel(5)})`;
  }

  function regionalPalette(weather, biome) {
    const key = `${weather}/${biomes.indexOf(biome)}`;
    if (palettes.has(key)) return palettes.get(key);
    const original = terrains[weather];
    const strength = { clear: 1, rain: 0.54, snow: 0.5, fog: 0.48, night: 0.37 }[weather];
    const palette = original.map((color, i) => {
      const tint = biome[[2, 3, -1, 4, 5, 6, 7][i]];
      return tint ? blend(color, tint, strength) : color;
    });
    palettes.set(key, palette);
    return palette;
  }

  function box(ctx, color, x, y, w, h) {
    ctx.fillStyle = color;
    ctx.fillRect(Math.round(x), Math.round(y), Math.ceil(w), Math.ceil(h));
  }

  function polygon(ctx, color, points) {
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.moveTo(Math.round(points[0]), Math.round(points[1]));
    for (let i = 2; i < points.length; i += 2) ctx.lineTo(Math.round(points[i]), Math.round(points[i + 1]));
    ctx.closePath();
    ctx.fill();
  }

  function canvas(w, h) {
    const image = document.createElement('canvas');
    image.width = w;
    image.height = h;
    return image;
  }

  function skyline(palette, weather, biome, biomeId) {
    const key = `${weather}/${biomeId}`;
    if (skies.has(key)) return skies.get(key);
    const image = canvas(384, 96);
    const ctx = image.getContext('2d');
    const sky=ctx.createLinearGradient(0,0,0,96);
    sky.addColorStop(0,palette[0]);sky.addColorStop(.68,palette[1]);
    sky.addColorStop(1,weather==='night'?'#52647d':weather==='snow'?'#d3d9dc':'#b0a99f');
    ctx.fillStyle=sky;ctx.fillRect(0,0,384,96);
    for(let i=0;i<11;i++){
      const x=(i*83)%384, y=19+i*11%42;
      ctx.fillStyle=weather==='night'?'#b7cce411':'#dce8ee20';
      ctx.beginPath();ctx.ellipse(x,y,18+i%4*10,2+i%5,0,0,7);ctx.fill();
    }
    if (weather === 'night') {
      for (let i = 0; i < 49; i++) box(ctx, i % 4 ? '#788095' : '#ebd5af', (i * 157) % 384, 7 + (i * 29) % 55, 1, 1);
    }
    if (weather === 'clear' || weather === 'night') {
      for (let y = -12; y <= 12; y++) {
        const edge = Math.floor(Math.sqrt(155 - y * y));
        box(ctx, palette[2], 235 - edge, 36 + y, edge * 2 + 1, 1);
      }
    }
    const silhouettes = [];
    const type = biome[0];
    for (let layer = 0; layer < 2; layer++) {
      const silhouette = canvas(384, 96);
      const land = silhouette.getContext('2d');
      for (let x = 0; x < 384; x++) {
        const a = x * Math.PI / 192 + biomeId * Math.PI / 8;
        const wave = Math.sin(a * 4 + layer) + Math.cos(a * 7 + 2 * layer) * 0.45;
        let edge = 78 + layer * 9 + 5 * wave;
        if (type === 'ridge') edge -= 23 * Math.pow(Math.max(0, Math.cos(a * 3 + layer)), 2.5) + 4 * Math.sin(a * 11);
        if (type === 'dune') edge = 73 + layer * 10 + 11 * Math.sin(a * 3 + layer * 1.7) + 4 * Math.sin(a * 6);
        if (type === 'mesa' && Math.sin(a * 3 + layer) > 0.16) edge -= 15 + 2 * Math.floor(wave);
        if (type === 'forest') edge -= Math.abs(7 - mod(x + layer * 5, 14)) + mod(x >> 3, 3);
        if (type === 'cliff') edge -= Math.floor(6 * Math.max(0, Math.sin(a * 5 + layer))) * 3;
        if (type === 'plain' || type === 'lake') edge = 78 + layer * 8 + 3 * Math.sin(a * 5);
        if (type === 'harbor') edge -= mod(Math.floor(x / 8) * 47 + layer * 11, 17);
        box(land, palette[3 + layer], x, edge, 1, 96 - edge);
        if (weather === 'snow' && type === 'ridge' && x % 5 !== 0) box(land, '#c4c9cb', x, edge, 1, 3 + x % 4);
      }
      if (layer === 1 && ['lake', 'coast', 'harbor'].includes(type)) {
        const water = weather === 'night' ? '#474361' : '#679b9c';
        box(land, water, 0, 88, 384, 8);
        for (let i = 0; i < 19; i++) box(land, palette[3], (i * 127) % 381, 88 + i % 7, 3 + i % 11, 1);
      }
      silhouettes.push(silhouette);
    }
    const layers = [image, ...silhouettes];
    skies.set(key, layers);
    return layers;
  }

  function carSprite(color, direction, braking, bodyId) {
    const key=`${color}/${direction}/${braking}/${bodyId}`;
    if(sprites.has(key))return sprites.get(key);
    const image=canvas(200,116), c=image.getContext('2d');
    const shift=direction*12, roof=[38,48,31,42][bodyId], wing=[0,1,2,3][bodyId];
    const line=(ink,width,pts)=>{
      c.strokeStyle=ink;c.lineWidth=width;c.lineCap='round';c.beginPath();c.moveTo(pts[0],pts[1]);
      for(let i=2;i<pts.length;i+=2)c.lineTo(pts[i],pts[i+1]);c.stroke();
    };
    const fill=(ink,pts)=>polygon(c,ink,pts);
    const grad=(x,y,u,v,stops)=>{
      const g=c.createLinearGradient(x,y,u,v);
      stops.forEach(([at,k])=>g.addColorStop(at,k));return g;
    };
    const shade=grad(0,30,0,102,[[0,blend(color,'#ffffff',.47)],[.32,color],[.65,blend(color,'#030811',.35)],[1,'#14202b']]);
    const glass=grad(0,24,0,62,[[0,'#7197b2'],[.22,'#354967'],[.57,'#142331'],[1,'#090e15']]);
    const rubber=grad(0,60,16,111,[[0,'#3b4450'],[.35,'#151b23'],[.85,'#06090c'],[1,'#121820']]);
    const metal=grad(0,90,0,108,[[0,'#89949a'],[.23,'#272d33'],[.47,'#637380'],[1,'#13181d']]);
    c.fillStyle='#02050884';c.beginPath();c.ellipse(100,106,89,9,0,0,7);c.fill();
    for(const x of [22,177]){
      c.fillStyle=rubber;c.beginPath();c.ellipse(x,84,14,26,0,0,7);c.fill();
      c.fillStyle='#4a5661';c.beginPath();c.ellipse(x,86,7,17,0,0,7);c.fill();
      c.fillStyle='#1c232b';c.beginPath();c.ellipse(x,86,4,13,0,0,7);c.fill();
      for(let i=0;i<5;i++)line('#76818b',1.4,[x-5,75+i*5,x+5,77+i*5]);
    }
    fill('#111923',[10,72,20,54,46+shift,48,65+shift,roof-13,132+shift,roof-13,153+shift,49,179,55,190,74,183,101,164,109,34,109,17,100]);
    fill(shade,[12,74,24,57,49+shift,50,67+shift,roof-11,130+shift,roof-11,151+shift,51,176,58,188,76,178,96,158,104,40,104,19,96]);
    fill(glass,[52+shift,50,69+shift,roof-8,127+shift,roof-8,148+shift,51,132+shift,57,67+shift,57]);
    line('#b3c7ccaa',2,[59+shift,48,73+shift,roof-6,120+shift,roof-6]);
    line('#708ca478',1,[67+shift,51,132+shift,51]);
    line(blend(color,'#ffffff',.45),2,[20,66,53,61,149,61,181,67]);
    line('#202839',2,[16,79,30,80,171,80,184,79]);
    fill('#0e151e',[23,73,46,69,153,69,178,73,172,87,29,87]);
    if(wing){
      fill('#111923',[44,53,49,40,55,40,54,56,145,56,143,40,150,40,156,53]);
      fill(shade,[29,39,170,39,178,43,173,49,26,49,21,44]);
      line('#7d8792',1.6,[29,40,166,40]);
    }
    const lampBase=braking?'#fa542e':'#be302c';
    for(const x of [35,152]){
      c.save();c.shadowBlur=braking?14:5;c.shadowColor=lampBase;
      c.fillStyle=lampBase;c.fillRect(x-10,74,30,8);c.restore();
      line(braking?'#fff19b':'#ff9160',1.7,[x-7,75,x+16,75]);
      for(let i=0;i<5;i++)line('#571e2b',.8,[x-7+i*5,77,x-7+i*5,82]);
    }
    fill('#252d38',[17,89,43,88,64,95,137,95,158,88,183,89,173,103,27,103]);
    fill(metal,[75,77,125,77,120,90,80,90]);
    fill('#b8c9ce',[84,79,117,79,116,87,85,87]);
    for(let i=0;i<6;i++)line('#445465',1,[89+i*4,81,89+i*4,85]);
    for(const x of wing===2?[48,57,143,152]:[49,151]){
      c.fillStyle='#9babb0';c.beginPath();c.ellipse(x,98,6,4.5,0,0,7);c.fill();
      c.fillStyle='#0b0e14';c.beginPath();c.ellipse(x,99,4.2,3,0,0,7);c.fill();
    }
    line('#596572',1.8,[69,105,131,105]);
    sprites.set(key,image);return image;
  }


  function drawCar(ctx, car, point, frame) {
    const drift = Math.abs(car.spin || 0) > 0.06;
    const steering = drift ? Math.sign(car.spin) : Math.abs(car.steer || 0) < 0.2 ? 0 : Math.sign(car.steer);
    const sprite = carSprite(car.color || '#42a8a0', steering, !!car.brake, mod(car.body ?? car.id ?? 0, bodies.length));
    const width = Math.max(3,point.scale*(drift?5.4:5.9));
    const height = Math.max(2, Math.round(width * sprite.height / sprite.width));
    if (drift && width > 9) {
      box(ctx, '#333744', point.x - width * 0.33, point.y - 1, 2, 4);
      box(ctx, '#333744', point.x + width * 0.26, point.y - 1, 2, 4);
    }
    if(width>13){
      ctx.fillStyle='#04071076';ctx.beginPath();ctx.ellipse(point.x,point.y-1,width*.47,height*.12,0,0,7);ctx.fill();
    }
    ctx.drawImage(sprite,point.x-width/2,point.y-height,width,height);
    const damage=car.damage?Math.max(...car.damage):0;
    if(damage>28&&width>19){
      ctx.strokeStyle=damage>60?'#15151e':'#3d414c';ctx.lineWidth=.45;
      ctx.beginPath();ctx.moveTo(point.x+width*.17,point.y-height*.68);ctx.lineTo(point.x+width*.25,point.y-height*.5);
      ctx.lineTo(point.x+width*.18,point.y-height*.34);ctx.stroke();
    }
    if (car.boost > 0) {
      const length = Math.max(1, Math.round(width * (0.08 + frame % 3 * 0.035)));
      box(ctx, '#fa7140', point.x + width * 0.21, point.y - length, length, length);
      box(ctx, '#f8ce76', point.x + width * 0.23, point.y - length, 1, length);
    }
  }

  function preview(ctx, car, x, y, width) {
    const sprite = carSprite(car.color || '#42a8a0', 0, false, mod(car.body ?? car.id ?? 0, bodies.length));
    ctx.drawImage(sprite, x, y, width, Math.round(width * sprite.height / sprite.width));
  }

  function leafSprite(variant,weather,tint){
    const key=variant+'/'+weather+'/'+tint;
    if(foliage.has(key))return foliage.get(key);
    const sprite=canvas(110,164), c=sprite.getContext('2d');
    const spread=variant==='cypress'?.57:variant==='cedar'?1.08:.89;
    const light=weather==='snow'?'#c8d3cd':tint;
    const trunk=c.createLinearGradient(48,0,64,0);
    trunk.addColorStop(0,'#252424');trunk.addColorStop(.45,'#73635b');trunk.addColorStop(1,'#372f31');
    polygon(c,trunk,[46,162,57,13,61,162]);
    for(let n=0;n<12;n++){
      const y=5+n*11, width=(7+n*3.7)*spread;
      const fill=c.createLinearGradient(54-width,y,54+width,y+25);
      fill.addColorStop(0,light);fill.addColorStop(.55,'#3c6051');fill.addColorStop(1,'#172f2b');
      polygon(c,fill,[55,y,58+width*.27,y+13,55+width,y+31,51+width*.52,y+28,
        55+width*.76,y+35,55+width*.23,y+31,54,y+38,54-width*.43,y+35,
        55-width,y+33,54-width*.62,y+28,54-width*.75,y+29,52-width*.28,y+11]);
      c.strokeStyle=weather==='snow'?'#dce3df88':'#92b19738';
      c.lineWidth=.8;c.beginPath();c.moveTo(54,y+9);
      c.lineTo(54-width*.73,y+30);c.stroke();
    }
    foliage.set(key,sprite);return sprite;
  }

  function surfaceGrain(ctx,w,h){
    if(!grainPatterns.has(ctx)){
      const tile=canvas(73,53), t=tile.getContext('2d');
      for(let i=0;i<680;i++){
        t.fillStyle=i%4?'#e6dfca16':'#10172d20';
        t.fillRect((i*37+i*i)%73,(i*19+i*i)%53,.58+(i%3)*.23,.48);
      }
      grainPatterns.set(ctx,ctx.createPattern(tile,'repeat'));
    }
    const pattern=grainPatterns.get(ctx);
    if(pattern){ctx.fillStyle=pattern;ctx.fillRect(0,0,w,h);}
  }

  function drawObject(ctx, object, point, weather, biome) {
    const { x, y, scale } = point;
    const unit = Math.max(1, scale);
    if (object.kind === 'tree') {
      const variant = object.variant || biome[1];
      if (variant === 'stone') {
        polygon(ctx, '#4d4d59', [x - unit * 1.5, y, x - unit, y - unit * 1.3, x + unit * 0.25, y - unit * 1.8, x + unit * 1.5, y - unit * 0.6, x + unit * 1.7, y]);
        polygon(ctx, '#8c7d78', [x - unit * 1.1, y - unit * 0.5, x - unit, y - unit * 1.3, x + unit * 0.25, y - unit * 1.8, x + unit * 0.82, y - unit * 0.95]);
        return;
      }
      if (variant === 'cactus' || variant === 'reed' || variant === 'lamp') {
        const tone = variant === 'cactus' ? '#547e60' : variant === 'reed' ? '#9b9865' : '#ab8c73';
        const size = variant === 'reed' ? 2.6 : 4.5;
        box(ctx, '#3f4640', x - unit * 0.23, y - unit * size, unit * 0.46, unit * size);
        box(ctx, tone, x - unit * 0.16, y - unit * size, unit * 0.26, unit * size);
        if (variant === 'lamp') {
          box(ctx, '#323943', x - unit * 0.62, y - unit * size, unit * 1.24, unit * 0.65);
          box(ctx, '#ead4a3', x - unit * 0.5, y - unit * (size - 0.28), unit, unit * 0.3);
        } else {
          for (const side of [-1,1]) {
            box(ctx, tone, x + side * unit * 0.72, y - unit * (size - 0.7 + side * 0.22), unit * 0.28, unit * 0.9);
            box(ctx, tone, side < 0 ? x - unit * 0.72 : x, y - unit * (size - 1.5 + side * 0.22), unit * 0.84, unit * 0.24);
          }
        }
        return;
      }
      if (variant === 'palm') {
        polygon(ctx, '#785b4d', [x - unit * 0.3,y,x + unit * 0.3,y,x + unit * 0.6,y - unit * 4.9,x + unit * 0.18,y - unit * 4.9]);
        for (const side of [-1,1]) {
          polygon(ctx, '#405d46', [x + unit * 0.4,y - unit * 4.8,x + side * unit * 1.45,y - unit * 5.5,x + side * unit * 2.75,y - unit * 4.25,x + side * unit * 1.35,y - unit * 4.65]);
          polygon(ctx, '#7b9357', [x + unit * 0.4,y - unit * 4.85,x + side * unit * 1.05,y - unit * 5.8,x + side * unit * 2.12,y - unit * 5.52]);
        }
        return;
      }
      const tree=leafSprite(variant,weather,biome[7]);
      const height=unit*6.3, width=height*.66;
      ctx.fillStyle='#0a1b2355';ctx.beginPath();ctx.ellipse(x+unit*.6,y,width*.37,unit*.29,0,0,7);ctx.fill();
      ctx.drawImage(tree,x-width*.5,y-height,width,height);
      return;
    }
    const pickup = ['nitro','fuel','cash','boost'].includes(object.kind);
    const width = unit * (pickup ? 1.05 : 1.9);
    const height = unit * (pickup ? 0.85 : 0.8);
    const top = y - height - unit * (pickup ? 0.2 : 0.65);
    if (!pickup) box(ctx, '#4e4846', x - unit * 0.12, top, unit * 0.24, y - top);
    box(ctx, '#252838', x - width / 2, top, width, height);
    const tone = { fuel:'#e2b95f', nitro:'#63d2d2', cash:'#8fd38f', boost:'#fa8d68', barrier:'#d58e71' }[object.kind] || '#e2c17a';
    box(ctx, tone, x - width * 0.39, top + height * 0.18, width * 0.78, height * 0.64);
    if (width > 6) {
      if (object.kind === 'barrier' || object.kind === 'boost') {
        polygon(ctx, '#483c48', [x - width * .34,top + height * .7,x - width * .13,top + height * .22,x + width * .08,top + height * .22,x - width * .14,top + height * .7]);
        polygon(ctx, '#483c48', [x + width * .08,top + height * .7,x + width * .29,top + height * .22,x + width * .38,top + height * .22,x + width * .28,top + height * .7]);
      } else box(ctx, '#635354', x - width * 0.09, top + height * 0.35, width * 0.18, height * 0.34);
    }
  }

  function stripe(ctx, color, near, far, middle, width) {
    polygon(ctx, color, [near.x + near.half * (middle - width), near.y, near.x + near.half * (middle + width), near.y,
      far.x + far.half * (middle + width), far.y, far.x + far.half * (middle - width), far.y]);
  }

  function tunnelAt(tunnels, z, length) {
    const position = mod(z, length);
    return tunnels.find(({ start, end }) => start <= position && position < end);
  }

  function drawTunnel(ctx, near, far, tunnel, dark, portal) {
    const height = tunnel.height || 6;
    const nearRoof = near.y - near.scale * height;
    const farRoof = far.y - far.scale * height;
    const nearWall = near.half * 1.17;
    const farWall = far.half * 1.17;
    const concrete = dark ? '#514950' : '#68606a';
    for (const side of [-1, 1]) {
      polygon(ctx, concrete, [near.x + side * nearWall, near.y, near.x + side * nearWall, nearRoof,
        far.x + side * farWall, farRoof, far.x + side * farWall, far.y]);
      polygon(ctx, '#a78b73', [near.x + side * nearWall, near.y - near.scale * 0.7,
        far.x + side * farWall, far.y - far.scale * 0.7, far.x + side * farWall, far.y - far.scale * 0.48,
        near.x + side * nearWall, near.y - near.scale * 0.48]);
    }
    polygon(ctx, dark ? '#37333c' : '#45404b', [near.x - nearWall, nearRoof, near.x + nearWall, nearRoof,
      far.x + farWall, farRoof, far.x - farWall, farRoof]);
    if (!dark) {
      polygon(ctx, '#efc98e', [near.x - near.scale * 0.28, nearRoof, near.x + near.scale * 0.28, nearRoof,
        far.x + far.scale * 0.28, farRoof, far.x - far.scale * 0.28, farRoof]);
    }
    if (portal) {
      const beam = Math.max(2, near.scale * 0.75);
      box(ctx, '#746579', near.x - nearWall - beam, nearRoof - beam, 2 * (nearWall + beam), beam);
      box(ctx, '#504652', near.x - nearWall - beam, nearRoof, beam, near.y - nearRoof);
      box(ctx, '#504652', near.x + nearWall, nearRoof, beam, near.y - nearRoof);
      box(ctx, '#d3a876', near.x - nearWall - beam, nearRoof - beam, 2 * (nearWall + beam), 1);
    }
  }

  function drawBridge(ctx, near, far, dark) {
    for (const side of [-1, 1]) {
      const nearX = near.x + side * near.half * 1.15;
      const farX = far.x + side * far.half * 1.15;
      const nearRail = near.y - near.scale * 1.25;
      const farRail = far.y - far.scale * 1.25;
      polygon(ctx, dark ? '#665f67' : '#817980', [nearX,nearRail,farX,farRail,farX,farRail + far.scale * 0.23,nearX,nearRail + near.scale * 0.23]);
      if (!dark) box(ctx, '#575561', farX - far.scale * 0.17, farRail, far.scale * 0.34, far.y - farRail);
    }
  }

  function view(ctx, w, h, top, race, driver, frame) {
    const track = race.track;
    const weather = terrains[track.weather] ? track.weather : 'clear';
    const biomeId = mod(track.biome ?? track.region ?? 0, biomes.length);
    const biome = biomes[biomeId];
    const p = regionalPalette(weather, biome);
    const split = h < 150;
    const horizon = Math.round(h * (split ? .4 : .48));
    const tireLine = Math.min(h-10,Math.round(h*(split?.86:.87)));
    const focal = split ? h*2.18 : h*1.12;
    const follow = (split?28:22)*[1,1.25,.72][driver.camera||0];
    const cameraZ = driver.z - follow;
    const here = track.sample(driver.z);
    const rear = track.sample(cameraZ);
    const planar = Number.isFinite(here.px) && Number.isFinite(here.py) && Number.isFinite(here.heading);
    const heading = planar ? Math.atan2(here.py - rear.py, here.px - rear.px) : 0;
    const rightX = -Math.sin(heading);
    const rightY = Math.cos(heading);
    const tangent = planar ? 0 : (here.x - rear.x) / follow;
    const pitch = Math.max(-0.18, Math.min(0.18, (here.y - rear.y) / follow));
    const cameraX = rear.x + driver.x * 0.68;
    const cameraY = here.y - pitch * follow + (tireLine - horizon) * follow / focal;
    const farClip = 510;
    const tunnels = track.tunnels || [];
    const bridges = track.bridges || [];
    const inTunnel = tunnelAt(tunnels, cameraZ, track.length);

    function project(z, lateral, sample) {
      const depth = z - cameraZ;
      const scale = focal / depth;
      const angle = planar ? sample.heading - heading : 0;
      const facing = Math.cos(angle);
      const localX = planar ? (sample.px - rear.px) * rightX + (sample.py - rear.py) * rightY + lateral * facing - driver.x * 0.68 :
        sample.x + lateral - cameraX - tangent * depth;
      return {
        x: w / 2 + localX * scale,
        y: horizon + (cameraY + pitch * depth - sample.y) * scale,
        half: sample.width * scale * Math.max(0.55, facing),
        scale
      };
    }

    ctx.save();
    ctx.translate(0, top);
    ctx.beginPath();
    ctx.rect(0, 0, w, h);
    ctx.clip();
    ctx.imageSmoothingEnabled = true;
    if (inTunnel) {
      box(ctx, '#302a34', 0, 0, w, h);
      box(ctx, '#39313b', 0, horizon * 0.65, w, h - horizon * 0.65);
    } else {
      const layers = skyline(p, weather, biome, biomeId);
      ctx.drawImage(layers[0], 0, 0, w, horizon + 6);
      for (let i = 1; i < layers.length; i++) {
        const shift = Math.round(mod(planar ? heading * w * i / (Math.PI * 2) : (here.x * 0.16 + tangent * 19) * i, w));
        ctx.drawImage(layers[i], -shift, 0, w, horizon + 6);
        ctx.drawImage(layers[i], w - shift, 0, w, horizon + 6);
      }
    }
    box(ctx, p[5], 0, horizon + 5, w, h - horizon);

    const stride = 5;
    const baseZ = Math.floor((cameraZ + 9) / stride) * stride;
    const slices = [];
    const visible = [];
    let covered = h;
    for (let z = baseZ; z < cameraZ + farClip; z += stride) {
      const near = project(z, 0, track.sample(z));
      const far = project(z + stride, 0, track.sample(z + stride));
      slices.push({ z, near, far, covered });
      if (Math.round(far.y) >= covered) continue;
      visible.push({ z, near, far, covered });
      covered = Math.round(far.y);
    }

    for (let i = visible.length - 1; i >= 0; i--) {
      const { z, near, far, covered: clip } = visible[i];
      const alt = mod(Math.floor(z / 15), 2);
      const tunnel = tunnelAt(tunnels, z + stride * 0.5, track.length);
      const bridge = tunnelAt(bridges, z + stride * 0.5, track.length);
      ctx.save();
      ctx.beginPath();
      ctx.rect(0, 0, w, Math.max(0, clip + 1));
      ctx.clip();
      box(ctx, bridge ? (alt ? '#537b80' : '#608a90') : p[5 + alt], 0, far.y, w, near.y - far.y + 1);
      stripe(ctx, p[9 + alt], near, far, 0, 1.12);
      stripe(ctx, tunnel ? (alt ? '#4b444b' : '#585059') : p[7 + alt], near, far, 0, 1);
      stripe(ctx, p[11], near, far, -0.965, 0.018);
      stripe(ctx, p[11], near, far, 0.965, 0.018);
      if (mod(Math.floor(z / 10), 3) === 0) {
        stripe(ctx, p[11], near, far, -1 / 3, 0.019);
        stripe(ctx, p[11], near, far, 1 / 3, 0.019);
      }
      if (mod(z, track.length) < stride) {
        for (let tile = 0; tile < 16; tile++) stripe(ctx, tile % 2 ? '#282630' : '#e0d7ba', near, far, -0.9375 + tile * 0.125, 0.0625);
      }
      if (tunnel) drawTunnel(ctx, near, far, tunnel, !alt, tunnel !== tunnelAt(tunnels, z - stride * 0.5, track.length));
      if (bridge) drawBridge(ctx, near, far, !alt);
      ctx.restore();
    }

    surfaceGrain(ctx,w,h);

    const objects = [];
    function requireVisible(entity, isCar, z) {
      const index = Math.floor((z - baseZ) / stride);
      if (index < 0 || index >= slices.length) return;
      const point = project(z, entity.x, track.sample(z));
      const clip = entity === driver ? tireLine + 1 : slices[index].covered;
      if (point.x < -45 || point.x > w + 45) return;
      objects.push({ entity, isCar, point, clip, z });
    }

    for (const car of race.cars) requireVisible(car, true, cameraZ + mod(car.z - cameraZ, track.length));
    for (const object of track.objects || []) {
      const z = cameraZ + mod(object.z - cameraZ, track.length);
      const pickup = ['nitro','fuel','cash','boost'].includes(object.kind);
      const alreadyPicked = pickup && driver.picked?.has(`${Math.floor((z + 0.00001) / track.length)}:${object.z}`);
      if (!alreadyPicked && !object.collected && !object.used) requireVisible(object, false, z);
    }
    objects.sort((a, b) => b.z - a.z);
    for (const { entity, isCar, point, clip } of objects) {
      ctx.save();
      ctx.beginPath();
      ctx.rect(0, 0, w, Math.max(0, clip + 1));
      ctx.clip();
      if (isCar) drawCar(ctx, entity, point, frame);
      else drawObject(ctx, entity, point, weather, biome);
      ctx.restore();
    }
    if(!inTunnel&&['rain','snow'].includes(weather)){
      const rain=weather==='rain', velocity=driver.speed, length=rain?3+velocity*.12:1.7;
      ctx.lineWidth=.36;ctx.lineCap='round';ctx.strokeStyle=rain?'#e7f5ff76':'#ffffffb0';ctx.beginPath();
      for(let i=0;i<(rain?100:68);i++){
        const x=mod(i*73+frame*(rain?-4:1),w),y=mod(i*117+frame*(rain?7:2),h);
        ctx.moveTo(x,y);ctx.lineTo(x-(rain?length*.4:0),y+length);
      }
      ctx.stroke();
    }
    if(!inTunnel&&weather==='fog'){
      const fog=ctx.createLinearGradient(0,horizon-19,0,horizon+20);
      fog.addColorStop(0,'#e2e9e800');fog.addColorStop(.45,'#d3ded84f');fog.addColorStop(1,'#d5dfd700');
      box(ctx,fog,0,horizon-19,w,39);
    }
    if(driver.boost>0||driver.speed>66){
      ctx.strokeStyle=driver.boost>0?'#9fd3ff58':'#d7e8fa3b';ctx.lineWidth=.38;ctx.beginPath();
      for(let i=0;i<9;i++){
        const side=i%2?1:-1, y=mod(frame*2.6+i*29,h*.42)+h*.53;
        const x=w/2+side*w*(.27+i%4*.055);
        ctx.moveTo(x,y);ctx.lineTo(x+side*9,y+6);
      }
      ctx.stroke();
    }
    ctx.restore();
  }

  function render(target, race) {
    const ctx = target.getContext('2d');
    const drivers = race.cars.filter(car => car.player > 0);
    const frame = Math.floor((race.time || 0) * 60);
    const height=224, width=height*target.width/target.height;
    const h=height/Math.max(1,drivers.length);
    ctx.save();ctx.setTransform(target.width/width,0,0,target.height/height,0,0);
    drivers.forEach((driver,index)=>view(ctx,width,h,index*h,race,driver,frame));
    ctx.restore();
  }

  global.BGRenderer = { render, preview };
})(globalThis);
