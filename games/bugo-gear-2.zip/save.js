'use strict';
globalThis.BGSave = (() => {
  const key = 'bugo-gear-2:1';
  const legacyKey = 'bugle-gear-2:1';
  const profile = name => ({name,paint:0,manual:false,money:0,points:0,parts:Array(11).fill(0)});
  const defaults = () => ({track:0,lang:0,players:1,difficulty:1,mph:false,muted:false,
    profiles:[profile('P1'),{...profile('P2'),paint:1}], records:{}, rivals:{}, music:.8,effects:.8,
    layout:0, custom:[null,null], deadzone:[.18,.18], fit:'fill', quality:'balanced', keys:[null,null], sensitivity:[1,1],
    customQuality:{resolution:720,effects:true}, regional:{},schema:2});
  function validate(s) {
    if (!s || !Number.isInteger(s.track) || s.track < 0 || s.track > 64 ||
       ![0,1].includes(s.lang) || ![1,2].includes(s.players) || ![0,1,2].includes(s.difficulty) ||
       !Array.isArray(s.profiles) || s.profiles.length !== 2 || typeof s.muted !== 'boolean' ||
       typeof s.mph !== 'boolean' || !s.records || Array.isArray(s.records) ||
       typeof s.records !== 'object' || Object.entries(s.records).some(([k,v]) => !/^\d{1,2}$/.test(k) || +k >= 64 || !Number.isFinite(v) || v <= 0))
      throw Error('Invalid save');
    for (const p of s.profiles) {
      if (!p || typeof p.name !== 'string' || p.name.length > 12 || typeof p.manual !== 'boolean' ||
         !Number.isInteger(p.paint) || p.paint < 0 || p.paint >= 8 || !Number.isSafeInteger(p.money) || p.money < 0 ||
         !Number.isSafeInteger(p.points) || p.points < 0 || !Array.isArray(p.parts) ||
         ![6,8,11].includes(p.parts.length) || p.parts.some(x => ![0,1,2,3].includes(x))) throw Error('Invalid profile');
      if(p.parts.length!==11)p.parts=[...p.parts,...Array(11-p.parts.length).fill(0)];
    }
    s.regional ??= {};
    if (!s.regional || Array.isArray(s.regional) || typeof s.regional !== 'object' ||
      Object.entries(s.regional).some(([k,v])=>!/^\d{1,2}$/.test(k)||+k>=64||+k>=s.track||!Array.isArray(v)||v.length!==21||v.some(n=>![null,0,1,2,3,4,6,10].includes(n)))) throw Error('Invalid regional results');
    s.rivals ??= {};
    if (!s.rivals || Array.isArray(s.rivals) || typeof s.rivals !== 'object' ||
      Object.entries(s.rivals).some(([k,v]) => !/^(?:[0-9]|1[0-9])$/.test(k) || !Number.isSafeInteger(v) || v < 0)) throw Error('Invalid standings');
    s.music ??= .8; s.effects ??= .8;
    if ([s.music,s.effects].some(v => !Number.isFinite(v) || v<0 || v>1)) throw Error('Invalid audio levels');
    const config = defaults();
    s.fit ??= config.fit;
    s.quality = ({hd:'balanced',performance:'economy'})[s.quality] || s.quality || 'balanced';
    s.keys ??= config.keys; s.sensitivity ??= config.sensitivity;
    if(s.schema!==undefined && ![1,2].includes(s.schema))throw Error('Unknown save format');
    s.schema=2;
    if(!['fill','wide','tall'].includes(s.fit) || !['economy','balanced','high','custom'].includes(s.quality) ||
      !Array.isArray(s.sensitivity)||s.sensitivity.length!==2||s.sensitivity.some(v=>![.7,1,1.3].includes(v))||
      !Array.isArray(s.keys)||s.keys.length!==2||s.keys.some(l=>l!==null&&(!Array.isArray(l)||l.length!==12||l.some(v=>v!==null&&(!Array.isArray(v)||v.length!==1||!(/^[A-Za-z0-9]{1,24}$/).test(v[0]))))))throw Error('Invalid control or display settings');
    s.customQuality??={resolution:720,effects:true};
    if(![540,720,900,1080].includes(s.customQuality.resolution)||typeof s.customQuality.effects!=='boolean')throw Error('Invalid custom graphics');
    s.layout ??= config.layout;
    s.custom ??= config.custom;
    s.deadzone ??= config.deadzone;
    if (![0,1,2,3,4].includes(s.layout) || !Array.isArray(s.custom) || s.custom.length !== 2 ||
      s.custom.some(layout => layout !== null && (!Array.isArray(layout) || layout.length !== 7 ||
        new Set(layout).size !== 7 || layout.some(k => typeof k !== 'string' || !/^[a-zA-Z0-9]{1,24}$/.test(k)))) ||
      !Array.isArray(s.deadzone) || s.deadzone.length !== 2 ||
      s.deadzone.some(n => !Number.isFinite(n) || n < .05 || n > .5)) throw Error('Invalid input settings');
    return s;
  }
  function load() {
    for (const slot of [key,key + ':backup',legacyKey,legacyKey + ':backup']) {
      try {
        const state=validate(JSON.parse(localStorage.getItem(slot)));
        if(slot.startsWith(legacyKey))save(state);
        return state;
      } catch {}
    }
    return defaults();
  }
  function save(s) {
    try {
      const next = JSON.stringify(validate(s));
      let previous;
      try {previous = JSON.stringify(validate(JSON.parse(localStorage.getItem(key))));} catch {}
      if (previous) localStorage.setItem(key + ':backup',previous);
      localStorage.setItem(key,next);
    } catch {}
  }
  function checksum(bytes) {
    let hash = 2166136261;
    for (const b of bytes) hash = Math.imul(hash ^ b,16777619);
    return (hash >>> 0).toString(36);
  }
  function encode(s) {
    const bytes = new TextEncoder().encode(JSON.stringify(validate(s)));
    return 'BG2-' + checksum(bytes) + '-' + btoa(String.fromCharCode(...bytes));
  }
  function decode(code) {
    const m = /^BG2-([a-z0-9]+)-([a-zA-Z0-9+/=]+)$/.exec(code.trim());
    if (!m || m[2].length > 8192) throw Error('Invalid code');
    const bytes = Uint8Array.from(atob(m[2]), c => c.charCodeAt(0));
    if (checksum(bytes) !== m[1]) throw Error('Invalid checksum');
    return validate(JSON.parse(new TextDecoder().decode(bytes)));
  }
  return {load,save,defaults,encode,decode};
})();
