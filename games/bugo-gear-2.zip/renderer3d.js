'use strict';
globalThis.BG3D=(()=>{
 const surface=document.querySelector('#screen-3d');
 let gl,program,buffer,uniform,roadTexture, count=0, ready=false, lost=false, camera,capacity=0,recording;
 let spectralQueue=[],spectralReady=false;
 let data=new Float32Array(513333);
 const stationary=new WeakMap(), chase=new WeakMap(), bodyPoses=new WeakMap(), rivalLevels=new WeakMap();
 const visualYaw=c=>Math.max(-1,Math.min(1,c.steer||0))*.19-(c.spin||0)*.37;
 const sceneryGeometry=new WeakMap();
 const sceneryLOD={
   tree_detailed:'tree_default',
   tree_detailed_fall:'tree_default',
   tree_oak:'tree_fat',
   tree_palmDetailedShort:'tree_palmShort',
   tree_palmDetailedTall:'tree_palmTall',
   tree_pineDefaultA:'tree_pineTallA',
   tree_pineDefaultB:'tree_pineTallA',
   tree_pineTallD:'tree_pineTallA',
 };
 let propTrack,propFrame=new Map(),previousProps=new Map();
 const colors=new Map();
 const P=[['#79adc6','#466b54','#738f67','#62636a'],['#768c9d','#445f58','#637067','#505961'],['#bfd2de','#c5d3dc','#e4e9ed','#687480'],['#a0acae','#627d70','#7d8d7b','#636c70'],['#252e45','#30374a','#444654','#454a5d']];
 const weather=['clear','rain','snow','fog','night'];
 surface.addEventListener('webglcontextlost',e=>{e.preventDefault();lost=true;});
 surface.addEventListener('webglcontextrestored',()=>{lost=false;ready=false;program=null;spectralReady=false;globalThis.BGSpectralRender?.reset();});
 function boot(){
   gl=surface.getContext('webgl',{alpha:false,antialias:false,powerPreference:'low-power'});
   if(!gl)return false;
   function compile(type,source){
     const sh=gl.createShader(type);
     gl.shaderSource(sh,source);gl.compileShader(sh);
     if(!gl.getShaderParameter(sh,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(sh));
     return sh;
   }
   const v=compile(gl.VERTEX_SHADER,`
     attribute vec3 position; attribute vec3 color; attribute vec3 samplePoint; attribute vec2 roadCoord;
     uniform float aspect; uniform float f;
     varying vec3 shade; varying vec3 world; varying float depth; varying vec2 roadUV;
     void main(){depth=position.z; shade=color; world=samplePoint; roadUV=roadCoord;
       gl_Position=vec4(position.x*f/aspect,position.y*f,position.z*1.0004-.38,position.z);}
   `);
   const fs=compile(gl.FRAGMENT_SHADER,`
     precision mediump float; varying vec3 shade; varying vec3 world; varying float depth; varying vec2 roadUV;
     uniform sampler2D roadMap; uniform vec3 haze; uniform float atmosphere; uniform float wet; uniform float night; uniform float roadRelief; uniform vec4 lamps[2]; uniform vec4 streetLights[4];
     void main(){
       if(world.z < -0.5){gl_FragColor=vec4(shade,1.);return;}
       vec2 cell=mod(floor(world.xy*29.0), vec2(163.0));
       float grit=fract(sin(dot(cell,vec2(12.17,7.31)))*1745.1)-.5;
       float detail=1.-smoothstep(8.,130.,depth);
       vec3 lit=shade+(grit*.075*min(world.z,2.0))*detail;
       if(world.z>2.5 && world.z<3.5){
         vec4 tex=texture2D(roadMap,vec2(roadUV.x*2.75,roadUV.y));
         float tracks=1.-smoothstep(.025,.09,abs(abs(abs(roadUV.x)-.5)-.15));
         lit=shade*(.94-tracks*(.035+.035*tex.g))+vec3((tex.r-.5)*.19+(tex.g-.5)*.12)*detail;
         lit=mix(lit,lit*.67+haze*(.08+.07*tex.g),wet);
         // Asphalt microrelief is packed into alpha, alongside the existing RGB channels.
         float relief=(tex.a-.5)*detail*roadRelief;
         lit+=vec3(relief*mix(.036,.012,wet))+haze*max(0.,-relief)*wet*.15;
         // Two bounded road-light cones, in world coordinates, not screen overlays.
         for(int i=0;i<2;i++){
           vec2 delta=world.xy-lamps[i].xy;
           float ahead=dot(delta,lamps[i].zw);
           float lateral=abs(dot(delta,vec2(-lamps[i].w,lamps[i].z)));
           float reach=max(0.,ahead);
           float cone=(1.-smoothstep(.65+reach*.13,1.4+reach*.23,lateral));
           float beam=smoothstep(1.,4.,ahead)*(1.-smoothstep(10.,52.,ahead))*cone;
           lit+=vec3(.40,.35,.25)*beam*night;
         }
       }
       if(world.z>3.5 && world.z<4.5){
         vec3 tex=texture2D(roadMap,vec2(roadUV.x*2.75,roadUV.y)).rgb;
         lit=shade*(.88+.19*tex.r-.12*smoothstep(.68,.93,tex.g)*detail);
         lit=mix(lit,lit*.78,wet);
       }
       if(world.z>4.5){
         vec3 tex=texture2D(roadMap,vec2(roadUV.x*3.,roadUV.y)).rgb;
         lit=shade*(.85+.28*tex.g)+(tex.r-.5)*.10*detail;
         lit=mix(lit,lit*.76,wet);
       }
       if(world.z>2.5){
         for(int i=0;i<4;i++){
           vec2 delta=world.xy-streetLights[i].xy;
           float pool=1.-smoothstep(12.,225.,dot(delta,delta));
           lit+=vec3(.25,.19,.10)*pool*streetLights[i].z;
         }
       }
       gl_FragColor=vec4(mix(lit,haze,clamp(depth*atmosphere,0.,.87)),1.);
     }
   `);
   program=gl.createProgram();gl.attachShader(program,v);gl.attachShader(program,fs);gl.linkProgram(program);
   if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(program));
   gl.useProgram(program);buffer=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,buffer);
   gl.bufferData(gl.ARRAY_BUFFER,data.byteLength,gl.DYNAMIC_DRAW);capacity=data.byteLength;
   uniform=Object.fromEntries(['aspect','f','haze','atmosphere','wet','night','roadRelief','lamps[0]','streetLights[0]','roadMap'].map(k=>[k,gl.getUniformLocation(program,k)]));
   roadTexture=gl.createTexture();gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,roadTexture);
   const map=roadTextureData();
   gl.uniform1f(uniform.roadRelief,Number(!!map.relief));
   gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,map.size,map.size,0,gl.RGBA,gl.UNSIGNED_BYTE,map.pixels);
   gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.REPEAT);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.REPEAT);
   gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR_MIPMAP_LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);gl.generateMipmap(gl.TEXTURE_2D);gl.uniform1i(uniform.roadMap,0);
   try{if(globalThis.BGSpectralRender&&globalThis.BGSpectralData){BGSpectralRender.prepare(gl);spectralReady=true;}}catch(e){console.warn('Spectral unavailable; legacy model:',e);spectralReady=false;}
   bindScene();
   gl.enable(gl.DEPTH_TEST);gl.enable(gl.SCISSOR_TEST);ready=true;return true;
 }
 function bindScene(){
   gl.useProgram(program);gl.bindBuffer(gl.ARRAY_BUFFER,buffer);
   gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,roadTexture);
   ['position','color','samplePoint','roadCoord'].forEach((name,i)=>{const loc=gl.getAttribLocation(program,name);gl.enableVertexAttribArray(loc);gl.vertexAttribPointer(loc,i===3?2:3,gl.FLOAT,false,44,i*12);});
 }
 // Periodic deterministic noise, generated once locally (no network dependency).
 function makeRoadMap(){
   let seed=41971;const rnd=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
   const layers=[8,32,128,256].map(n=>({n,v:Float32Array.from({length:n*n},rnd)}));
   function noise(l,x,y){const n=l.n,fx=x*n/256,fy=y*n/256,i=Math.floor(fx),j=Math.floor(fy),a=fx-i,b=fy-j;
     const u=a*a*(3-2*a),v=b*b*(3-2*b),at=(i,j)=>l.v[(j%n)*n+i%n];
     return (at(i,j)*(1-u)+at(i+1,j)*u)*(1-v)+(at(i,j+1)*(1-u)+at(i+1,j+1)*u)*v;
   }
   const out=new Uint8Array(256*256*4);
   for(let y=0;y<256;y++)for(let x=0;x<256;x++){
     const a=noise(layers[0],x,y),b=noise(layers[1],x,y),c=noise(layers[2],x,y),d=noise(layers[3],x,y),i=(y*256+x)*4;
     out[i]=Math.round(255*(.10*a+.18*b+.42*c+.30*d));out[i+1]=Math.round(255*(.6*a+.4*b));out[i+2]=Math.round(255*d);out[i+3]=255;
   }return out;
 }
 // The optional photo contains local luminance and microrelief channels.
 // No fetch, image decoding, or network permission is required at runtime.
 function roadTextureData(photo=globalThis.BGRoadPhoto){
   const base=makeRoadMap(), fallback={size:256,pixels:base,photographic:false};
   if(!photo||photo.size!==512||typeof photo.luminance!=='string'||photo.luminance.length!==349528)return fallback;
   let raw;try{raw=atob(photo.luminance);}catch(_){return fallback;}
   if(raw.length!==512*512)return fallback;
   let relief='';
   if(typeof photo.relief==='string'&&photo.relief.length===87384){
     try{relief=atob(photo.relief);}catch{}
   }
   const hasRelief=relief.length===256*256;
   const pixels=new Uint8Array(512*512*4);
   for(let y=0;y<512;y++)for(let x=0;x<512;x++){
     const p=y*512+x, i=p*4, j=(Math.floor(y/2)*256+Math.floor(x/2))*4;
     pixels[i]=raw.charCodeAt(p); pixels[i+1]=base[j+1];pixels[i+2]=base[j+2];pixels[i+3]=hasRelief?relief.charCodeAt(j/4):255;
   }
   return {size:512,pixels,photographic:true,relief:hasRelief};
 }
 function rgb(hex){
   if(!colors.has(hex))colors.set(hex,[1,3,5].map(i=>parseInt(hex.slice(i,i+2),16)/255));
   return colors.get(hex);
 }
 function shade(hex,light){return rgb(hex).map(n=>n*light);}
 function vertex(p,c,material,uv){
   if(count+11>data.length){const expanded=new Float32Array(data.length*2);expanded.set(data);data=expanded;}
   const [x,y,z]=p, dx=x-camera.x,dz=z-camera.z,dy=y-camera.y;
   const forward=dx*camera.fx+dz*camera.fz;
   data[count++]=dx*camera.rx+dz*camera.rz;
   data[count++]=dy*camera.cp+forward*camera.sp;
   data[count++]=forward*camera.cp-dy*camera.sp;
   data[count++]=c[0];data[count++]=c[1];data[count++]=c[2];
   data[count++]=x;data[count++]=z;data[count++]=material;data[count++]=uv?uv[0]:0;data[count++]=uv?uv[1]:0;
 }
 function tri(a,b,c,col,material=0,uv){
   if(recording){recording.push([a,b,c,col,material,uv]);return;}
   vertex(a,col[0] instanceof Array?col[0]:col,material,uv?.[0]);vertex(b,col[0] instanceof Array?col[1]:col,material,uv?.[1]);vertex(c,col[0] instanceof Array?col[2]:col,material,uv?.[2]);
 }
 function quad(a,b,c,d,col,material=0){tri(a,b,c,col,material);tri(a,c,d,col,material);}
 function along(p,x,h=0){return [p.px-Math.sin(p.heading)*x,p.y+h,p.py+Math.cos(p.heading)*x];}
 function face(a,b,ma,mb,na,nb,ink,material=0,lift=.01,span){
   const p=[along(a,ma,lift),along(a,mb,lift),along(b,nb,lift),along(b,na,lift)];
   if(!span){quad(...p,ink,material);return;}
   const uv=[[ma/a.width,span[0]],[mb/a.width,span[0]],[nb/b.width,span[1]],[na/b.width,span[1]]];
   tri(p[0],p[1],p[2],ink,material,[uv[0],uv[1],uv[2]]);tri(p[0],p[2],p[3],ink,material,[uv[0],uv[2],uv[3]]);
 }
 function ranges(track,kind,z){const p=BGTracks.mod(z,track.length);return track[kind].some(s=>s.start<=p&&p<=s.end);}
 // Subdivide only when the road centre or either edge deviates from the straight mesh chord.
 // All samples come from the existing physics track; no new racing line or grade is introduced.
 function roadError(track,start,end){
   const a=track.sample(start),b=track.sample(end);
   let horizontal=0,vertical=0;
   for(const t of [.25,.5,.75]){
     const p=track.sample(start+(end-start)*t);
     for(const side of [-1,0,1]){
       const u=along(a,side*a.width),v=along(b,side*b.width),q=along(p,side*p.width);
       horizontal=Math.max(horizontal,Math.hypot(q[0]-u[0]-(v[0]-u[0])*t,q[2]-u[2]-(v[2]-u[2])*t));
       vertical=Math.max(vertical,Math.abs(q[1]-u[1]-(v[1]-u[1])*t));
     }
   }
   return {horizontal,vertical};
 }
 function roadSlices(track,start,end){
   const cuts=[start,end];
   for(const kind of ['tunnels','bridges'])for(const range of track[kind]||[])for(const z of [range.start,range.end])if(z>start+1e-7&&z<end-1e-7)cuts.push(z);
   cuts.sort((a,b)=>a-b);
   const out=[];
   function split(a,b,depth){
     const e=roadError(track,a,b);
     if(depth<3&&b-a>.75&&(e.horizontal>.06||e.vertical>.015)){
       const m=(a+b)*.5;split(a,m,depth+1);split(m,b,depth+1);
     }else out.push([a,b]);
   }
   for(let i=1;i<cuts.length;i++)if(cuts[i]-cuts[i-1]>1e-7)split(cuts[i-1],cuts[i],0);
   return out;
 }
 // P13: cross-section strips follow each adaptive road slice, not the world axes.
 function edgeStrip(a,b,side,d0,h0,d1,h1,ink){
   const pt=(p,d,h)=>along(p,side*(p.width+1.7+d),h);
   quad(pt(a,d0,h0),pt(b,d0,h0),pt(b,d1,h1),pt(a,d1,h1),rgb(ink));
 }
 function guardRail(a,b,side,post){
   // Folded metal profile, kept beyond the paved driving width.
   const profile=[[-.17,.46],[-.25,.53],[-.13,.61],[-.25,.70],[-.17,.77]];
   const inks=['#77838a','#c0c8cc','#88959d','#d3d9dc'];
   for(let i=0;i<4;i++)edgeStrip(a,b,side,...profile[i],...profile[i+1],inks[i]);
   if(post){const q=along(a,side*(a.width+1.58));const m=mesh(...q,a.heading);
     prism(m,-.065,.065,0,.80,-.08,.08,'#69777e');
     prism(m,-.095,.095,0,.07,-.12,.12,'#8b9296');
   }
 }
 function bridgeSide(a,b,side,post){
   // Solid deck, parapet and capped railing; no new collision objects.
   edgeStrip(a,b,side,0,-.60,0,.44,'#90979b');
   edgeStrip(a,b,side,0,.44,.28,.44,'#b9bec1');
   edgeStrip(a,b,side,.28,.44,.28,-.60,'#747d84');
   edgeStrip(a,b,side,0,-.60,.28,-.60,'#68727a');
   edgeStrip(a,b,side,.03,1.03,.03,1.14,'#b0bdc4');
   edgeStrip(a,b,side,.03,1.14,.22,1.14,'#d8dde0');
   edgeStrip(a,b,side,.22,1.14,.22,1.03,'#829098');
   if(post){const q=along(a,side*(a.width+1.83));prism(mesh(...q,a.heading),-.055,.055,.44,1.10,-.075,.075,'#8c999f');}
 }
 function tunnelShell(a,b,side){
   edgeStrip(a,b,side,0,0,0,.68,'#8c8b86');
   edgeStrip(a,b,side,0,.68,0,1.0,'#d6b957');
   edgeStrip(a,b,side,0,1.0,0,4.65,'#777b80');
   edgeStrip(a,b,side,0,4.65,-1.15,6,'#575e67');
   if(side===1)quad(along(a,-(a.width+.55),6),along(a,a.width+.55,6),along(b,b.width+.55,6),along(b,-(b.width+.55),6),rgb('#484958'));
 }
 function portal(p){
   // Face at the exact structure boundary; opening follows the existing tunnel profile.
   const m=mesh(...along(p,0),p.heading), w=p.width+1.7;
   for(const side of [-1,1]){
     const low=Math.min(side*w,side*(w+.48)),high=Math.max(side*w,side*(w+.48));
     prism(m,low,high,-.12,4.65,-.12,.12,'#a1a3a2');
     for(const z of [-.13,.13])quad(m(side*w,4.65,z),m(side*(w+.48),4.65,z),m(side*(w-.67),6.35,z),m(side*(w-1.15),6,z),rgb('#9b9e9e'));
   }
   prism(m,-w+1.15,w-1.15,6,6.35,-.12,.12,'#a1a3a2');
 }
 // P13.1: actual Kenney GLB geometry, baked to the existing scene triangle batch.
 function kenneyProp(m,name,scale,flip=1,sideOffset=0,forwardOffset=0){
   const model=globalThis.BGKenneyRoads?.[name];if(!model)return false;
   const pt=p=>m(sideOffset+p[2]*scale*flip,p[1]*scale,forwardOffset+p[0]*scale*flip);
   for(const [a,b,c,color] of model)tri(pt(a),pt(b),pt(c),color);
   return true;
 }
 function roadsideObject(track,o){
   const p=track.sample(o.z),m=mesh(...along(p,o.x),p.heading);
   const ahead=track.sample(o.z+12),bend=Math.sin(ahead.heading-p.heading);
   if(o.kind==='barrier'&&kenneyProp(m,'construction-barrier',7.5)){
     kenneyProp(m,'construction-cone',5,1,-1.02,-.1);
     kenneyProp(m,'construction-cone',5,1,1.02,-.1);
   }else{
     roadsideSign(m,o.kind,bend>=0?1:-1);
     // Retain the original directional chevron. Add a separate warning sign on approach.
     if(o.kind==='sign'&&!ranges(track,'tunnels',o.z)&&!ranges(track,'bridges',o.z)){
       const q=track.sample(o.z-4);if(!ranges(track,'tunnels',o.z-4)&&!ranges(track,'bridges',o.z-4))
         kenneyProp(mesh(...along(q,Math.sign(o.x)*(q.width+Math.max(2.1,Math.abs(o.x)-p.width))),q.heading),'road-sign-warning',3.3);
     }
   }
 }
 function roadsideSign(m,kind,turn){
   const hazard=kind==='barrier', width=hazard?.85:.56, low=hazard?.46:1.04, high=hazard?.96:1.64;
   for(const x of (hazard?[-.57,.57]:[0]))prism(m,x-.045,x+.045,0,high,-.045,.045,'#8e999d');
   prism(m,-width,width,low,high,-.065,.065,'#444b50');
   const panel=hazard?'#d58d35':'#e6d9a7';
   // Both faces: a high-contrast direction/hazard pattern, readable looking back too.
   for(const z of [-.071,.071]){
     quad(m(-width+.05,low+.05,z),m(width-.05,low+.05,z),m(width-.05,high-.05,z),m(-width+.05,high-.05,z),rgb(panel));
     if(hazard){for(const x of [-.52,-.05,.42])quad(m(x-.13,low+.05,z),m(x+.02,low+.05,z),m(x+.28,high-.05,z),m(x+.13,high-.05,z),rgb('#302e2b'));}
     else {const d=turn*(z<0?1:-1), y=(low+high)*.5;
       quad(m(-d*.34,y-.18,z),m(d*.02,y-.18,z),m(d*.34,y,z),m(d*.04,y,z),rgb('#30383e'));
       quad(m(-d*.34,y+.18,z),m(d*.02,y+.18,z),m(d*.34,y,z),m(d*.04,y,z),rgb('#30383e'));
     }
   }
 }
 function segment(track,palette,z,stride,slot,first){
     const a=track.sample(z),b=track.sample(z+stride);
     const tunnel=ranges(track,'tunnels',z+stride*.5),bridge=ranges(track,'bridges',z+stride*.5);
     const variation=1+Math.sin(z*.034)*.05;
     const tiles=Math.max(1,Math.round(track.length/4)), start=z/track.length*tiles;
     const uvStart=BGTracks.mod(start,32),span=[uvStart,uvStart+stride/track.length*tiles];
     const ground=shade(palette[1],variation), shoulder=rgb(track.weather==='snow'?'#c6cdcf':'#7c796d');
     for(const side of [-1,1]){
       const edgeA=side*(a.width+1.7),edgeB=side*(b.width+1.7);
       const farA=side*(a.width+64),farB=side*(b.width+64);
       quad(along(a,edgeA,-.14),along(a,farA,-1),along(b,farB,-1),along(b,edgeB,-.14),bridge?rgb('#3d6373'):ground,2);
       face(a,b,side*a.width,edgeA,side*b.width,edgeB,shoulder,5,.01,span);
       if(tunnel)tunnelShell(a,b,side);
       else if(bridge)bridgeSide(a,b,side,first&&slot%2===0);
       if(first&&!tunnel&&!bridge && slot%3===0){
         const x=side*(a.width+1.35), q=along(a,x), m=mesh(...q,a.heading);
         prism(m,-.065,.065,0,.83,-.07,.07,'#d2d6d7');
         prism(m,-.071,.071,.57,.75,-.076,.076,'#252d36');
       }
       if(first&&!tunnel&&!bridge&&slot%12===0&&(track.weather==='night'||track.stage===2)&&side===(slot%24===0?1:-1)){
         const q=along(a,side*(a.width+3.2),-.15);
         kenneyProp(mesh(...q,a.heading),'light-curved',8,side);
       }
       face(a,b,side*(a.width-.17),side*(a.width-.03),side*(b.width-.17),side*(b.width-.03),rgb('#e3e1d4'),4,.025,span);
     }
     face(a,b,-a.width,a.width,-b.width,b.width,rgb(tunnel?'#4c4d54':palette[3]),3,.01,span);
     // Narrow shoulders and alternate curb panels, without changing collision geometry.
     for(const side of [-1,1]){
       const curb= slot%2===0?'#d3d0c4':'#a54e40';
       if(!tunnel&&!bridge&&Math.abs(a.curvature)>.012)face(a,b,side*(a.width+.04),side*(a.width+.38),side*(b.width+.04),side*(b.width+.38),rgb(curb),4,.035,span);
       if(!tunnel&&!bridge&&Math.abs(a.curvature)>.018){
         guardRail(a,b,side,first&&slot%2===0);
       }
     }
     if(tunnel){for(const range of track.tunnels){if(Math.abs(z-range.start)<1e-6)portal(a);if(Math.abs(z+stride-range.end)<1e-6)portal(b);}}
     if(slot%3===0){
       face(a,b,-.09,.09,-.09,.09,rgb('#e3dfd1'),4,.025,span);
       if(tunnel&&first&&stride>.12){const m=mesh(...along(a,0),a.heading);prism(m,-.48,.48,5.86,5.99,0,Math.min(1.4,stride),'#41484e');quad(m(-.36,5.85,.04),m(.36,5.85,.04),m(.36,5.85,Math.min(1.35,stride)),m(-.36,5.85,Math.min(1.35,stride)),rgb('#fff0c2'));}
     }
 }
 const streetCache=new WeakMap();
 function streetPlan(track){
   if(streetCache.has(track))return streetCache.get(track);
   const lights=[],total=Math.ceil(track.length/6),stride=track.length/total;
   if(track.weather==='night')for(let slot=0;slot<total;slot+=12){
     const [a,b]=roadSlices(track,slot*stride,Math.min(track.length,(slot+1)*stride))[0];
     if(ranges(track,'tunnels',(a+b)/2)||ranges(track,'bridges',(a+b)/2))continue;
     const p=track.sample(a),side=slot%24===0?1:-1;
     const q=along(p,side*(p.width+1.1));lights.push({z:a,x:q[0],y:q[2]});
   }
   streetCache.set(track,lights);return lights;
 }
 function streetUniform(track,driver){
   const p=track.sample(driver.z),q=along(p,driver.x||0);
   const nearest=streetPlan(track).map(l=>({...l,d:(l.x-q[0])**2+(l.y-q[2])**2})).filter(l=>l.d<260**2).sort((a,b)=>a.d-b.d).slice(0,4);
   const values=new Float32Array(16);
   nearest.forEach((l,i)=>values.set([l.x,l.y,1,0],i*4));return values;
 }
 function roadway(track,driver,palette,distance){
   let cache=stationary.get(track);
   if(!cache){cache=new Map();stationary.set(track,cache);}
   const length=track.length, total=Math.ceil(length/6),stride=length/total;
   const from=Math.floor((driver.z-(driver.lookBack?distance:45))/stride);
   const to=Math.ceil((driver.z+(driver.lookBack?45:distance))/stride);
   for(let i=from;i<=to;i++){
     const index=BGTracks.mod(i,total);
     if(!cache.has(index)){
       recording=[];
       const start=index*stride,end=(index+1===total?length:(index+1)*stride);
       roadSlices(track,start,end).forEach(([a,b],i)=>segment(track,palette,a,b-a,index,i===0));
       cache.set(index,recording);recording=null;
     }
     for(const part of cache.get(index))tri(...part);
   }
 }
 function mesh(x,y,z,heading){
   const sin=Math.sin(heading),cos=Math.cos(heading);
   return (side,up,forward)=>[x+forward*cos-side*sin,y+up,z+forward*sin+side*cos];
 }
 function prism(m,x0,x1,y0,y1,z0,z1,color){
   const p=[m(x0,y0,z0),m(x1,y0,z0),m(x1,y1,z0),m(x0,y1,z0),m(x0,y0,z1),m(x1,y0,z1),m(x1,y1,z1),m(x0,y1,z1)];
   quad(p[0],p[1],p[2],p[3],shade(color,.8));
   quad(p[4],p[5],p[6],p[7],shade(color,.68));
   quad(p[0],p[4],p[7],p[3],shade(color,.72));
   quad(p[1],p[5],p[6],p[2],shade(color,.91));
   quad(p[3],p[2],p[6],p[7],rgb(color));
 }
 const finishes={
   trim:'#182028',mesh:'#11161e',rubber:'#232730',metal:'#8f9ca7',rim:'#323b46',
   carbon:'#242d38',glass:'#315069',mirror:'#577b96',head:'#f0e7c0',tailLight:'#ff7962'
 };
 function carMesh(c,center,heading,lod,lit,spin=0,mode="clear",pose=null){
   const [x,y,z]=center;
   const m=mesh(x,y,z,heading+spin), model=c.player?0:(c.id||0)%4;
   const paint=c.color||'#c34d35', tail=c.brake?'#ff654b':'#a92122';
   const glow=c.brake?1.35:1.03;
   const ground=lit<.7?'#222831':'#323b40';
   for(let i=0;i<12;i++){
     const a=i*Math.PI/6,b=(i+1)*Math.PI/6;
     tri(m(0,.027,0),m(Math.cos(a)*1.22,.027,Math.sin(a)*2.12),m(Math.cos(b)*1.22,.027,Math.sin(b)*2.12),rgb(ground));
   }
   const damage=Math.max(...(c.damage||[0]));
   const shadeCache=new Map();
   const angle=heading+spin, cs=Math.cos(angle), sn=Math.sin(angle);
   const vx=camera.x-x,vy=camera.y-y-.7,vz=camera.z-z,vl=Math.hypot(vx,vy,vz)||1;
   if(spectralReady){spectralQueue.push({c,center,heading:heading+spin,lit,mode,pose,lod:c.player?'full':lod>=1?'near':'far'});}
   else for(const t of (c.player&&globalThis.BGImportedCar?BGImportedCar.make(lod):BGCarModels.make(model,lod))){
     let tint=shadeCache.get(t.m);
     if(!tint){tint=rgb(t.m==='paint'?paint:t.m==='tail'?tail:finishes[t.m]);shadeCache.set(t.m,tint);}
     const metallic=t.m==='metal'||t.m==='paint'||t.m==='glass';
     const colorFor=(normal)=>{
       const [nx,ny,nz]=normal;
       const wx=nz*cs-nx*sn,wz=nz*sn+nx*cs;
       const sun=Math.max(0,.36*wx+.88*ny-.30*wz);
       const facing=Math.max(0,(wx*vx+ny*vy+wz*vz)/vl);
       const fresnel=(1-facing)**3;
       const reflected=Math.max(0,.3*wx+.83*ny+.46*wz)**18;
       const power=t.m==='tail'?glow:t.m==='tailLight'?(c.brake?1.55:.84):t.m==='head'?1.14:lit*(.46+.48*sun+.24*Math.max(0,ny));
       const spec=metallic?lit*(reflected*.46+fresnel*.12):0;
       const sky=metallic?lit*Math.max(0,ny)*.11:0;
       const color=tint.map((v,i)=>Math.min(1,v*power+spec*[.85,.94,1][i]+sky*[.55,.72,1][i]));
       if(damage>65&&t.m==='paint')color[0]*=.84;
       return color;
     };
     tri(m(...t.a),m(...t.b),m(...t.c),[colorFor(t.na||t.n),colorFor(t.nb||t.n),colorFor(t.nc||t.n)]);
   }
   if(c.boost>0 && !c.retired)for(const side of [-1,1]){
     // Two crossed tapered flame surfaces aligned to the actual exhaust mouth.
     const [sx,sy,sz]=spectralReady?BGSpectralRender.mounts.exhaust:[.61,.34,-2.22];
     const effectPose=spectralReady?(pose||{roll:0,pitch:0,lift:BGSpectralRender.motion(c).lift}):null;
     const flame=(x,y,z)=>m(...(effectPose?BGSpectralRender.bodyPoint(x,y,z,effectPose):[x,y,z]));
     const x=side*sx,y=sy,z=sz-.012;
     const pulse=.66+.12*Math.sin((c.z||0)*3.1+(c.id||0));
     const hot=rgb('#fff1b8'),blue=rgb('#67b9ff'),tip=rgb('#ff7435');
     tri(flame(x-.041,y,z),flame(x+.041,y,z),flame(x,y,z-pulse),[blue,hot,tip]);
     tri(flame(x,y-.041,z),flame(x,y+.041,z),flame(x,y,z-pulse),[blue,hot,tip]);
     tri(flame(x-.019,y,z-.015),flame(x+.019,y,z-.015),flame(x,y,z-pulse*.54),[hot,hot,blue]);
     tri(flame(x,y-.019,z-.015),flame(x,y+.019,z-.015),flame(x,y,z-pulse*.54),[hot,hot,blue]);
   }
 }
 function vehicle(track,c,lod){
   const p=track.sample(c.z);
   const mode=ranges(track,'tunnels',c.z)?'tunnel':track.weather;
   carMesh(c,along(p,c.x),p.heading,lod,mode==='night'||mode==='tunnel'?.63:mode==='rain'?.86:1,visualYaw(c),mode,bodyPoses.get(c));
 }
 function packedScenery(source,m,sx,sy,sz,snow){
   let data=sceneryGeometry.get(source);
   if(!data){
     const bytes=Uint8Array.from(atob(source.packed),ch=>ch.charCodeAt(0));
     data=new DataView(bytes.buffer);
     sceneryGeometry.set(source,data);
   }
   const pt=i=>m(data.getInt32(i,true)*sx,data.getInt32(i+4,true)*sy,data.getInt32(i+8,true)*sz);
   for(let i=0;i<data.byteLength;i+=42){
     const color=[data.getUint16(i+36,true)/10000,data.getUint16(i+38,true)/10000,data.getUint16(i+40,true)/10000];
     const tint=snow&&data.getInt32(i+4,true)>45000?color.map(v=>v*.6+.23):color;
     tri(pt(i),pt(i+12),pt(i+24),tint);
   }
 }
 function sceneryMesh(track,o,near){
   const models=globalThis.BGKenneyScenery, model=models?.[o.name];if(!model)return;
   const p=track.sample(o.z),m=mesh(...along(p,o.x),o.heading),h=o.height;
   if(!near&&o.kind==='building'){
     const w=model.width*h/2,d=model.depth*h/2;
     prism(m,-w,w,0,h,-d,d,'#777b79');return;
   }
   const snow=track.weather==='snow'&&o.kind==='nature';
   if(o.name==='cliff_waterfallTop_stone'){
     // These two Nature Kit modules share the same original width and unit height.
     const half=h/2, k=half/100000, lower=models.cliff_waterfall_stone;
     packedScenery(lower,m,k,k,k,snow);
     const depthShift=(lower.depth-model.depth)*half/2;
     packedScenery(model,(x,y,z)=>m(x,y+half,z+depthShift),k,k,k,snow);
     return;
   }
   const source=(!near&&models[sceneryLOD[o.name]])||model;
   // Match the original footprint when using a simpler model from the same kit.
   packedScenery(source,m,h*model.width/source.width/100000,h/100000,h*model.depth/source.depth/100000,snow);
 }
 function cachedProp(key,build){
   if(propFrame.has(key))return propFrame.get(key);
   let parts=previousProps.get(key);
   if(!parts){
     parts=[];
     recording=parts;
     try{build();}finally{recording=null;}
   }
   propFrame.set(key,parts);
   return parts;
 }
 function scenery(track,driver,distance,high){
   const n=track.length;
   const placements=globalThis.BGSceneryP14?.plan(track)||[];
   const replaced=new Set(placements.filter(o=>o.anchor>=0).map(o=>o.anchor));
   for(const [i,o] of placements.entries()){
     const gap=BGTracks.mod(o.z-driver.z+n*.5,n)-n*.5;
     if(Math.abs(gap)>distance||(driver.lookBack?gap>30:gap<-40)||(!high&&o.kind==='nature'&&i%2))continue;
     const small=o.kind==='nature'&&o.height<=1.15&&/^(grass|flower_|plant_)/.test(o.name);
     if(small&&Math.abs(gap)>(high?50:32))continue;
     const near=Math.abs(gap)<(high?85:42),key='p14:'+i+':'+near;
     for(const part of cachedProp(key,()=>sceneryMesh(track,o,near)))tri(...part);
   }
   for(const [i,o] of track.objects.entries()){
     const gap=BGTracks.mod(o.z-driver.z+n*.5,n)-n*.5;
     if(Math.abs(gap)>distance || (driver.lookBack?gap>30:gap<-40))continue;
     const p=track.sample(o.z),[x,y,z]=along(p,o.x),m=mesh(x,y,z,p.heading);
     if(o.kind==='tree'){
       if(replaced.has(i))continue;
       if(!high&&i%2)continue;
       const key=i+':'+high;
       const parts=cachedProp(key,()=>{
         const bush=track.weather==='snow'?'#a9bec1':track.region%4===2?'#76684e':track.weather==='night'?'#344a49':'#486d56';
         const rocky=[2,7,12].includes(track.region);
         if(!rocky)prism(m,-.15,.15,0,2.5,-.15,.15,'#57483c');
         const sides=high?8:5;
         for(let j=0;j<(rocky?2:3);j++)for(let k=0;k<sides;k++){
           const a=k*2*Math.PI/sides,b=(k+1)*2*Math.PI/sides;
           const scale=.85+(i*17%31)/75;
           const h=rocky?j*.55:(1.3+j*1.15)*scale, diameter=(rocky?1.3-j*.42:1.36-j*.29)*scale;
           const radial=(v,r,y)=>m(Math.cos(v)*r,y,Math.sin(v)*r);
           const color=shade(bush,.63+(k%4)*.1+j*.05);
           quad(radial(a,diameter,h),radial(b,diameter,h-.13),radial(b,diameter*.51,h+1.1),radial(a,diameter*.51,h+1.15),color);
           tri(radial(a,diameter*.51,h+1.15),radial(b,diameter*.51,h+1.1),m(.10,h+(rocky?1.2:2.45),.06),color);
         }
       });
       for(const part of parts)tri(...part);
     }else if(o.kind==='sign'||o.kind==='barrier'){
       const key='roadside:'+i;
       for(const part of cachedProp(key,()=>roadsideObject(track,o)))tri(...part);
     }else{
       const key=Math.floor((driver.z+gap)/track.length)+':'+o.z;
       if(!driver.picked.has(key))prism(m,-.34,.34,.02,.76,-.35,.35,{nitro:'#3db5d0',cash:'#79d174',boost:'#ec9a57'}[o.kind]||'#f8dd83');
     }
   }
 }
 function skyDome(sky,track){
   const night=track.weather==='night', cloudy=['rain','snow','fog'].includes(track.weather);
   const zenith=night?[.025,.045,.095]:cloudy?sky.map(v=>v*.77):[.19,.40,.61];
   const horizon=sky.map(v=>Math.min(1,v*(night?1.18:1.15)+.025));
   const D=530;
   const pt=(x,y)=>{const forward=D*camera.cp+y*camera.sp, up=y*camera.cp-D*camera.sp;return [camera.x+camera.fx*forward+camera.rx*x,camera.y+up,camera.z+camera.fz*forward+camera.rz*x];};
   const a=pt(-D*2,-D),b=pt(D*2,-D),c=pt(D*2,0),d=pt(-D*2,0),e=pt(D*2,D),f=pt(-D*2,D);
   tri(a,b,c,[horizon,horizon,horizon],-1);tri(a,c,d,[horizon,horizon,horizon],-1);
   tri(d,c,e,[horizon,horizon,zenith],-1);tri(d,e,f,[horizon,zenith,zenith],-1);
 }
 function riverMesh(track,banks){
   const water=track.weather==='night'?'#314a61':track.weather==='rain'?'#416172':'#498592';
   const edge=track.weather==='night'?'#465862':'#627c71';
   const strip=({z,offset,half})=>{
     const sample=track.sample(z);
     return [-half-1.2,-half,half,half+1.2].map((x,i)=>along(sample,offset+x,i===1||i===2?-.16:-.24));
   };
   let previous=strip(banks[0]);
   for(let j=1;j<banks.length;j++){
     const next=strip(banks[j]);
     quad(previous[0],previous[1],next[1],next[0],rgb(edge));
     quad(previous[1],previous[2],next[2],next[1],shade(water,.9+.055*(j%3)));
     quad(previous[2],previous[3],next[3],next[2],rgb(edge));
     previous=next;
   }
 }
 function drawRivers(track,driver){
   for(const [i,banks] of (globalThis.BGSceneryP14?.rivers(track)||[]).entries()){
     const mid=banks[4].z;
     const gap=BGTracks.mod(mid-driver.z+track.length*.5,track.length)-track.length*.5;
     if(Math.abs(gap)>185||(driver.lookBack?gap>75:gap<-75))continue;
     for(const part of cachedProp('river:'+i,()=>riverMesh(track,banks)))tri(...part);
   }
 }
 // Stable world-space mountain clusters, independent of camera direction.
 const mountainCache=new WeakMap();
 function mountainPlan(track){
   if(mountainCache.has(track))return mountainCache.get(track);
   const samples=[];for(let z=0;z<track.length;z+=8)samples.push(track.sample(z));
   const highland=[1,6,9,15].includes(track.region), desert=[2,7,12].includes(track.region);
   const hills=[];
   for(let z=0,i=0;z<track.length;z+=85,i++)for(const side of [-1,1]){
     const p=track.sample(z),radius=34+(i*13%19),offset=radius+38+(i*17%40);
     const [x,y,w]=along(p,side*offset,-5);
     if(samples.some(a=>Math.hypot(a.px-x,a.py-w)<radius+a.width+16))continue;
     if(hills.some(a=>Math.hypot(a.x-x,a.z-w)<radius+a.r*.65))continue;
     hills.push({x,y,z:w,r:radius,h:(highland?42:desert?19:26)+(i*31%23),seed:i+track.index*11});
   }
   mountainCache.set(track,hills);return hills;
 }
 function mountainMesh(track,o,detail){
   const sides=detail?12:8,rings=detail?3:2;
   const ink=track.weather==='snow'?'#9caab9':track.weather==='night'?'#34405b':[2,7,12].includes(track.region)?'#987969':'#516b70';
   const drift=o.seed*.67, broad=[1,6,9,15].includes(track.region);
   const point=(j,k)=>{
     const a=k*2*Math.PI/sides, t=j/rings;
     const r=o.r*(1-Math.pow(t,broad?1.55:1.18))*(.84+.13*Math.cos(a*3+o.seed)+.10*Math.sin(a*5+o.seed));
     const ridge=broad?.24:.13;
     return [o.x+Math.cos(a)*r+t*o.r*ridge*Math.cos(drift),
       o.y+o.h*t*(.85+.15*Math.cos(a*2+o.seed)*(1-t)),o.z+Math.sin(a)*r+t*o.r*ridge*Math.sin(drift)];
   };
   for(let j=0;j<rings;j++)for(let k=0;k<sides;k++){
     const color=shade(track.weather==='snow'&&j===rings-1?'#cbd4de':ink,.76+.20*Math.cos(k*2*Math.PI/sides-.7)+j*.06);
     const a=point(j,k),b=point(j,k+1),c=point(j+1,k+1),d=point(j+1,k);
     if(j===rings-1)tri(a,b,c,color);else quad(a,b,c,d,color);
   }
 }
 function mountains(track,position,forward,side,detail){
   for(const o of mountainPlan(track))if(Math.hypot(o.x-position.px,o.z-position.py)<380+o.r)mountainMesh(track,o,detail);
 }
 function precipitation(track,tick,detail){
   if(!['rain','snow'].includes(track.weather))return;
   const snow=track.weather==='snow', ink=rgb(snow?'#dae5ea':'#a1b3c2');
   for(let i=0;i<(detail?(snow?40:68):(snow?12:20));i++){
     const depth=3+i%17,x=((i*39+tick)%105-52)*depth*.022;
     const y=((i*71-tick*(snow?2:7))%83+83)%83*.071-3;
     const p=(u,v)=>[camera.x+camera.fx*depth+camera.rx*(x+u),camera.y+y+v,
       camera.z+camera.fz*depth+camera.rz*(x+u)];
     if(snow){const size=.035+(i%4)*.013;quad(p(-size,0),p(0,size),p(size,0),p(0,-size),ink); }
     else quad(p(0,0),p(.016,0),p(.076,.29),p(.06,.29),ink);
   }
 }
 function draw(race,driver,x,y,w,h,preset){
   const track=race.track, p=track.sample(driver.z), back=driver.lookBack?Math.PI:0;
   const angled=p.heading+back, f=[Math.cos(angled),Math.sin(angled)],r=[-f[1],f[0]];
   const old=chase.get(driver);
   const lane=old&&old.view===driver.camera&&old.back===back?old.lane+(driver.x-old.lane)*.22:driver.x;
   chase.set(driver,{lane,view:driver.camera,back});
   const base=along(p,lane*.82);
   const views=[{distance:7.45,height:2.64},{distance:11.5,height:5.1},{distance:3.4,height:2.1}];
   const v=views[(driver.camera||0)%views.length];
   const cameraDistance=v.distance+driver.speed*.012, direction=driver.lookBack?-1:1;
   const behind=track.sample(driver.z-direction*cameraDistance), ahead=track.sample(driver.z+direction*12);
   const grade=(ahead.y-behind.y)/(12+cameraDistance);
   const pitch=Math.max(-.08,Math.min(.34,.13-Math.atan(grade)*.75));
   camera={x:base[0]-f[0]*cameraDistance,y:behind.y+v.height,z:base[2]-f[1]*cameraDistance,
     fx:f[0],fz:f[1],rx:r[0],rz:r[1],cp:Math.cos(pitch),sp:Math.sin(pitch)};
   const palette=P[Math.max(0,weather.indexOf(track.weather))], sky=rgb(palette[0]);
   const yaw=p.heading+visualYaw(driver), dir=[Math.cos(yaw),Math.sin(yaw)];
   const center=along(p,driver.x), lamps=[];
   const [lampSide,lampY,lampZ]=spectralReady?BGSpectralRender.mounts.head:[.57,0,2];
   for(const side of [-1,1]){const local=spectralReady?BGSpectralRender.bodyPoint(side*lampSide,lampY,lampZ,bodyPoses.get(driver)):[side*lampSide,lampY,lampZ];
     lamps.push(center[0]+dir[0]*local[2]-dir[1]*local[0],center[2]+dir[1]*local[2]+dir[0]*local[0],...dir);}
   const lampMode=ranges(track,'tunnels',driver.z)?'tunnel':track.weather;
   const beam=spectralReady?BGSpectralRender.lights(driver,lampMode).beam:(lampMode==='night'||lampMode==='tunnel'?1:0);

   gl.viewport(x,y,w,h);gl.scissor(x,y,w,h);gl.clearColor(...sky,1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
   gl.useProgram(program);
   gl.uniform1f(uniform.aspect,w/h);
   gl.uniform1f(uniform.f,(race.cars.filter(c=>c.player).length===2?1.82:1.67)-Math.min(.17,driver.speed*.0023));
   gl.uniform3fv(uniform.haze,sky);
   gl.uniform1f(uniform.wet,track.weather==='rain'?1:0);
   gl.uniform1f(uniform.night,beam);
   gl.uniform4fv(uniform['lamps[0]'],lamps);
   gl.uniform4fv(uniform['streetLights[0]'],streetUniform(track,driver));
   gl.uniform1f(uniform.atmosphere,track.weather==='fog'?.0065:track.weather==='rain'?.0035:.002);
   count=0;spectralQueue=[];
   const distance=preset.effects?225:150;
   skyDome(sky,track);
   mountains(track,p,f,r,preset.effects);
   roadway(track,driver,palette,distance);
   drawRivers(track,driver);
   scenery(track,driver,distance,preset.effects);
   let viewLevels=rivalLevels.get(driver);if(!viewLevels){viewLevels=new WeakMap();rivalLevels.set(driver,viewLevels);}
   for(const car of race.cars){
     const gap=BGTracks.mod(car.z-driver.z+track.length*.5,track.length)-track.length*.5;
     if(Math.abs(gap)<=distance&&(driver.lookBack?gap<22:gap>-33)){
       const lod=car===driver?2:spectralReady?BGSpectralRender.rivalLOD(gap,preset.effects,viewLevels.get(car)):preset.effects&&Math.abs(gap)<31?1:0;
       viewLevels.set(car,lod);vehicle(track,car,lod);
     }else viewLevels.delete(car);
   }
   if(!ranges(track,'tunnels',driver.z))precipitation(track,race.tick,preset.effects);
   submit();
   if(spectralReady)BGSpectralRender.draw(gl,spectralQueue,camera,w/h,(race.cars.filter(c=>c.player).length===2?1.82:1.67)-Math.min(.17,driver.speed*.0023),sky,track.weather==='fog'?.0065:track.weather==='rain'?.0035:.002);
 }
 function submit(){
   if(!count)return;
   bindScene();
   if(data.byteLength>capacity){capacity=data.byteLength;gl.bufferData(gl.ARRAY_BUFFER,capacity,gl.DYNAMIC_DRAW);}
   gl.bufferSubData(gl.ARRAY_BUFFER,0,data.subarray(0,count));gl.drawArrays(gl.TRIANGLES,0,count/11);
   gl.disableVertexAttribArray(gl.getAttribLocation(program,'roadCoord'));
 }
 function preview(target,car,angle){
   if(lost||unsupported)return false;
   try{
     if(!ready&&!boot()){unsupported=true;return false;}
     const w=surface.width,h=surface.height;
     const fx=Math.cos(angle),fz=Math.sin(angle);
     camera={x:-6.3*fx,y:2.25,z:-6.3*fz,fx,fz,rx:-fz,rz:fx,cp:Math.cos(.20),sp:Math.sin(.20)};
     gl.viewport(0,0,w,h);gl.scissor(0,0,w,h);gl.clearColor(.054,.078,.116,1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
     gl.useProgram(program);gl.uniform1f(uniform.aspect,w/h);gl.uniform1f(uniform.f,1.77);
     gl.uniform3fv(uniform.haze,[.07,.09,.15]);gl.uniform1f(uniform.atmosphere,.0008);gl.uniform1f(uniform.wet,0);gl.uniform1f(uniform.night,0);gl.uniform4fv(uniform['lamps[0]'],[0,0,1,0,0,0,1,0]);
     gl.uniform4fv(uniform['streetLights[0]'],new Float32Array(16));
     count=0;spectralQueue=[];
     quad([-14,-.035,-14],[14,-.035,-14],[14,-.035,14],[-14,-.035,14],rgb('#24313f'),1);
     carMesh({...car,player:1},[0,0,0],0,2,1.04,0,"studio");
     submit();
     if(spectralReady)BGSpectralRender.draw(gl,spectralQueue,camera,w/h,1.77,[.07,.09,.15],.0008);
     const ctx=target.getContext('2d'), crop=Math.min(w,h*target.width/target.height);
     ctx.drawImage(surface,(w-crop)/2,0,crop,h,0,0,target.width,target.height);
     return true;
   }catch{return false;}
 }
 let unsupported=false;
 function render(race,preset){
   if(lost||unsupported)return false;
   try{
     if(!ready&&!boot()){unsupported=true;return false;}
     // Reuse world geometry across both panels and consecutive frames. Keep only visible sets.
     previousProps=propTrack===race.track?propFrame:new Map();
     propTrack=race.track;
     propFrame=new Map();
     if(spectralReady)for(const c of race.cars)bodyPoses.set(c,BGSpectralRender.bodyPose(c,race.track.sample(c.z),bodyPoses.get(c),race.tick));
     const cars=race.cars.filter(c=>c.player);
     const h=Math.floor(surface.height/cars.length);
     cars.forEach((c,i)=>draw(race,c,0,surface.height-h*(i+1),surface.width,h,preset));
     return true;
   }catch(e){console.error(e.stack);unsupported=true;return false;}
   finally{previousProps.clear();}
 }
 function inspectRoadSlice(track,z,stride,slot=0,first=true){
   const prior=recording;recording=[];
   try{segment(track,P[Math.max(0,weather.indexOf(track.weather))],z,stride,slot,first);return recording;}finally{recording=prior;}
 }
 function inspectRoadside(track,o){const prior=recording;recording=[];try{roadsideObject(track,o);return recording;}finally{recording=prior;}}
 function inspectScenery(track,o,near=true){const prior=recording;recording=[];try{sceneryMesh(track,o,near);return recording;}finally{recording=prior;}}
 function inspectMountains(track,detail=true){const prior=recording;recording=[];try{for(const o of mountainPlan(track))mountainMesh(track,o,detail);return recording;}finally{recording=prior;}}
 function inspectRiver(track,banks){const prior=recording;recording=[];try{riverMesh(track,banks);return recording;}finally{recording=prior;}}
 return {streetPlan,streetUniform,mountainPlan,inspectMountains,inspectScenery,inspectRiver,render,preview,visualYaw,makeRoadMap,roadTextureData,roadSlices,roadError,inspectRoadSlice,inspectRoadside};
})();
