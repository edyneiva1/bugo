'use strict';
globalThis.BGControls=(()=>{
  const actions=['gas','brake','left','right','boost','up','down','handbrake','camera','lookBack','pause','confirm'];
  const base=[
    [['KeyW','ArrowUp'],['KeyS','ArrowDown'],['KeyA','ArrowLeft'],['KeyD','ArrowRight'],['ShiftLeft','KeyN'],['KeyE'],['KeyQ'],['Space'],['KeyC'],['KeyR'],['Escape','KeyP'],['Enter']],
    [['KeyI'],['KeyK'],['KeyJ'],['KeyL'],['ShiftRight','KeyM'],['KeyO'],['KeyU'],['KeyH'],['KeyV'],['KeyB'],[],[]]
  ];
  const config=(state,i)=>actions.map((_,j)=>state.keys?.[i]?.[j]??(j<7&&state.custom?.[i]?[state.custom[i][j]]:base[i][j]));
  function keys(state,i,held){
    return Object.fromEntries(actions.map((field,j)=>[field,config(state,i)[j].some(code=>held.has(code))]));
  }
  function set(state,i,action,code){
    if(!/^[A-Za-z0-9]{1,24}$/.test(code)||['F10','F11','Tab','Escape'].includes(code))return false;
    const layouts=[config(state,0),config(state,1)];
    if(layouts.some((layout,k)=>layout.some((field,j)=>(k!==i||j!==action)&&field.includes(code))))return false;
    state.keys[i]??=Array(actions.length).fill(null);
    state.keys[i][action]=[code];
    return true;
  }
  function reset(state,i){state.keys[i]=null;state.custom[i]=null;}
  return {actions,config,keys,set,reset};
})();
