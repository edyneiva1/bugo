'use strict';
globalThis.BGEngine = (() => {
  const dt = 1 / 60;
  const clamp = (n, low, high) => Math.max(low, Math.min(high, n));
  const {mod} = BGTracks;
  const colors = ['#ec4963','#45c7dc','#e6bf49','#9958d8','#8ccd63','#e77839','#e0dfd3','#547de4'];
  const {slot,transmissions,nitro} = BGParts;
  function create(track, players, profiles = [], difficulty = 1) {
    const cars = Array.from({length: 20}, (_, id) => {
      const config = profiles[id] || {};
      const player = id < players ? id + 1 : 0;
      const grid = player ? 20 - players + id : id - players;
      const kit = nitro[config.parts?.[slot.nitro] || 0];
      return {
        id, player, color: colors[config.paint ?? id % colors.length], z: -2 - grid * 4.6,
        x: grid % 2 ? 2.5 : -2.5, speed: 0, vx: 0, steer: 0, rpm: 0, gear: 1,
        nitro: kit.stock, kit, cash: 0, fuel: 100, boost: 0, nitroReady:0, impulse: 0, brake: false,
        brakeTime: 0, coastTime: 0, damage: [0,0,0], spin: 0,
        config, previous: {}, finish: null, retired: false, picked: new Set()
      };
    });
    return {track, cars, laps: track.laps, time: -3, tick: 0, difficulty, events: [], contacts: new Set()};
  }
  function inputAI(race,c) {
    const {track, time, difficulty} = race;
    const road = track.sample(c.z);
    const bend = track.sample(c.z + Math.max(18,c.speed*.65)).curvature || 0;
    let target = ((c.id * 7) % 5 - 2) * road.width / 4 + Math.sin(c.id + time * .35) * .6;
    let gap=35, ahead;
    for (const other of race.cars) {
      const delta=other.z-c.z;
      if (delta>0 && delta<gap && !other.retired && other.finish===null && Math.abs(other.x-c.x)<2.1) {
        gap=delta; ahead=other;
      }
    }
    if (ahead) target = ahead.x + (ahead.x >= 0 ? -3 : 3);
    const limit = 49 + difficulty*8 + c.id%7 - Math.min(24,Math.abs(bend)*(1600-difficulty*230));
    return {gas:c.speed<limit,brake:c.speed>limit+4 || gap<7 && ahead.speed+8<c.speed,
      steer:clamp((target-c.x)*.42 + (road.curvature || 0)*c.speed*c.speed*.012,-1,1),
      boost:c.speed>42 && Math.abs(bend)<.003 && gap>19 && (race.tick+c.id*193)%1310===0};
  }
  function hit(race,c,region,intensity,dir) {
    const part = c.config.parts?.[region + 3] || 0;
    const unprotected = c.damage[region] >= 100;
    c.damage[region] = clamp(c.damage[region] + intensity / (1 + part * .55),0,100);
    c.speed *= 1 - clamp(intensity / 95,.07,.57);
    c.vx += dir * intensity * .17;
    if (intensity > 16) c.spin = dir * clamp(intensity*.023,.38,1.05);
    if (unprotected && intensity >= 36 && region === 0 && c.finish === null) {
      c.retired = true;
      c.retiredAt=race.time;
      c.boost=0; c.impulse=0; c.speed=0; c.rpm=0; c.vx=0;
    }
    if (c.player) race.events.push('collision');
  }
  function advance(race,c,a) {
    const {track} = race, p = c.config.parts || [];
    const road = track.sample(c.z);
    const wet = ['rain','snow'].includes(track.weather);
    const grip = (wet ? (track.weather === 'snow' ? .58 : .72) + (p[2] || 0) * .08 : .93 + (p[1] || 0) * .07);
    const outside = Math.abs(c.x) > road.width;
    c.brake = !!a.brake;
    if (c.player && c.brake && !c.previous.brake && c.speed > 10) race.events.push('brake');
    c.brakeTime = c.brake ? c.brakeTime + dt : 0;
    c.steer = Number(a.steer) || 0;
    if (a.boost && !c.previous.boost &&
        c.nitro > 0 && race.tick>=c.nitroReady && c.fuel > 0 && !c.retired) {
      c.boost = c.kit.time; c.nitro--; c.nitroReady=race.tick+(c.speed>15?438:420);
      if (c.player) race.events.push('nitro');
    }
    c.boost = Math.max(0,c.boost - dt);
    c.impulse = Math.max(0,c.impulse-dt);
    const gears = transmissions[p[slot.gearbox] || 0];
    const engine = p[slot.engine] || 0;
    const top = c.gear===0 ? 18 : gears[c.gear - 1] + engine*2;
    const previousGear = c.gear;
    if (c.config.manual) {
      if (a.up && !c.previous.up && (c.gear!==0 || c.speed<1.5)) c.gear = Math.min(gears.length,c.gear + 1);
      if (a.down && !c.previous.down && c.gear>0 && (c.gear>1 || c.speed<1.5)) c.gear--;
    } else {
      if (c.speed > top * .92 && c.gear < gears.length) c.gear++;
      else if (c.gear > 1 && c.speed < gears[c.gear - 2] * .71) c.gear--;
    }
    if (c.player && c.gear !== previousGear) race.events.push('shift');
    const ratio = c.gear===0 ? 18 : gears[c.gear-1]+engine*2;
    c.rpm = clamp(c.speed / ratio,.14,1);
    const damage = c.damage.reduce((s,n) => s + n,0) / 300;
    const gas = a.gas && c.fuel > 0 && c.finish === null && !c.retired;
    c.coastTime = gas ? 0 : c.coastTime + dt;
    const direction=c.gear===0?-1:1;
    const grade = (track.sample(c.z + 3*direction).y - road.y) / 3;
    const launch = clamp(.13 + race.time * 4.3,.13,1);
    const torque = c.speed<14.7 ? 20.2 : c.speed<26.7 ? 17.6 : c.speed<39.5 ? 11.7 : c.speed<52 ? 9.3 : 7.5;
    const clutch=c.config.manual&&c.gear>1 ? clamp(.82/c.gear+c.speed/ratio,.2,1) : 1;
    const drive = gas ? (torque + engine*.7) * (1-damage*.52)*launch*clutch : 0;
    const engineBrake = c.brake ? 13.8 : 7 + 7.8 * Math.min(1,c.coastTime/.25);
    const drag = (gas ? .8 + c.speed * .029 : engineBrake + c.speed * .012) +
      (outside ? 4.1 + c.speed * .11 : 0);
    const braking = 26 * Math.min(1,c.brakeTime/.28);
    const thrust = (gas ? (c.boost>c.kit.time-.42 ? 10.2 : c.boost>0 ? 1.2 : 0)*c.kit.force : 0) + (c.impulse>0 ? 7 : 0);
    const cap = (ratio + (c.boost>0 ? 22 : 0) + (c.impulse>0 ? 10 : 0)) * (1-damage*.2);
    c.speed = clamp(c.speed + (drive - drag - grade * 4 - braking +
      thrust - Math.max(0,c.speed - cap) * 2.25) * dt, 0, 110);
    c.fuel = Math.max(0,c.fuel - (gas ? (.10 + c.speed * .0024 + (c.boost > 0 ? .19 : 0)) * dt : 0));
    const steering = c.spin ? -Math.sign(c.spin) * .4 : c.steer;
    c.spin -= Math.sign(c.spin) * Math.min(dt,Math.abs(c.spin));
    const target = direction*steering*Math.min(13,c.speed*.32)*grip-(road.curvature || 0)*c.speed*c.speed*.12;
    if(c.player&&c.speed>32&&Math.abs(steering)>.82&&Math.abs(target-c.vx)>6&&race.tick%18===0)race.events.push('skid');
    c.vx += (target - c.vx) * dt * (outside ? 3.5 : 6.4) * grip;
    c.x = clamp(c.x + c.vx * dt,-road.width - 4,road.width + 4);
    c.z += direction*c.speed*dt;
    c.previous = {...a};
  }
  function objectContacts(race,c,old) {
    const {track} = race;
    if (c.z <= old.z) return;
    const distance = c.z - old.z, start = mod(old.z,track.length);
    const objects = track.objects;
    if (!objects.length) return;
    let low = 0, high = objects.length;
    while (low < high) {
      const center = (low + high) >> 1;
      if (objects[center].z < start) low = center + 1;
      else high = center;
    }
    for (let i = 0; i < objects.length; i++) {
      const object = objects[(low + i) % objects.length];
      const delta = object.z >= start ? object.z - start : object.z + track.length - start;
      if (delta > distance) break;
      const fraction = delta / (c.z - old.z);
      const x = old.x + (c.x - old.x) * fraction;
      if (Math.abs(x - object.x) > (object.kind === 'barrier' ? 1.42 : 1.16)) continue;
      const lap = Math.floor((old.z + delta) / track.length);
      const key = lap + ':' + object.z;
      if (c.picked.has(key)) continue;
      c.picked.add(key);
      if (['nitro','boost','cash'].includes(object.kind)) {
        if (object.kind === 'nitro') c.nitro = Math.min(c.kit.max,c.nitro+1);
        if (object.kind === 'boost') { c.impulse=1.1; c.speed=Math.min(110,c.speed+4); }
        if (object.kind === 'cash') c.cash += 500;
        if (c.player) race.events.push(object.kind==='nitro' ? 'pickup' : object.kind==='boost' ? 'nitro' : 'purchase');
      } else hit(race,c,0,8 + c.speed * .37, Math.sign(-object.x));
    }
  }
  function span(start,end,radius) {
    const rate = end - start;
    if (Math.abs(rate) < 1e-8) return Math.abs(start) <= radius ? [0,1] : [1,0];
    const a = (-radius - start) / rate, b = (radius - start) / rate;
    return [Math.min(a,b),Math.max(a,b)];
  }
  function carContacts(race,old) {
    const next = new Set(), {cars,track} = race;
    for (let i = 0; i < cars.length; i++) for (let j = i + 1; j < cars.length; j++) {
      const a = cars[i], b = cars[j], key = i * cars.length + j;
      if (a.finish!==null || b.finish!==null || a.retired || b.retired) continue;
      const previousZ = mod(old[j].z - old[i].z + track.length / 2,track.length) - track.length / 2;
      const z = previousZ + (b.z - old[j].z) - (a.z - old[i].z);
      const x = b.x - a.x;
      const longitudinal = span(previousZ,z,3.4);
      const lateral = span(old[j].x - old[i].x,x,1.65);
      const entry=Math.max(0,longitudinal[0],lateral[0]);
      if (entry > Math.min(1,longitudinal[1],lateral[1])) continue;
      next.add(key);
      const overlapX=1.65-Math.abs(x), overlapZ=3.4-Math.abs(z);
      const lateralImpact=entry>0 ? lateral[0]>=longitudinal[0] : overlapX<=overlapZ;
      const startX=old[j].x-old[i].x;
      const dir=Math.sign(lateralImpact ? startX+(x-startX)*entry : previousZ+(z-previousZ)*entry) || 1;
      if (overlapX>0 && overlapZ>0) {
        if (lateralImpact) {
          const correction=(overlapX+.015)*.5*dir;
          a.x-=correction; b.x+=correction;
        } else {
          const correction=(overlapZ+.015)*.5*dir;
          a.z-=correction; b.z+=correction;
        }
      }
      if (race.contacts.has(key)) continue;
      const closing=Math.abs(a.speed*(a.gear===0?-1:1)-b.speed*(b.gear===0?-1:1));
      const strength=lateralImpact ? 3+Math.min(20,Math.abs(a.vx-b.vx)*.7) :
        4+Math.min(38,closing*.48);
      const lateralDir=lateralImpact ? dir : Math.sign(x) || (a.id%2 ? -1 : 1);
      hit(race,a,lateralImpact ? 2 : dir>0 ? 0 : 1,strength,-lateralDir);
      hit(race,b,lateralImpact ? 2 : dir>0 ? 1 : 0,strength*.7,lateralDir);
    }
    race.contacts = next;
  }
  function step(race,controls = []) {
    race.tick++;
    race.time = (race.tick - 180) * dt;
    race.events.length = 0;
    if (race.tick <= 180) return;
    const old = race.cars.map(({x,z}) => ({x,z}));
    for (const c of race.cars) {
      if (c.finish!==null || c.retired) continue;
      advance(race,c,c.player ? controls[c.player-1] || {} : inputAI(race,c));
      objectContacts(race,c,old[c.id]);
      const finishZ = race.track.length * race.laps;
      if (c.finish === null && !c.retired && c.z >= finishZ) {
        c.finish = race.time - dt * (c.z - finishZ) / (c.z - old[c.id].z);
        if (c.player) race.events.push('finish');
      }
    }
    carContacts(race,old);
  }
  function order(race) {
    return [...race.cars].sort((a,b) => (a.finish ?? Infinity) - (b.finish ?? Infinity) ||
      Number(a.retired) - Number(b.retired) || b.z - a.z || a.id - b.id);
  }
  function frame(race) {
    return { tick: race.tick, track: race.track.index, cars: race.cars.map(({id,z,x,speed,gear,boost,damage,finish}) =>
      ({id,z,x,speed,gear,boost,damage:[...damage],finish})) };
  }
  const interpolate = (previous,next,alpha) => next.cars.map((car,i) => ({...car,
    x: previous.cars[i].x + (car.x - previous.cars[i].x) * alpha,
    z: previous.cars[i].z + (car.z - previous.cars[i].z) * alpha}));
  return {create,step,order,dt,colors,frame,interpolate,inputAI};
})();
